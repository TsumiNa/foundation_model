# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""
Test module for configuration models.
"""

import pytest
from pydantic import ValidationError

from shotgun_csp.cli.config_models import CrystalConfig, GeneratorCliConfig
from shotgun_csp.cli.exceptions import ConfigurationError
from shotgun_csp.core.utils import WY


class TestGeneratorCliConfig:
    """Test class for GeneratorCliConfig model."""

    # 2025-04-29: Added tests for GeneratorCliConfig validation and defaults
    def test_valid_config(self):
        """Test that a valid configuration passes validation."""
        config = GeneratorCliConfig(
            full_formula="Li2O",
            volume_of_cell=100.0,
            space_group_num=225,
            max_angle_degree=140.0,
            min_angle_degree=40.0,
            max_attempts=500,
            variance_of_volume=5.0,
            low_length=3.0,
            high_length=10.0,
        )

        # Verify values are set correctly
        assert config.full_formula == "Li2O"
        assert config.volume_of_cell == 100.0
        assert config.space_group_num == 225
        assert config.max_angle_degree == 140.0
        assert config.min_angle_degree == 40.0
        assert config.max_attempts == 500
        assert config.variance_of_volume == 5.0
        assert config.low_length == 3.0
        assert config.high_length == 10.0

        # Verify defaults are set correctly
        assert config.decimals == 7
        assert config.wyckoff_mixing_ratio == 0.0
        assert config.use_mesh is True
        assert config.perturbation == 0.05
        assert config.check_atomic_dist is False
        assert "ltol" in config.structure_matcher_params
        assert "angle_tol" in config.structure_matcher_params

    def test_default_values(self):
        """Test that default values are set correctly."""
        config = GeneratorCliConfig(
            volume_of_cell=200.0,
            space_group_num=123,
        )

        # Verify that default values are set
        assert config.variance_of_volume == 200.0 * 0.1
        assert config.low_length == pytest.approx(200.0 ** (1 / 3) * 0.5)
        assert config.high_length == pytest.approx(200.0 ** (1 / 3) * 1.5)
        assert config.max_angle_degree == 150.0
        assert config.min_angle_degree == 20.0
        assert config.max_attempts == 1000
        assert config.decimals == 7
        assert config.wyckoff_mixing_ratio == 0.0

    def test_invalid_volume(self):
        """Test validation of volume_of_cell."""
        # 2025-04-29: Added test to ensure volume_of_cell is validated properly
        with pytest.raises(ConfigurationError) as exc_info:
            GeneratorCliConfig(
                volume_of_cell=5.0,  # Too small
                space_group_num=123,
            )

        assert "volume_of_cell must be greater than 10" in str(exc_info.value)

    def test_invalid_space_group(self):
        """Test validation of space_group_num."""
        # 2025-04-29: Added test to ensure space_group_num is validated properly
        # Test with space group below valid range
        with pytest.raises(ConfigurationError) as exc_info:
            GeneratorCliConfig(
                volume_of_cell=100.0,
                space_group_num=0,  # Invalid - below range
            )

        assert "Space group must be between 1 and 230" in str(exc_info.value)

        # Test with space group above valid range
        with pytest.raises(ConfigurationError) as exc_info:
            GeneratorCliConfig(
                volume_of_cell=100.0,
                space_group_num=231,  # Invalid - above range
            )

        assert "Space group must be between 1 and 230" in str(exc_info.value)

    def test_invalid_angle_degree(self):
        """Test validation of angle_degree limits."""
        # 2025-04-29: Added test to ensure angle degree limits are validated properly
        # Test with min_angle_degree too small
        with pytest.raises(ConfigurationError) as exc_info:
            GeneratorCliConfig(
                volume_of_cell=100.0,
                space_group_num=123,
                min_angle_degree=5.0,  # Too small
            )

        assert "angle_degree must be between 10 and 170" in str(exc_info.value)

        # Test with max_angle_degree too large
        with pytest.raises(ConfigurationError) as exc_info:
            GeneratorCliConfig(
                volume_of_cell=100.0,
                space_group_num=123,
                max_angle_degree=180.0,  # Too large
            )

        assert "angle_degree must be between 10 and 170" in str(exc_info.value)

        # Test with min_angle_degree >= max_angle_degree
        with pytest.raises(ConfigurationError) as exc_info:
            GeneratorCliConfig(
                volume_of_cell=100.0,
                space_group_num=123,
                min_angle_degree=100.0,
                max_angle_degree=100.0,  # Equal to min
            )

        assert "min_angle_degree must be less than max_angle_degree" in str(exc_info.value)

    def test_invalid_max_attempts(self):
        """Test validation of max_attempts."""
        # 2025-04-29: Added test to ensure max_attempts is validated properly
        with pytest.raises(ConfigurationError) as exc_info:
            GeneratorCliConfig(
                volume_of_cell=100.0,
                space_group_num=123,
                max_attempts=50,  # Too small
            )

        assert "max_attempts must be greater than 100" in str(exc_info.value)

    def test_invalid_variance_of_volume(self):
        """Test validation of variance_of_volume."""
        # 2025-04-29: Added test to ensure variance_of_volume is validated properly
        with pytest.raises(ConfigurationError) as exc_info:
            GeneratorCliConfig(
                volume_of_cell=100.0,
                space_group_num=123,
                variance_of_volume=30.0,  # Too large (> volume/4)
            )

        assert "variance_of_volume must be between 0 and volume_of_cell / 4" in str(exc_info.value)

    def test_invalid_wyckoff_mixing_ratio(self):
        """Test validation of wyckoff_mixing_ratio."""
        # 2025-04-29: Added test to ensure wyckoff_mixing_ratio is validated properly
        # Test with value below range
        with pytest.raises(ConfigurationError) as exc_info:
            GeneratorCliConfig(
                volume_of_cell=100.0,
                space_group_num=123,
                wyckoff_mixing_ratio=-0.1,  # Below valid range
            )

        assert "wyckoff_mixing_ratio must be between 0.0 and 1.0" in str(exc_info.value)

        # Test with value above range
        with pytest.raises(ConfigurationError) as exc_info:
            GeneratorCliConfig(
                volume_of_cell=100.0,
                space_group_num=123,
                wyckoff_mixing_ratio=1.1,  # Above valid range
            )

        assert "wyckoff_mixing_ratio must be between 0.0 and 1.0" in str(exc_info.value)

    def test_invalid_wy_priority(self):
        """Test validation of wy_priority."""
        # 2025-04-29: Added test to ensure wy_priority is validated against available positions
        # Get valid Wyckoff positions for space group 1
        space_group_num = 1
        valid_wy_positions = set(WY[space_group_num - 1].keys())

        # Create an invalid wy_priority with a non-existent Wyckoff position
        invalid_wy_position = "z"  # This should not exist for any space group
        wy_priority = {pos: 1.0 for pos in valid_wy_positions}
        wy_priority[invalid_wy_position] = 1.0

        with pytest.raises(ConfigurationError) as exc_info:
            GeneratorCliConfig(
                volume_of_cell=100.0,
                space_group_num=space_group_num,
                wy_priority=wy_priority,
            )

        assert "Invalid Wyckoff positions" in str(exc_info.value)
        assert invalid_wy_position in str(exc_info.value)


class TestCrystalConfig:
    """Test class for CrystalConfig model."""

    # 2025-04-29: Added tests for CrystalConfig model
    def test_valid_crystal_config(self):
        """Test that a valid crystal configuration passes validation."""
        generator_args = GeneratorCliConfig(
            volume_of_cell=100.0,
            space_group_num=123,
        )

        wyckoff_cfgs = [
            {"Li": ["a", "b"], "O": ["c"]},
            {"Li": ["d"], "O": ["e", "f"]},
        ]

        config = CrystalConfig(
            generator_args=generator_args,
            wyckoff_cfgs=wyckoff_cfgs,
        )

        # Verify that the config is created correctly
        assert config.generator_args.volume_of_cell == 100.0
        assert config.generator_args.space_group_num == 123
        assert len(config.wyckoff_cfgs) == 2
        assert "Li" in config.wyckoff_cfgs[0]
        assert "O" in config.wyckoff_cfgs[0]
        assert config.wyckoff_cfgs[0]["Li"] == ["a", "b"]
        assert config.wyckoff_cfgs[0]["O"] == ["c"]

    def test_invalid_generator_args(self):
        """Test validation when generator_args is invalid."""
        # 2025-04-29: Added test to ensure generator_args validation is propagated
        # Create invalid generator args (volume too small)
        wyckoff_cfgs = [{"Li": ["a"], "O": ["b"]}]

        with pytest.raises(ValidationError):
            # This should fail because volume is required
            CrystalConfig(
                generator_args={"space_group_num": 123},  # Missing volume_of_cell
                wyckoff_cfgs=wyckoff_cfgs,
            )

    def test_invalid_wyckoff_cfgs(self):
        """Test validation when wyckoff_cfgs is invalid."""
        # 2025-04-29: Added test to ensure wyckoff_cfgs validation
        generator_args = GeneratorCliConfig(
            volume_of_cell=100.0,
            space_group_num=123,
        )

        with pytest.raises(ValidationError):
            # This should fail because wyckoff_cfgs should be a list
            CrystalConfig(
                generator_args=generator_args,
                wyckoff_cfgs={"Li": ["a"], "O": ["b"]},  # Not a list
            )
