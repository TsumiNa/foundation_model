# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""Exceptions for the CLI module."""


class CLIError(Exception):
    """Base exception for CLI errors."""

    pass


class ConfigurationError(CLIError):
    """Exception raised for errors in the configuration."""

    pass


class GenerationError(CLIError):
    """Exception raised for errors during structure generation."""

    pass
