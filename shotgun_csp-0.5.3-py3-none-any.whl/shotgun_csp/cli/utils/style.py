# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""Styling utilities for the CLI."""

import click
from click_rich_help import StyledCommand, StyledGroup

# Define colors for different elements
COLORS = {
    "primary": "bright_blue",  # Main command names and primary info
    "secondary": "green",      # Secondary information
    "highlight": "bright_yellow",  # Highlighted elements
    "parameter": "bright_cyan",  # Parameters
    "default": "bright_white",  # Default values
    "example": "bright_green",  # Examples
    "warning": "bright_red",  # Warning information
    "option": "magenta",  # Option names
    "description": "bright_white",  # Descriptions
}


# Command classes with predefined styling
class ColoredCommand(StyledCommand):
    """Command class with colored output."""
    pass


class ColoredGroup(StyledGroup):
    """Group class with colored output."""
    pass


# Helper functions to style specific parts of the text
def style_command(text):
    """Style a command name."""
    return click.style(text, fg=COLORS["primary"], bold=True)


def style_option(text):
    """Style an option name."""
    return click.style(text, fg=COLORS["option"], bold=True)


def style_parameter(text):
    """Style a parameter name."""
    return click.style(text, fg=COLORS["parameter"], bold=True)


def style_value(text):
    """Style a value."""
    return click.style(text, fg=COLORS["secondary"])


def style_highlight(text):
    """Style highlighted text."""
    return click.style(text, fg=COLORS["highlight"], bold=True)


def style_example(text):
    """Style example text."""
    return click.style(text, fg=COLORS["example"])


def style_default(text):
    """Style default value text."""
    return click.style(f"(default: {text})", fg=COLORS["default"])


def style_path(text):
    """Style a file path."""
    return click.style(text, fg=COLORS["secondary"], underline=True)
