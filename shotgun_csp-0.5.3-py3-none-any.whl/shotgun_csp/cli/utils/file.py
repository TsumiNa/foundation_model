# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

from pathlib import Path
from typing import Any, Tuple

import joblib
import pandas as pd
from loguru import logger


def get_space_group_dir(output_dir: Path, formula: str, space_group_num: int) -> Path:
    """Create and return space group directory path.

    Args:
        output_dir: Base output directory
        formula: Chemical formula
        space_group_num: Space group number

    Returns:
        Path to the space group directory
    """
    # Clean formula to ensure it's suitable for filesystem
    formula = formula.replace(" ", "")

    # Create the directory structure
    space_group_dir = output_dir / formula / f"space_group_{space_group_num}"
    space_group_dir.mkdir(parents=True, exist_ok=True)

    return space_group_dir


def save_compressed_pickle(obj: Any, file_path: Path, compress=3):
    """Save object as compressed pickle file using joblib.

    Args:
        obj: Object to save
        file_path: Path to save the file
        compress: Compression level (0-9)
    """
    if isinstance(obj, pd.DataFrame):
        # For pandas DataFrame, ensure the file extension is .pd.xz
        # Remove all suffixes (multi-part) and add .pd.xz
        stem = file_path
        while stem.suffix:
            stem = stem.with_suffix("")
        file_path = stem.with_name(stem.name + ".pd.xz")
        obj.to_pickle(file_path, compression="xz")
    else:
        # For other objects use joblib with zlib compression
        joblib.dump(obj, file_path, compress=compress)

    logger.debug(f"💾 Saved compressed data to {file_path}")


def create_optimization_dirs(space_group_dir: Path) -> Tuple[Path, Path, Path]:
    """Create directories for optimization outputs.

    Args:
        space_group_dir: Base space group directory

    Returns:
        Tuple of (trajectory_dir, logs_dir, cifs_dir)
    """
    # Create optimization directories
    opt_trajectory_dir = space_group_dir / "opt_trajectory"
    opt_logs_dir = space_group_dir / "opt_logs"
    opt_cifs_dir = space_group_dir / "opt_cifs"

    for dir_path in [opt_trajectory_dir, opt_logs_dir, opt_cifs_dir]:
        dir_path.mkdir(exist_ok=True)

    return opt_trajectory_dir, opt_logs_dir, opt_cifs_dir
