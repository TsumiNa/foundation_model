# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""
Test module for file utilities.
"""

import shutil
import tempfile
from pathlib import Path

import joblib
import pandas as pd
import pytest

from shotgun_csp.cli.utils.file import (
    create_optimization_dirs,
    get_space_group_dir,
    save_compressed_pickle,
)


class TestFileUtils:
    """Test class for file utility functions."""

    @pytest.fixture
    def temp_dir(self):
        """Create a temporary directory for testing."""
        # 2025-04-29: Adding fixture for temporary directory to test file operations
        temp_dir = tempfile.mkdtemp()
        yield Path(temp_dir)
        shutil.rmtree(temp_dir)

    def test_get_space_group_dir(self, temp_dir):
        """Test the get_space_group_dir function."""
        # 2025-04-29: Added test to verify space group directory is created with correct structure
        formula = "Li2 O"
        space_group_num = 123

        # Call the function
        result = get_space_group_dir(temp_dir, formula, space_group_num)

        # Check that the path is correct
        expected_path = temp_dir / "Li2O" / "space_group_123"
        assert result == expected_path

        # Check that the directory was created
        assert result.exists()
        assert result.is_dir()

    def test_save_compressed_pickle_dataframe(self, temp_dir):
        """Test save_compressed_pickle with a pandas DataFrame."""
        # 2025-04-29: Added test for saving pandas DataFrame with proper extension
        df = pd.DataFrame({"col1": [1, 2, 3], "col2": ["a", "b", "c"]})
        file_path = temp_dir / "test.pkl"

        # Save the DataFrame
        save_compressed_pickle(df, file_path)

        # Check that the file has the correct extension
        expected_path = temp_dir / "test.pd.xz"
        assert expected_path.exists()

        # Load the file and check contents
        loaded_df = pd.read_pickle(expected_path)
        pd.testing.assert_frame_equal(df, loaded_df)

    def test_save_compressed_pickle_object(self, temp_dir):
        """Test save_compressed_pickle with a regular object."""
        # 2025-04-29: Added test for saving non-DataFrame objects
        test_obj = {"key": "value", "list": [1, 2, 3]}
        file_path = temp_dir / "test.pkl"

        # Save the object
        save_compressed_pickle(test_obj, file_path)

        # Check that the file exists
        assert file_path.exists()

        # Load the file and check contents
        loaded_obj = joblib.load(file_path)
        assert loaded_obj == test_obj

    def test_create_optimization_dirs(self, temp_dir):
        """Test create_optimization_dirs function."""
        # 2025-04-29: Added test to ensure optimization directories are created properly
        space_group_dir = temp_dir / "test_formula" / "space_group_123"
        space_group_dir.mkdir(parents=True)

        # Call the function
        trajectory_dir, logs_dir, cifs_dir = create_optimization_dirs(space_group_dir)

        # Check that the returned paths are correct
        assert trajectory_dir == space_group_dir / "opt_trajectory"
        assert logs_dir == space_group_dir / "opt_logs"
        assert cifs_dir == space_group_dir / "opt_cifs"

        # Check that the directories were created
        assert trajectory_dir.exists() and trajectory_dir.is_dir()
        assert logs_dir.exists() and logs_dir.is_dir()
        assert cifs_dir.exists() and cifs_dir.is_dir()
