# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""
Test module for CLI styling utilities.
"""

import click
import pytest
from click.testing import CliRunner

from shotgun_csp.cli.utils.style import (
    ColoredCommand,
    ColoredGroup,
    style_command,
    style_default,
    style_example,
    style_highlight,
    style_option,
    style_parameter,
    style_path,
    style_value,
)


class TestStyleFunctions:
    """Test class for style helper functions."""

    # 2025-04-29: Added tests for CLI styling utility functions
    def test_style_command(self):
        """Test styling for command names."""
        text = "test-command"
        styled = style_command(text)

        # The styled text should include the original text and be formatted
        assert text in styled
        # Check that styling was applied (should be different from original text)
        assert styled != text
        assert len(styled) > len(text)  # Styling adds escape sequences

    def test_style_option(self):
        """Test styling for option names."""
        text = "--option"
        styled = style_option(text)

        assert text in styled
        # Check that styling was applied
        assert styled != text
        assert len(styled) > len(text)  # Styling adds escape sequences

    def test_style_parameter(self):
        """Test styling for parameter names."""
        text = "param"
        styled = style_parameter(text)

        assert text in styled
        # Check that styling was applied
        assert styled != text
        assert len(styled) > len(text)  # Styling adds escape sequences

    def test_style_value(self):
        """Test styling for values."""
        text = "value"
        styled = style_value(text)

        assert text in styled
        # Check that styling was applied
        assert styled != text
        assert len(styled) > len(text)  # Styling adds escape sequences

    def test_style_highlight(self):
        """Test styling for highlighted text."""
        text = "important"
        styled = style_highlight(text)

        assert text in styled
        # Check that styling was applied
        assert styled != text
        assert len(styled) > len(text)  # Styling adds escape sequences

    def test_style_example(self):
        """Test styling for example text."""
        text = "example usage"
        styled = style_example(text)

        assert text in styled
        # Check that styling was applied
        assert styled != text
        assert len(styled) > len(text)  # Styling adds escape sequences

    def test_style_default(self):
        """Test styling for default values."""
        text = "default"
        styled = style_default(text)

        # Check that the text is prepended with "(default: )"
        assert f"(default: {text})" in styled
        # Check that styling was applied
        assert styled != f"(default: {text})"
        assert len(styled) > len(f"(default: {text})")  # Styling adds escape sequences

    def test_style_path(self):
        """Test styling for file paths."""
        text = "/path/to/file"
        styled = style_path(text)

        assert text in styled
        # Check that styling was applied
        assert styled != text
        assert len(styled) > len(text)  # Styling adds escape sequences


class TestColoredClasses:
    """Test class for ColoredCommand and ColoredGroup."""

    # 2025-04-29: Added tests for custom colored command classes
    @pytest.fixture
    def cli_runner(self):
        """Set up CLI runner for testing commands."""
        return CliRunner()

    def test_colored_command(self, cli_runner):
        """Test that ColoredCommand works correctly."""

        @click.command(cls=ColoredCommand)
        @click.option("--name", help="Your name")
        def hello(name):
            """A simple greeting command."""
            click.echo(f"Hello, {name or 'World'}!")

        result = cli_runner.invoke(hello, ["--help"])
        assert result.exit_code == 0
        assert "A simple greeting command." in result.output
        assert "--name" in result.output

    def test_colored_group(self, cli_runner):
        """Test that ColoredGroup works correctly."""

        @click.group(cls=ColoredGroup)
        def cli():
            """Test command group."""
            pass

        @cli.command()
        def sub():
            """Subcommand."""
            click.echo("Subcommand executed")

        result = cli_runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "Test command group." in result.output
        assert "sub" in result.output

        result = cli_runner.invoke(cli, ["sub"])
        assert result.exit_code == 0
        assert "Subcommand executed" in result.output
