# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""TOML configuration file utilities."""

from pathlib import Path

import numpy as np
import tomli
import tomli_w
from loguru import logger

from shotgun_csp.cli.exceptions import ConfigurationError


def load_toml(file_path):
    """Load a TOML configuration file.

    Args:
        file_path: Path to the TOML file

    Returns:
        Dict containing parsed configuration

    Raises:
        ConfigurationError: If the file cannot be read or parsed
    """
    try:
        with open(file_path, "rb") as f:
            return tomli.load(f)
    except FileNotFoundError:
        raise ConfigurationError(f"Configuration file not found: {file_path}")
    except tomli.TOMLDecodeError as e:
        raise ConfigurationError(f"Error parsing TOML file: {e}")
    except Exception as e:
        raise ConfigurationError(f"Error reading configuration file: {e}")


def _convert_numpy_types(obj):
    """Recursively convert numpy types to native Python types.

    Args:
        obj: Object to convert (can be a dict, list, numpy array, or scalar value)

    Returns:
        Object with numpy types converted to native Python types
    """
    # Handle None values
    if obj is None:
        return ""  # Convert None to empty string for TOML serialization

    # Handle numpy arrays
    if isinstance(obj, np.ndarray):
        return obj.tolist()

    # Handle numpy scalars
    if isinstance(obj, (np.integer, np.int_, np.intc, np.intp, np.int8, np.int16, np.int32, np.int64)):
        return int(obj)
    if isinstance(obj, (np.floating, np.float_, np.float16, np.float32, np.float64)):
        return float(obj)
    if isinstance(obj, np.bool_):  # Use np.bool_ instead of np.bool which is deprecated
        return bool(obj)

    # Handle dictionaries
    if isinstance(obj, dict):
        return {k: _convert_numpy_types(v) for k, v in obj.items()}

    # Handle lists/tuples
    if isinstance(obj, (list, tuple)):
        return [_convert_numpy_types(i) for i in obj]

    # Return unchanged for other types
    return obj


def save_toml(config, file_path):
    """Save a configuration dictionary to a TOML file.

    Args:
        config: Configuration dictionary to save
        file_path: Path where to save the TOML file

    Raises:
        ConfigurationError: If the file cannot be written
    """
    try:
        # Ensure the directory exists
        Path(file_path).parent.mkdir(exist_ok=True, parents=True)

        # Convert numpy types to native Python types before serializing
        cleaned_config = _convert_numpy_types(config)

        with open(file_path, "wb") as f:
            tomli_w.dump(cleaned_config, f)
    except Exception as e:
        # Add more detailed debugging to find problematic values

        def find_none_values(obj, path=""):
            """Recursively find None values in the object structure."""
            if obj is None:
                return [(path, None)]

            results = []
            if isinstance(obj, dict):
                for k, v in obj.items():
                    results.extend(find_none_values(v, f"{path}.{k}" if path else k))
            elif isinstance(obj, (list, tuple)):
                for i, v in enumerate(obj):
                    results.extend(find_none_values(v, f"{path}[{i}]"))
            return results

        # Look for None values in the original config
        none_values = find_none_values(config)
        if none_values:
            logger.error(f"Found None values in config: {none_values}")

        raise ConfigurationError(f"Error writing configuration file: {e}")
