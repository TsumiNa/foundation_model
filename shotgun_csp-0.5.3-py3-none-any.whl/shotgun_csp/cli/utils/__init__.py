# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""Utility functions for the CLI."""

from shotgun_csp.cli.utils.logging import setup_logging
from shotgun_csp.cli.utils.style import (
    ColoredCommand,
    ColoredGroup,
    style_command,
    style_default,
    style_example,
    style_highlight,
    style_option,
    style_parameter,
    style_path,
    style_value,
)
from shotgun_csp.cli.utils.toml_io import load_toml, save_toml

__all__ = [
    "setup_logging",
    "load_toml",
    "save_toml",
    "ColoredCommand",
    "ColoredGroup",
    "style_command",
    "style_default",
    "style_example",
    "style_highlight",
    "style_option",
    "style_parameter",
    "style_path",
    "style_value",
]
