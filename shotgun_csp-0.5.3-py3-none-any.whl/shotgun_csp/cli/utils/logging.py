# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import datetime
import re
import sys
from pathlib import Path
from typing import Optional

from loguru import logger


def setup_logging(output_dir: Optional[str] = None, log_json: bool = False, prefix: str = "csp"):
    """Set up loguru logging configuration.

    Args:
        output_dir: Directory to save log files. If None, logs will only be printed to console.
        log_json: Whether to output logs in JSON format
        prefix: Prefix for log filename. Will be sanitized if it contains invalid characters.
    """
    # Remove default handlers
    logger.remove()

    # Create log file path if output_dir is provided
    log_file = None
    if output_dir is not None:
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True, parents=True)

        # Validate prefix (remove/replace invalid filename characters)
        safe_prefix = re.sub(r'[<>:"/\\|?*]', "_", prefix)
        if safe_prefix != prefix:
            logger.warning(
                f"Prefix '{prefix}' contains invalid filename characters and was sanitized to '{safe_prefix}'"
            )

        # Generate timestamp for filename
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = output_dir / f"{safe_prefix}_task_{timestamp}.log"

    if log_json:
        # JSON format logs
        console_format = '{"time":"{time:YYYY-MM-DD HH:mm:ss}","level":"{level}","message":"{message}"}'
        file_format = (
            '{"time":"{time:YYYY-MM-DD HH:mm:ss}",'
            '"level":"{level}",'
            '"file":"{name}",'
            '"function":"{function}",'
            '"line":"{line}",'
            '"message":"{message}"}'
        )
    else:
        # Modern format with emojis
        emojis = {"INFO": "ℹ️ ", "SUCCESS": "✅ ", "WARNING": "⚠️ ", "ERROR": "❌ ", "DEBUG": "🔍 "}
        # Regular format logs with emojis and modern styling
        console_format = (
            "<bold><blue>{time:YYYY-MM-DD HH:mm:ss}</blue></bold> | "
            "<level>{level: <8}</level> | "
            "{level.icon} <level>{message}</level>"
        )
        file_format = "{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}"

        # Add level icon customization
        for level, emoji in emojis.items():
            logger.level(level, icon=emoji)

    # Add console handler
    logger.add(sys.stderr, format=console_format, level="INFO", colorize=True)

    # Add file handler if output_dir is provided
    if log_file is not None:
        logger.add(log_file, format=file_format, level="DEBUG")
        logger.info(f"Logs will be saved to {log_file}")
    else:
        logger.info("Logging to console only (no log file)")
