# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""
Test module for TOML I/O utilities.
"""

import shutil
import tempfile
from pathlib import Path

import numpy as np
import pytest

from shotgun_csp.cli.exceptions import ConfigurationError
from shotgun_csp.cli.utils.toml_io import _convert_numpy_types, load_toml, save_toml


class TestTomlIO:
    """Test class for TOML I/O utilities."""

    @pytest.fixture
    def temp_dir(self):
        """Create a temporary directory for testing."""
        # 2025-04-29: Adding fixture for temporary directory to test TOML I/O
        temp_dir = tempfile.mkdtemp()
        yield Path(temp_dir)
        shutil.rmtree(temp_dir)

    def test_load_toml_success(self, temp_dir):
        """Test successful loading of a TOML file."""
        # 2025-04-29: Added test for loading valid TOML files
        # Create a sample TOML file
        test_data = {
            "section": {
                "key1": "value1",
                "key2": 123,
                "key3": True,
            },
            "list_section": [1, 2, 3],
        }

        # Instead of manually formatting TOML (which can be error-prone),
        # use tomli_w to generate a valid TOML file from the test data
        import tomli_w

        test_file = temp_dir / "test_config.toml"
        with open(test_file, "wb") as f:
            tomli_w.dump(test_data, f)

        # Load the TOML file
        result = load_toml(test_file)

        # Verify the result
        assert result["section"]["key1"] == "value1"
        assert result["section"]["key2"] == 123
        assert result["section"]["key3"] is True
        assert result["list_section"] == [1, 2, 3]

    def test_load_toml_file_not_found(self):
        """Test load_toml with non-existent file."""
        # 2025-04-29: Added test for file not found error handling
        non_existent_file = Path("non_existent_file.toml")

        with pytest.raises(ConfigurationError) as exc_info:
            load_toml(non_existent_file)

        assert "Configuration file not found" in str(exc_info.value)

    def test_load_toml_parse_error(self, temp_dir):
        """Test load_toml with invalid TOML content."""
        # 2025-04-29: Added test for TOML parsing error handling
        # Create a file with invalid TOML - missing closing bracket on section
        invalid_toml = '[section\nkey1 = "value1"'

        test_file = temp_dir / "invalid.toml"
        with open(test_file, "w") as f:
            f.write(invalid_toml)

        with pytest.raises(ConfigurationError) as exc_info:
            load_toml(test_file)

        assert "Error parsing TOML file" in str(exc_info.value)

    def test_convert_numpy_types_scalars(self):
        """Test conversion of numpy scalar types."""
        # 2025-04-29: Added test for numpy scalar conversion
        # Create a dict with numpy scalar values
        test_data = {
            "int32": np.int32(42),
            "int64": np.int64(9223372036854775807),
            "float32": np.float32(3.14),
            "float64": np.float64(2.71828),
            "bool": np.bool_(True),
        }

        # Convert the data
        result = _convert_numpy_types(test_data)

        # Verify the result
        assert isinstance(result["int32"], int)
        assert result["int32"] == 42

        assert isinstance(result["int64"], int)
        assert result["int64"] == 9223372036854775807

        assert isinstance(result["float32"], float)
        assert pytest.approx(result["float32"]) == 3.14

        assert isinstance(result["float64"], float)
        assert pytest.approx(result["float64"]) == 2.71828

        assert isinstance(result["bool"], bool)
        assert result["bool"] is True

    def test_convert_numpy_types_arrays(self):
        """Test conversion of numpy arrays."""
        # 2025-04-29: Added test for numpy array conversion
        # Create data with numpy arrays
        test_data = {
            "array_1d": np.array([1, 2, 3]),
            "array_2d": np.array([[1, 2], [3, 4]]),
            "mixed_array": np.array([1, 2.5, 3]),
        }

        # Convert the data
        result = _convert_numpy_types(test_data)

        # Verify the result
        assert isinstance(result["array_1d"], list)
        assert result["array_1d"] == [1, 2, 3]

        assert isinstance(result["array_2d"], list)
        assert result["array_2d"] == [[1, 2], [3, 4]]

        assert isinstance(result["mixed_array"], list)
        assert result["mixed_array"] == [1, 2.5, 3]

    def test_convert_numpy_types_nested(self):
        """Test conversion of nested structures with numpy types."""
        # 2025-04-29: Added test for nested structure conversion
        # Create a nested structure with numpy types
        test_data = {
            "level1": {
                "level2": {"array": np.array([1, 2, 3]), "value": np.int64(42)},
                "list": [np.float32(1.1), np.float64(2.2), np.int32(3)],
            }
        }

        # Convert the data
        result = _convert_numpy_types(test_data)

        # Verify the result
        assert isinstance(result["level1"]["level2"]["array"], list)
        assert result["level1"]["level2"]["array"] == [1, 2, 3]

        assert isinstance(result["level1"]["level2"]["value"], int)
        assert result["level1"]["level2"]["value"] == 42

        assert isinstance(result["level1"]["list"], list)
        assert isinstance(result["level1"]["list"][0], float)
        assert isinstance(result["level1"]["list"][1], float)
        assert isinstance(result["level1"]["list"][2], int)
        assert pytest.approx(result["level1"]["list"][0]) == 1.1
        assert pytest.approx(result["level1"]["list"][1]) == 2.2
        assert result["level1"]["list"][2] == 3

    def test_convert_numpy_types_none_value(self):
        """Test conversion of None values."""
        # 2025-04-29: Added test for None value handling
        test_data = {"none_value": None, "list_with_none": [1, None, 3], "nested": {"key": None}}

        # Convert the data
        result = _convert_numpy_types(test_data)

        # Verify the result
        assert result["none_value"] == ""
        assert result["list_with_none"] == [1, "", 3]
        assert result["nested"]["key"] == ""

    def test_save_toml(self, temp_dir):
        """Test saving a configuration to a TOML file."""
        # 2025-04-29: Added test for saving TOML files
        # Create test data
        test_config = {
            "section1": {"string_value": "hello", "int_value": 42, "bool_value": True, "list_value": [1, 2, 3]},
            "section2": {"nested": {"key": "value"}},
        }

        # Save the TOML file
        test_file = temp_dir / "saved_config.toml"
        save_toml(test_config, test_file)

        # Verify the file exists
        assert test_file.exists()

        # Load the file and verify its contents
        loaded_config = load_toml(test_file)
        assert loaded_config["section1"]["string_value"] == "hello"
        assert loaded_config["section1"]["int_value"] == 42
        assert loaded_config["section1"]["bool_value"] is True
        assert loaded_config["section1"]["list_value"] == [1, 2, 3]
        assert loaded_config["section2"]["nested"]["key"] == "value"

    def test_save_toml_with_numpy_types(self, temp_dir):
        """Test saving a configuration with numpy types to a TOML file."""
        # 2025-04-29: Added test for saving with numpy types
        # Create test data with numpy types
        test_config = {
            "numpy_values": {
                "int": np.int32(10),
                "float": np.float64(3.14159),
                "array": np.array([1, 2, 3]),
                "bool": np.bool_(False),
            }
        }

        # Save the TOML file
        test_file = temp_dir / "numpy_config.toml"
        save_toml(test_config, test_file)

        # Verify the file exists
        assert test_file.exists()

        # Load the file and verify its contents
        loaded_config = load_toml(test_file)
        assert loaded_config["numpy_values"]["int"] == 10
        assert pytest.approx(loaded_config["numpy_values"]["float"]) == 3.14159
        assert loaded_config["numpy_values"]["array"] == [1, 2, 3]
        assert loaded_config["numpy_values"]["bool"] is False

    def test_save_toml_create_parent_dirs(self, temp_dir):
        """Test that parent directories are created when saving a TOML file."""
        # 2025-04-29: Added test for parent directory creation
        # Create a path with non-existent parent directories
        test_file = temp_dir / "subdir1" / "subdir2" / "config.toml"

        # Save a simple configuration
        test_config = {"key": "value"}
        save_toml(test_config, test_file)

        # Verify the file and parent directories were created
        assert test_file.exists()
        assert test_file.parent.exists()
        assert test_file.parent.parent.exists()

        # Load the file and verify its contents
        loaded_config = load_toml(test_file)
        assert loaded_config["key"] == "value"
