# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0


import json
import multiprocessing

from loguru import logger
from pymatgen.core import Composition

from shotgun_csp.cli.config_models import CrystalConfig, GeneratorCliConfig
from shotgun_csp.cli.exceptions import ConfigurationError
from shotgun_csp.core import GeneratorArgs
from shotgun_csp.core.utils import predict_proba_of_wyckoff_letters, predict_space_group, predict_volume_of_unit_cell
from shotgun_csp.core.wyckoff import WyckoffCfgGenerator

# Get CPU count for default parallelization
cpu_count = multiprocessing.cpu_count()
default_n_jobs = max(1, cpu_count - 1)


def build_config_from_formula(
    full_formula,
    models_dir,
    space_group=None,
    volume=None,
    wyckoff_priority=None,
    jobs_n=default_n_jobs,
    wyckoff_prediction_n=3000,
    space_group_top_n=30,
    max_attempts=1000,
    wyckoff_mixing_ratio=0.0,
    use_mesh=True,
    perturbation=0.05,
    atomic_dist_decay_rate=0.002,
    check_atomic_dist=False,
):
    """Process a chemical formula to generate configurations.

    Args:
        full_formula: Full chemical formula of the primitive unit cell to be explored
        models_dir: Directory containing prediction models
        space_group: Optional space group number (if not provided, will be predicted)
        volume: Optional unit cell volume (if not provided, will be predicted)
        wyckoff_priority: Optional dictionary of Wyckoff priorities
        jobs_n: Number of parallel jobs
        wyckoff_prediction_n: Number of Wyckoff configurations to generate per space group
        space_group_top_n: Number of top space groups to consider in prediction
        max_attempts: Maximum number of generation attempts (default: 1000)
        wyckoff_mixing_ratio: Ratio to mix wyckoff priorities (0.0-1.0) (default: 0.0)
        use_mesh: Whether to use mesh-based sampling for atomic coordinates (default: True).
                 When True, coordinates are sampled from a set that satisfies atomic distance requirements.
                 When False, coordinates are completely randomly sampled.
        perturbation: Perturbation factor for positions (default: 0.05)
        atomic_dist_decay_rate: Decay rate for atomic distances (default: 0.002)
        check_atomic_dist: Whether to check atomic distances (default: False)

    Returns:
        List[CrystalConfig]: List of crystal configurations.
        - If space_group and wyckoff_priority are provided, or only space_group is provided,
          returns a list with a single CrystalConfig.
        - If neither space_group nor wyckoff_priority is provided, returns a list with
          space_group_top_n CrystalConfig objects, one for each predicted space group.

    Raises:
        ConfigurationError: When the formula is invalid or processing fails
    """
    # Check formula validity
    try:
        comp = Composition(full_formula)
        composition_dict = comp.as_dict()
    except Exception as e:
        raise ConfigurationError(f"Invalid chemical formula: {e}")

    # Initialize generator arguments
    config_args = {
        "full_formula": full_formula,  # Store the original formula
        "max_attempts": max_attempts,
        "wyckoff_mixing_ratio": wyckoff_mixing_ratio,
        "use_mesh": use_mesh,
        "perturbation": perturbation,
        "atomic_dist_decay_rate": atomic_dist_decay_rate,
        "check_atomic_dist": check_atomic_dist,
    }

    # Process volume
    if volume is not None:
        config_args["volume_of_cell"] = volume
        logger.info(f"Using provided volume: {volume} Å³")
    else:
        try:
            logger.info("Predicting unit cell volume...")
            predicted_volume = predict_volume_of_unit_cell(
                [full_formula], pred_model=f"{models_dir}/composition_volume_of_primitive_cell", n_jobs=jobs_n
            )[0]
            # Convert to native Python float
            config_args["volume_of_cell"] = float(predicted_volume)
            logger.success(f"Predicted volume: {predicted_volume:.2f} Å³")
        except Exception as e:
            raise ConfigurationError(f"Failed to predict volume: {e}")

    # Check if wyckoff_priority is provided without space_group (error case)
    if wyckoff_priority is not None and space_group is None:
        raise ConfigurationError(
            "Wyckoff priorities cannot be provided without a space group number. "
            "Wyckoff positions are specific to a particular space group."
        )

    # List to store all generated crystal configurations
    crystal_configs = []

    # Process space group and Wyckoff priorities based on what's provided
    if space_group is not None and wyckoff_priority is not None:
        # Case 1: Both space group and Wyckoff priorities are provided
        # Use both directly without prediction - returns a list with one config
        config_args["space_group_num"] = space_group
        logger.info(f"Using provided space group: {space_group}")

        try:
            wy_priority = wyckoff_priority if isinstance(wyckoff_priority, dict) else json.loads(wyckoff_priority)
            config_args["wy_priority"] = wy_priority
            logger.info("Using provided Wyckoff priorities")
        except json.JSONDecodeError:
            raise ConfigurationError("Invalid JSON format for Wyckoff priorities")

        # Create GeneratorConfig object with validation
        try:
            generator_config = GeneratorCliConfig(**config_args)
        except ValueError as e:
            raise ConfigurationError(f"Invalid generator configuration: {e}")

        # Create GeneratorArgs object for Wyckoff generation
        try:
            args_obj = GeneratorArgs(**config_args)
        except Exception as e:
            raise ConfigurationError(f"Invalid generator arguments: {e}")

        # Generate Wyckoff configurations
        try:
            logger.info(f"Generating {wyckoff_prediction_n} Wyckoff configurations...")
            wyckoff_generator = WyckoffCfgGenerator(args_obj)
            wyckoff_configs = wyckoff_generator(
                composition_dict, expect_size=wyckoff_prediction_n, drop_duplicates=True
            )
            # Check if any valid configurations were generated
            valid_configs = [cfg for cfg in wyckoff_configs if cfg]
            if not valid_configs:
                logger.warning(
                    f"No valid Wyckoff configurations could be generated for space group {space_group}. "
                    f"Skipping this configuration."
                )
                return []

            logger.success(f"Generated {len(valid_configs)} unique Wyckoff configurations 🎉")
            # Create a single CrystalConfig and add it to the list
            crystal_configs.append(CrystalConfig(generator_args=generator_config, wyckoff_cfgs=valid_configs))
        except Exception as e:
            raise ConfigurationError(f"Failed to generate Wyckoff configurations: {e}")

    elif space_group is not None:
        # Case 2: Only space group is provided, predict Wyckoff priorities
        # Returns a list with one config
        config_args["space_group_num"] = space_group
        logger.info(f"Using provided space group: {space_group}")

        try:
            logger.info(f"Predicting Wyckoff letter probabilities for space group {space_group}...")
            prob = predict_proba_of_wyckoff_letters(
                [full_formula],
                space_group_num=space_group,
                pred_model_path=f"{models_dir}/wyckoff_proba",
                n_jobs=jobs_n,
            )
            if isinstance(prob, dict):  # Handle case when no model exists (returns {})
                logger.warning(
                    f"No Wyckoff probability model for space group {space_group}, using default equal probabilities"
                )
                config_args["wy_priority"] = {}  # Explicitly set to empty dict instead of leaving undefined
            elif prob and len(prob) > 0:  # Model exists and returned valid predictions
                config_args["wy_priority"] = prob[0]
                logger.success("✨ Using predicted Wyckoff probabilities")
            else:
                raise ConfigurationError("Failed to predict Wyckoff probabilities")
        except Exception as e:
            raise ConfigurationError(f"Error predicting Wyckoff probabilities: {e}")

        # Create GeneratorConfig object with validation
        try:
            generator_config = GeneratorCliConfig(**config_args)
        except ValueError as e:
            raise ConfigurationError(f"Invalid generator configuration: {e}")

        # Create GeneratorArgs object for Wyckoff generation
        try:
            args_obj = GeneratorArgs(**config_args)
        except Exception as e:
            raise ConfigurationError(f"Invalid generator arguments: {e}")

        # Generate Wyckoff configurations
        try:
            logger.info(f"Generating {wyckoff_prediction_n} Wyckoff configurations...")
            wyckoff_generator = WyckoffCfgGenerator(args_obj)
            wyckoff_configs = wyckoff_generator(
                composition_dict, expect_size=wyckoff_prediction_n, drop_duplicates=True
            )
            # Check if any valid configurations were generated
            valid_configs = [cfg for cfg in wyckoff_configs if cfg]
            if not valid_configs:
                logger.warning(
                    f"No valid Wyckoff configurations could be generated for space group {space_group}. "
                    f"Skipping this configuration."
                )
                return []

            logger.success(f"✨ Generated {len(valid_configs)} unique Wyckoff configurations 🎉")
            # Create a single CrystalConfig and add it to the list
            crystal_configs.append(CrystalConfig(generator_args=generator_config, wyckoff_cfgs=valid_configs))
        except Exception as e:
            raise ConfigurationError(f"Failed to generate Wyckoff configurations: {e}")

    else:
        # Case 3: Neither space group nor Wyckoff priorities are provided
        # Returns a list with space_group_top_n configs (one for each predicted space group)
        try:
            logger.info(f"Predicting space groups (considering top {space_group_top_n})...")

            # predict_space_group output a list contains all the predicted space groups for each formula
            # In our case, the shape of output is (1, space_group_top_n).
            spg_predictions = predict_space_group(
                [full_formula], pred_model=f"{models_dir}/space_group", top=space_group_top_n, n_jobs=jobs_n
            ).flatten()

            logger.success(f"✨ Predicted {len(spg_predictions)} space groups")

            # Process each predicted space group
            for i, spg in enumerate(spg_predictions):
                space_group_num = int(spg)
                logger.info(f"Processing predicted space group #{i + 1}: {space_group_num}")

                # Create a copy of config_args for this specific space group
                spg_config_args = config_args.copy()
                spg_config_args["space_group_num"] = space_group_num
                # full_formula is already included in the copied config_args

                # Now predict Wyckoff priorities based on this predicted space group
                logger.info(f"Predicting Wyckoff letter probabilities for space group {space_group_num}...")
                prob = predict_proba_of_wyckoff_letters(
                    [full_formula],
                    space_group_num=space_group_num,
                    pred_model_path=f"{models_dir}/wyckoff_proba",
                    n_jobs=jobs_n,
                )

                if isinstance(prob, dict):  # Handle case when no model exists (returns {})
                    logger.warning(
                        f"No Wyckoff probability model for space group {space_group_num}, using default equal probabilities"
                    )
                    spg_config_args["wy_priority"] = {}  # Explicitly set to empty dict instead of leaving undefined
                elif prob and len(prob) > 0:  # Model exists and returned valid predictions
                    spg_config_args["wy_priority"] = prob[0]
                    logger.success("✨ Using predicted Wyckoff probabilities")
                else:
                    logger.warning(f"Skipping space group {space_group_num} due to Wyckoff prediction failure")
                    continue

                # Create GeneratorConfig object with validation
                try:
                    generator_config = GeneratorCliConfig(**spg_config_args)
                except ValueError as e:
                    logger.warning(f"Invalid generator configuration for space group {space_group_num}: {e}. Skipping.")
                    continue

                # Create GeneratorArgs object for Wyckoff generation
                try:
                    args_obj = GeneratorArgs(**spg_config_args)
                except Exception as e:
                    logger.warning(f"Invalid generator arguments for space group {space_group_num}: {e}. Skipping.")
                    continue

                # Generate Wyckoff configurations
                try:
                    logger.info(
                        f"Generating {wyckoff_prediction_n} Wyckoff configurations for space group {space_group_num}..."
                    )
                    wyckoff_generator = WyckoffCfgGenerator(args_obj)
                    wyckoff_configs = wyckoff_generator(
                        composition_dict, expect_size=wyckoff_prediction_n, drop_duplicates=True
                    )
                    # Check if any valid configurations were generated
                    valid_configs = [cfg for cfg in wyckoff_configs if cfg]
                    if not valid_configs:
                        logger.warning(
                            f"Failed to generate any valid Wyckoff configurations for space group {space_group_num}. Skipping."
                        )
                        continue
                    logger.success(
                        f"✨ Generated {len(valid_configs)} unique Wyckoff configurations for space group {space_group_num} 🎉"
                    )
                    # Create a CrystalConfig for this space group and add it to the list
                    crystal_configs.append(CrystalConfig(generator_args=generator_config, wyckoff_cfgs=valid_configs))
                except Exception as e:
                    logger.warning(
                        f"Failed to generate Wyckoff configurations for space group {space_group_num}: {e}. Skipping."
                    )
                    continue

            if not crystal_configs:
                raise ConfigurationError("Failed to generate any valid configurations from predicted space groups")

        except Exception as e:
            raise ConfigurationError(f"Failed to predict space group or Wyckoff probabilities: {e}")

    # Return the list of crystal configurations
    return crystal_configs
