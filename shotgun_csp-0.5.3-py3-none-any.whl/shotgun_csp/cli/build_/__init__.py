# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""Build command for generating configuration files."""

from shotgun_csp.cli.build_.command import build_cmd

__all__ = ["build_cmd"]
