# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""Build command for generating configuration files."""

import multiprocessing
from pathlib import Path

import click
from loguru import logger

from shotgun_csp.cli.exceptions import ConfigurationError
from shotgun_csp.cli.utils import save_toml, setup_logging
from shotgun_csp.cli.utils.style import ColoredCommand, style_example, style_highlight, style_path

from .config import build_config_from_formula

# Get CPU count for default parallelization
cpu_count = multiprocessing.cpu_count()
default_n_jobs = max(1, cpu_count - 1)


@click.command(name="build", cls=ColoredCommand)
@click.argument("full_formula", type=str, metavar="FULL_FORMULA")
@click.option(
    "-m",
    "--models",
    type=click.Path(exists=True, file_okay=False, dir_okay=True),
    required=True,
    help="📊 Directory containing prediction models",
)
@click.option(
    "-o",
    "--output-dir",
    type=click.Path(file_okay=False, dir_okay=True),
    default="./csp_configs",
    help=f"📁 Directory for output files (default: {style_path('./csp_configs')})",
)
@click.option(
    "--space-group",
    type=int,
    help="🔢 Directly specify space group number (1-230)",
)
@click.option(
    "--volume",
    type=float,
    help="📏 Directly specify unit cell volume in Å³",
)
@click.option(
    "--wyckoff-priority",
    type=str,
    help="🔠 Directly specify Wyckoff priorities (JSON format, e.g. " + style_example('{"a":0.8,"b":0.2}') + ")",
)
@click.option(
    "--wyckoff-prediction-N",
    type=int,
    default=3000,
    help=f"🧮 Number of Wyckoff configurations to generate (default: {style_highlight('3000')})",
)
@click.option(
    "--space-group-top-N",
    type=int,
    default=30,
    help=f"🔢 Number of top space groups to consider in prediction (default: {style_highlight('30')})",
)
@click.option(
    "--max-attempts",
    type=int,
    default=2000,
    help=f"🔄 Maximum number of generation attempts (default: {style_highlight('2000')})",
)
@click.option(
    "--wyckoff-mixing-ratio",
    type=float,
    default=0.0,
    help=f"🔀 Ratio to mix wyckoff priorities with statistical distribution (0.0-1.0) (default: {style_highlight('0.0')})",
)
@click.option(
    "--coordinate-free",
    is_flag=True,
    default=False,
    help="🔍 Use completely random atomic coordinate sampling instead of mesh-based sampling",
)
@click.option(
    "--perturbation",
    type=float,
    default=0.05,
    help=f"📊 Perturbation factor for positions (default: {style_highlight('0.05')})",
)
@click.option(
    "--atomic-dist-decay-rate",
    type=float,
    default=0.002,
    help=f"📉 Decay rate for atomic distances (default: {style_highlight('0.002')})",
)
@click.option(
    "--check-atomic-dist",
    type=bool,
    default=False,
    help=f"✅ Whether to check atomic distances (default: {style_highlight('False')})",
)
@click.option(
    "--jobs-N",
    type=int,
    default=default_n_jobs,
    help=f"⚡ Number of parallel jobs (default: {style_highlight(str(default_n_jobs))})",
)
@click.option("--log-json", is_flag=True, default=False, help="📋 Output logs in JSON format (default: False)")
def build_cmd(
    full_formula,
    models,
    output_dir,
    space_group,
    volume,
    wyckoff_priority,
    wyckoff_prediction_n,
    space_group_top_n,
    max_attempts,
    wyckoff_mixing_ratio,
    coordinate_free,
    perturbation,
    atomic_dist_decay_rate,
    check_atomic_dist,
    jobs_n,
    log_json,
):
    """💎 Build configuration file for crystal structure prediction.

    This command builds a configuration file for the specified full formula
    of the primitive unit cell to be explored. The configuration can then
    be used with the generate command to create crystal structures.

    Example:
        {example}
    """.format(
        example=style_example('scp build "Na Cl" -m ./models -o ./configs  # Full formula of the primitive unit cell')
    )
    try:
        # Setup logging
        setup_logging(output_dir, log_json, "build")
        logger.info(f"Starting configuration build for {full_formula} 🚀")

        # Process the formula - now returns a list of configurations
        configs = build_config_from_formula(
            full_formula=full_formula,
            models_dir=models,
            space_group=space_group,
            volume=volume,
            wyckoff_priority=wyckoff_priority,
            jobs_n=jobs_n,
            wyckoff_prediction_n=wyckoff_prediction_n,
            space_group_top_n=space_group_top_n,
            max_attempts=max_attempts,
            wyckoff_mixing_ratio=wyckoff_mixing_ratio,
            use_mesh=not coordinate_free,
            perturbation=perturbation,
            atomic_dist_decay_rate=atomic_dist_decay_rate,
            check_atomic_dist=check_atomic_dist,
        )

        # Save configurations to files
        output_dir_path = Path(output_dir)
        output_dir_path.mkdir(exist_ok=True, parents=True)

        # Clean formula for filename
        clean_formula = full_formula.replace(" ", "")

        # Save each configuration to a separate file
        logger.info(f"Saving {len(configs)} configuration(s) to {output_dir_path}")

        for i, config in enumerate(configs):
            # Convert CrystalConfig to dictionary
            config_dict = config.model_dump()

            # Always include space group number in filename
            space_group_num = config.generator_args.space_group_num
            output_file = output_dir_path / f"{clean_formula}_spg{space_group_num}_config.toml"

            # Save to TOML
            save_toml(config_dict, output_file)
            logger.success(f"Configuration #{i + 1} saved to {output_file} 📁")
        return 0

    except ConfigurationError as e:
        logger.error(f"Configuration error: {e}")
        return 1
    except Exception as e:
        logger.exception(f"Unexpected error: {e}")
        return 2
