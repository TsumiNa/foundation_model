# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""Configuration models for crystal structure prediction."""

from typing import Dict, List, Optional

from pydantic import BaseModel, Field, model_validator

from shotgun_csp.cli.exceptions import ConfigurationError
from shotgun_csp.core.utils import WY


class GeneratorCliConfig(BaseModel):
    """
    Configuration model for crystal generation parameters.

    This model is used to store and validate crystal generation parameters for configuration files,
    excluding computed properties that will be recalculated by the GeneratorArgs class when needed.

    Attributes:
        full_formula (str): Original chemical formula used for configuration generation
        volume_of_cell (float): Volume of the crystal cell (must be > 10)
        space_group_num (int): Space group number (1-230)
        max_angle_degree (float): Maximum allowed angle in degrees (default: 150.0)
        min_angle_degree (float): Minimum allowed angle in degrees (default: 20.0)
        max_attempts (int): Maximum number of generation attempts (default: 1000)
        decimals (int): Number of decimal places for rounding (default: 7)
        variance_of_volume (float): Allowed volume variance (default: volume_of_cell * 0.1)
        low_length (float): Minimum cell length
        high_length (float): Maximum cell length
        wy_priority (Dict[str, float]): Wyckoff position priorities
        wyckoff_mixing_ratio (float): Ratio to mix between wy_priority and avg_wyckoff_distribution values.
    """

    full_formula: Optional[str] = None
    volume_of_cell: float
    space_group_num: int
    max_angle_degree: float = 150.0
    min_angle_degree: float = 20.0
    max_attempts: int = 1_000
    decimals: int = 7
    wyckoff_mixing_ratio: float = 0.0
    use_mesh: bool = True
    perturbation: float = 0.05
    atomic_dist_decay_rate: float = 0.002
    check_atomic_dist: bool = False
    structure_matcher_params: Dict[str, float] = Field(default_factory=lambda: {"ltol": 0.05, "angle_tol": 3})
    variance_of_volume: Optional[float] = None
    low_length: Optional[float] = None
    high_length: Optional[float] = None
    wy_priority: Optional[Dict[str, float]] = None

    @model_validator(mode="after")
    def validate_and_set_defaults(self) -> "GeneratorCliConfig":
        """Validate and set default values for the configuration."""
        # Validate volume_of_cell
        if self.volume_of_cell < 10:
            raise ConfigurationError("volume_of_cell must be greater than 10")

        # Set default variance_of_volume
        if self.variance_of_volume is None:
            self.variance_of_volume = self.volume_of_cell * 0.1

        # Set default low_length and high_length
        if self.low_length is None:
            self.low_length = self.volume_of_cell ** (1 / 3) * 0.5
        if self.high_length is None:
            self.high_length = self.volume_of_cell ** (1 / 3) * 1.5

        # Validate other parameters
        if self.max_attempts < 100:
            raise ConfigurationError("max_attempts must be greater than 100")
        if not (1 <= self.space_group_num <= 230):
            raise ConfigurationError(f"Space group must be between 1 and 230, got {self.space_group_num}")
        if self.variance_of_volume < 0 or self.variance_of_volume > self.volume_of_cell / 4:
            raise ConfigurationError("variance_of_volume must be between 0 and volume_of_cell / 4")
        if self.min_angle_degree < 10.0 or self.max_angle_degree > 170.0:
            raise ConfigurationError("angle_degree must be between 10 and 170")
        if self.min_angle_degree >= self.max_angle_degree:
            raise ConfigurationError("min_angle_degree must be less than max_angle_degree")
        if not (0.0 <= self.wyckoff_mixing_ratio <= 1.0):
            raise ConfigurationError("wyckoff_mixing_ratio must be between 0.0 and 1.0")

        # Process wy_priority if provided
        if self.wy_priority and self.space_group_num:
            wyckoff_data = WY[self.space_group_num - 1]
            # Validate that all keys in wy_priority exist in wyckoff_data
            invalid_keys = [key for key in self.wy_priority if key not in wyckoff_data]
            if invalid_keys:
                raise ConfigurationError(
                    f"Invalid Wyckoff positions in wy_priority for space group "
                    f"{self.space_group_num}: {', '.join(invalid_keys)}"
                )

        return self


class CrystalConfig(BaseModel):
    """
    Top-level configuration model for crystal structure prediction.

    This model represents the complete configuration for crystal structure prediction,
    containing both generator arguments and Wyckoff configurations.

    Attributes:
        generator_args (GeneratorConfig): Generator configuration parameters
        wyckoff_cfgs (List[Dict[str, List[str]]]): List of Wyckoff configurations,
            where each configuration is a dictionary mapping element symbols to lists
            of Wyckoff letters.
    """

    generator_args: GeneratorCliConfig
    wyckoff_cfgs: List[Dict[str, List[str]]]
