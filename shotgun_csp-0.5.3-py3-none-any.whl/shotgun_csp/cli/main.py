#!/usr/bin/env python3
# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""Main entry point for shotgun_csp CLI."""

import click

from shotgun_csp.cli.build_ import build_cmd
from shotgun_csp.cli.generate import generate_cmd
from shotgun_csp.cli.utils.style import ColoredGroup


@click.group(cls=ColoredGroup)
def cli():
    """🔮 Crystal Structure Prediction tools."""
    pass


# Register commands
cli.add_command(build_cmd)
cli.add_command(generate_cmd)


def main():
    """CLI entry point"""
    cli()


if __name__ == "__main__":
    main()
