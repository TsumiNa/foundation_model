# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""Generate command for creating crystal structures from configuration."""

from shotgun_csp.cli.generate.command import generate_cmd

__all__ = ["generate_cmd"]
