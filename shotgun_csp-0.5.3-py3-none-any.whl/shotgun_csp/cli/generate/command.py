# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

"""Generate command for creating crystal structures from configuration files."""

import multiprocessing
import warnings
from pathlib import Path

import click
from loguru import logger

from shotgun_csp.cli.exceptions import ConfigurationError, GenerationError
from shotgun_csp.cli.utils import setup_logging
from shotgun_csp.cli.utils.style import ColoredCommand, style_example, style_highlight, style_path

from .process_config import process_config

# Suppress the pkg_resources deprecation warning from mattersim
warnings.filterwarnings("ignore", message="pkg_resources is deprecated as an API")

# Get CPU count for default parallelization
cpu_count = multiprocessing.cpu_count()
default_n_jobs = max(1, cpu_count - 1)


@click.command(name="generate", cls=ColoredCommand)
@click.argument("config_file", type=click.Path(exists=True, file_okay=True, dir_okay=False))
@click.option(
    "-n",
    "--structure-N",
    type=int,
    default=10,
    help=f"💎 Number of structures to generate (default: {style_highlight('10')})",
)
@click.option(
    "--optimize-N",
    type=int,
    default=0,
    help=f"🧪 Number of structures to optimize (default: {style_highlight('0')}, no optimization)",
)
@click.option(
    "-o",
    "--output-dir",
    type=click.Path(file_okay=False, dir_okay=True),
    help="📁 Directory for output files (default: " + style_path("{config_file_dir}/{config_name}_generations") + ")",
)
@click.option(
    "--jobs-N",
    type=int,
    default=default_n_jobs,
    help=f"⚡ Number of parallel jobs (default: {style_highlight(str(default_n_jobs))})",
)
@click.option("--log-json", is_flag=True, default=False, help="📋 Output logs in JSON format (default: False)")
@click.option(
    "--coordinate-free",
    is_flag=True,
    default=False,
    help="🔍 Use completely random atomic coordinate sampling instead of mesh-based sampling",
)
@click.option(
    "--save-cif",
    is_flag=True,
    default=False,
    help="💾 Save generated structures as CIF files (default: False)",
)
@click.option(
    "--device",
    type=str,
    default="cpu",
    help=f"🖥️ Device to run calculations on (default: {style_highlight('cpu')})",
)
def generate_cmd(config_file, structure_n, optimize_n, output_dir, jobs_n, log_json, coordinate_free, save_cif, device):
    """💎 Generate crystal structures from a configuration file.

    This command generates crystal structures using a configuration file previously
    created with the 'build' command.

    Example:
        {example}
    """.format(example=style_example("scp generate path/to/config.toml --structure-N 20 --optimize-N 5"))
    try:
        # Determine output directory
        config_path = Path(config_file)
        if output_dir is None:
            config_name = config_path.stem
            output_dir = config_path.parent / f"{config_name}_generations"

        # Setup logging
        setup_logging(output_dir, log_json, "generate")
        logger.info(f"Starting crystal structure generation using {config_file} 🚀")

        # Process the configuration
        structures, out_dir = process_config(
            config_path=config_file,
            structure_n=structure_n,
            optimize_n=optimize_n,
            jobs_n=jobs_n,
            coordinate_free=coordinate_free,
            save_cif=save_cif,
            device=device,
            output_dir=output_dir,
        )

        # Report results
        if len(structures) == 0:
            logger.warning("No structures were generated")
        else:
            logger.success(f"Successfully generated {len(structures)} structures 🎉")
            logger.info(f"Results are saved in {out_dir} 📁")

        return 0

    except ConfigurationError as e:
        logger.error(f"Configuration error: {e}")
        return 1
    except GenerationError as e:
        logger.error(f"Generation error: {e}")
        return 2
    except Exception as e:
        logger.exception(f"Unexpected error: {e}")
        return 3
