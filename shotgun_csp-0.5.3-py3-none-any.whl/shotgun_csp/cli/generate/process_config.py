# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import multiprocessing
import shutil
import warnings
from pathlib import Path
from typing import List

import joblib
from loguru import logger
from pymatgen.io.ase import AseAtomsAdaptor

from shotgun_csp.cli.exceptions import ConfigurationError, GenerationError
from shotgun_csp.cli.utils import load_toml
from shotgun_csp.core import GeneratorArgs
from shotgun_csp.core.utils.structure_optimizer import StructureOptimizer
from shotgun_csp.core.wyckoff import CrystalGenerator
from shotgun_csp.core.wyckoff.structure import CrystalStructure

# Suppress the pkg_resources deprecation warning from mattersim
warnings.filterwarnings("ignore", message="pkg_resources is deprecated as an API")

# Get CPU count for default parallelization
cpu_count = multiprocessing.cpu_count()
default_n_jobs = max(1, cpu_count - 1)


def process_config(
    config_path,
    structure_n=10,
    optimize_n=0,
    jobs_n=default_n_jobs,
    coordinate_free=False,
    save_cif=False,
    device="cpu",
    output_dir=None,
    **kwargs,
):
    """Process a configuration file to generate crystal structures.

    Args:
        config_path: Path to the configuration file
        structure_n: Number of structures to generate
        optimize_n: Number of structures to optimize (0 for no optimization)
        jobs_n: Number of parallel jobs
        coordinate_free: Whether to use completely random atomic coordinate sampling
        save_cif: Whether to save structures as CIF files
        device: Device to run calculations on (cpu or cuda)

    Returns:
        Tuple[list, Path]: List of generated structures and output directory

    Raises:
        ConfigurationError: When the config is invalid
        GenerationError: When structure generation fails
    """
    # Load configuration
    try:
        config = load_toml(config_path)
    except ConfigurationError as e:
        raise ConfigurationError(f"Failed to load configuration: {e}")

    # Extract generator arguments
    try:
        generator_args = config.get("generator_args")
        if not generator_args:
            raise ConfigurationError("Missing generator_args in configuration")

        wyckoff_cfgs = config.get("wyckoff_cfgs")
        if not wyckoff_cfgs or not isinstance(wyckoff_cfgs, list) or len(wyckoff_cfgs) == 0:
            raise ConfigurationError("Missing or empty wyckoff_cfgs in configuration")

        # Create GeneratorArgs object
        args_obj = GeneratorArgs(**generator_args)
    except Exception as e:
        raise ConfigurationError(f"Invalid configuration format: {e}")

    # Set up the output directory
    config_path = Path(config_path)
    config_name = config_path.stem

    # Use the provided output_dir if it exists, otherwise create the default one
    if output_dir is None:
        output_dir = config_path.parent / f"{config_name}_generations"
    else:
        output_dir = Path(output_dir) / f"{config_name}_generations"

    output_dir.mkdir(exist_ok=True, parents=True)

    # Copy the config file to output directory with a standardized name
    shutil.copy2(config_path, output_dir / "generation_config.toml")
    logger.info(f"Copied configuration file to {output_dir / 'generation_config.toml'}")

    # Generate structures
    try:
        n_wyckoff_cfgs = len(wyckoff_cfgs)
        n_per_wyckoff = round(structure_n / n_wyckoff_cfgs)
        if n_per_wyckoff < 1:
            n_per_wyckoff = 1

        logger.info(
            f"💎 Trying to generate {n_per_wyckoff * n_wyckoff_cfgs} crystal structures "
            f"for {n_wyckoff_cfgs} configurations..."
        )

        # Create crystal generator
        crystal_generator = CrystalGenerator(args_obj)

        # Generate structures
        structures: List[CrystalStructure] = crystal_generator(
            *wyckoff_cfgs,  # Pass all Wyckoff configurations
            expect_size=structure_n,
            use_mesh=not coordinate_free,
            return_crystal_structures=True,
            n_jobs=jobs_n,
            progress_bar=True,
        )

        logger.success(f"Generated {len(structures)} crystal structures")
    except Exception as e:
        raise GenerationError(f"Failed to generate structures: {e}")

    # Save structures as dictionaries using joblib
    structures_dicts = [s.to_dict() for s in structures]
    structures_pkl_path = output_dir / "generated_structures.pkl.z"
    joblib.dump(structures_dicts, structures_pkl_path)
    logger.success(f"Saved structures dictionary to {structures_pkl_path}")

    # Process structure evaluation and optimization
    if len(structures) > 0:
        try:
            # Get ASE atoms from structures
            logger.info("🔄 Preparing structures for evaluation...")
            ase_structures = []
            for structure in structures:
                try:
                    ase_structures.append(structure.ase_atoms)
                except Exception as e:
                    logger.warning(f"⚠️ Failed to get ASE atoms from structure: {e}")

            if ase_structures:
                # Determine whether to evaluate only or optimize
                eval_only = optimize_n <= 0
                only_top_n = None if eval_only else optimize_n

                # Create directories for output files
                cifs_dir = output_dir / "cifs" if save_cif else None
                if save_cif:
                    cifs_dir.mkdir(exist_ok=True)

                # Create directories for optimization files if needed
                trajectory_dir = None
                log_dir = None
                if not eval_only:
                    trajectory_dir = output_dir / "trajectories"
                    log_dir = output_dir / "logs"
                    trajectory_dir.mkdir(exist_ok=True)
                    log_dir.mkdir(exist_ok=True)

                # Initialize StructureOptimizer
                optimizer = StructureOptimizer(
                    device=device,
                    save_trajectory=str(trajectory_dir) if trajectory_dir else None,
                    logfile=str(log_dir) if log_dir else None,
                    save_cif=str(cifs_dir) if save_cif else None,
                    group_output_files_by_formula=False,
                    logging=True,
                )

                # Run evaluation or optimization
                optimized_structures, summary_df = optimizer(
                    *ase_structures,
                    eval_only=eval_only,
                    only_top_n=only_top_n,
                    show_progress=True,
                    n_jobs=jobs_n,
                )

                # Save evaluation or optimization summary
                if summary_df is not None:
                    output_prefix = "evaluation_summary" if eval_only else "optimization_summary"
                    csv_path = output_dir / f"{output_prefix}.csv"
                    pd_path = output_dir / f"{output_prefix}.pd.xz"

                    summary_df.to_csv(csv_path, index=False)
                    summary_df.to_pickle(pd_path, compression="xz")

                    logger.success(
                        f"📊 Saved {'evaluation' if eval_only else 'optimization'} summary to {csv_path} and {pd_path}"
                    )

                # If optimization was performed, save optimized structures
                if not eval_only and optimized_structures and summary_df is not None:
                    # Get successfully optimized structures
                    successful_df = summary_df[summary_df["Converged (final)"] == True]

                    if not successful_df.empty:
                        # Create results list for optimized structures
                        optimized_results = []

                        for _, row in successful_df.iterrows():
                            try:
                                # Get the row index in the DataFrame and the original structure index
                                df_index = row.name
                                orig_idx = int(row["index"])

                                # Ensure index is valid
                                if df_index < len(optimized_structures):
                                    # Get optimized structure and convert to pymatgen Structure
                                    optimized_ase = optimized_structures[df_index]
                                    pymatgen_structure = AseAtomsAdaptor.get_structure(optimized_ase)

                                    # Save structure with metadata
                                    optimized_results.append(
                                        {
                                            "structure": pymatgen_structure.as_dict(),
                                            "original_index": orig_idx,
                                            "formula": pymatgen_structure.composition.reduced_formula,
                                        }
                                    )
                            except Exception as e:
                                logger.warning(
                                    f"⚠️ Failed to process optimized structure with original index {orig_idx}: {e}"
                                )

                        # Save optimized structures
                        if optimized_results:
                            optimized_pkl_path = output_dir / "optimized_structures.pkl.z"
                            joblib.dump(optimized_results, optimized_pkl_path)
                            logger.success(
                                f"💾 Saved {len(optimized_results)} optimized structures dictionary to {optimized_pkl_path}"
                            )
                            logger.info(
                                f"Optimized structures include original indices: {[r['original_index'] for r in optimized_results]}"
                            )

        except Exception as e:
            logger.warning(f"⚠️ Failed to {'evaluate' if optimize_n <= 0 else 'optimize'} structures: {e}")

    return structures, output_dir
