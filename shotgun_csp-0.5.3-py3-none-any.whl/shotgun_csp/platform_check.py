# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import argparse
import platform
import struct
import sys
import time

# Flag to track if platform check has already been performed
_PLATFORM_CHECK_DONE = False


def is_wsl() -> bool:
    """Detect if running inside Windows Subsystem for Linux."""
    if platform.system() != "Linux":
        return False
    try:
        with open("/proc/version", "r") as f:
            return "microsoft" in f.read().lower()
    except FileNotFoundError:
        return False


def color(text: str, code: str, enable: bool) -> str:
    if enable:
        return f"\033[{code}m{text}\033[0m"
    return text


def emoji(msg: str, enable: bool) -> str:
    return f"✨ {msg} ✨" if enable else msg


def get_diagnose_info():
    return {
        "System": platform.system(),
        "Machine": platform.machine(),
        "Processor": platform.processor(),
        "Arch Bits": f"{struct.calcsize('P') * 8}-bit",
        "Python Version": platform.python_version(),
    }


def print_diagnose(enable_color=True, enable_emoji=True):
    print(color(emoji("System Diagnostics", enable_emoji), "36;1", enable_color))
    info = get_diagnose_info()
    for k, v in info.items():
        print(f" - {k}: {v}")


def check_platform(verbose=False, quiet=True, force_no_color=False, force_check=False):
    """
    Check if the current platform is supported.

    Args:
        verbose (bool): Show system diagnostics
        quiet (bool): Suppress all output messages
        force_no_color (bool): Disable colored output
        force_check (bool): Force check even if already done

    Returns:
        bool: True if platform is supported, False otherwise
    """
    global _PLATFORM_CHECK_DONE

    # Skip check if already done and not forced
    if _PLATFORM_CHECK_DONE and not force_check:
        return True

    # Mark as done
    _PLATFORM_CHECK_DONE = True

    system = platform.system()
    machine = platform.machine()
    is_64bits = struct.calcsize("P") * 8 == 64
    is_tty = sys.stdout.isatty() and not force_no_color
    enable_emoji = is_tty

    allowed = False
    reason = ""

    if system == "Darwin":
        if machine in ("arm64", "aarch64") and is_64bits:
            allowed = True
            arch = "macOS (Apple Silicon)"
        else:
            reason = "Intel-based macOS is not supported."
            arch = "macOS (Intel)"
    elif system == "Linux":
        if is_wsl():
            allowed = True
            arch = "WSL (Windows Subsystem for Linux)"
        elif machine == "x86_64" and is_64bits:
            allowed = True
            arch = "Linux (x86_64)"
        else:
            reason = "Only 64-bit x86_64 Linux or WSL is supported."
            arch = f"Linux ({machine})"
    else:
        reason = "Unsupported operating system."
        arch = f"{system} ({machine})"

    if verbose:
        print_diagnose(enable_color=is_tty, enable_emoji=enable_emoji)

    if not allowed:
        if not quiet:
            print(color("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓", "31", is_tty))
            print(color("┃ 🚫 Platform Not Supported 🚫 ┃", "31;1", is_tty))
            print(color("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛", "31", is_tty))
            print(f" Detected: {arch}")
            print(f" Reason: {reason}")
            print(color(" Allowed platforms:", "33", is_tty))
            print(color("   ✅ macOS (Apple Silicon)", "32", is_tty))
            print(color("   ✅ 64-bit Linux (x86_64)", "32", is_tty))
            print(color("   ✅ Windows Subsystem for Linux (WSL)", "32", is_tty))
            print(color("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", "31", is_tty))
            if enable_emoji:
                time.sleep(0.5)
                print(color("💀 Bye Bye~ 💀", "31;1", is_tty))
        if not verbose and not force_check:  # Only exit if not in verbose mode or forced check
            sys.exit(1)
        return False

    if not quiet:
        print(color("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓", "32", is_tty))
        print(color("┃ ✅ Platform Check Passed ✅ ┃", "32;1", is_tty))
        print(color("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛", "32", is_tty))
        print(f" Detected: {arch}")
        print(color("━━━━━━━━━━━━━━━━━━━━━━━━━━━━", "32", is_tty))
        if enable_emoji:
            print("🎉 All Clear, Let's Rock!")

    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="💎 Cross-Platform Guard")
    parser.add_argument("--check-platform", action="store_true", help="Check platform compatibility only")
    parser.add_argument("--no-color", action="store_true", help="Disable colored output")
    parser.add_argument("--quiet", action="store_true", help="Silent mode for CI/logs")
    parser.add_argument("--verbose", action="store_true", help="Show system diagnostics")
    args = parser.parse_args()

    if args.check_platform or args.verbose:
        check_platform(verbose=args.verbose, quiet=args.quiet, force_no_color=args.no_color)
        if args.check_platform:
            sys.exit(0)
    else:
        check_platform()
        print("🚀 Starting your actual application...")
