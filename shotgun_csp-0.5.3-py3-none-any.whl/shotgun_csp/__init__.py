# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0


from .platform_check import check_platform

__version__ = "0.5.3"

# Run platform check silently on import
check_platform(quiet=True)
