# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0


import numpy as np
import pytest

from shotgun_csp.core import GeneratorArgs
from shotgun_csp.core.exception import GenerationError


def test_lattice_generator_args_validation():
    """Test LatticeGeneratorArgs validation rules."""
    # Test invalid volume_of_cell
    with pytest.raises(GenerationError, match="volume_of_cell must be greater than 10"):
        GeneratorArgs(volume_of_cell=5.0, space_group_num=1)

    # Test invalid max_attempts
    with pytest.raises(GenerationError, match="max_attempts must be greater than 100"):
        GeneratorArgs(volume_of_cell=100.0, space_group_num=1, max_attempts=0)

    # Test invalid space_group_num
    with pytest.raises(GenerationError, match="Space group must be between 1 and 230, got 0"):
        GeneratorArgs(volume_of_cell=100.0, space_group_num=0)
    with pytest.raises(GenerationError, match="Space group must be between 1 and 230, got 231"):
        GeneratorArgs(volume_of_cell=100.0, space_group_num=231)

    # Test invalid variance_of_volume
    with pytest.raises(GenerationError, match="variance_of_volume must be between 0 and volume_of_cell / 4"):
        GeneratorArgs(volume_of_cell=100.0, space_group_num=1, variance_of_volume=-1)
    with pytest.raises(GenerationError, match="variance_of_volume must be between 0 and volume_of_cell / 4"):
        GeneratorArgs(volume_of_cell=100.0, space_group_num=1, variance_of_volume=26)

    # Test invalid angle_degree
    with pytest.raises(GenerationError, match="angle_degree must be between 10 and 150"):
        GeneratorArgs(volume_of_cell=100.0, space_group_num=1, min_angle_degree=5, max_angle_degree=90)
    with pytest.raises(GenerationError, match="angle_degree must be between 10 and 150"):
        GeneratorArgs(volume_of_cell=100.0, space_group_num=1, min_angle_degree=15, max_angle_degree=175)

    # Test invalid min_angle_degree > max_angle_degree
    with pytest.raises(GenerationError, match="min_angle_degree must be greater than max_angle_degree"):
        GeneratorArgs(volume_of_cell=100.0, space_group_num=1, min_angle_degree=50, max_angle_degree=40)

    # Test invalid wyckoff_mixing_ratio
    with pytest.raises(GenerationError, match="wyckoff_mixing_ratio must be between 0.0 and 1.0"):
        GeneratorArgs(volume_of_cell=100.0, space_group_num=1, wyckoff_mixing_ratio=-0.1)
    with pytest.raises(GenerationError, match="wyckoff_mixing_ratio must be between 0.0 and 1.0"):
        GeneratorArgs(volume_of_cell=100.0, space_group_num=1, wyckoff_mixing_ratio=1.1)


def test_lattice_generator_args_defaults():
    """Test LatticeGeneratorArgs default values."""
    args = GeneratorArgs(volume_of_cell=100.0, space_group_num=1)

    assert args.variance_of_volume == 10.0
    assert args.max_angle_degree == 150.0
    assert args.min_angle_degree == 20.0
    assert args.low_length == 100.0 ** (1 / 3) * 0.4
    assert args.high_length == 100.0 ** (1 / 3) * 1.6
    assert args.wyckoff_mixing_ratio == 0.0  # Default wyckoff_mixing_ratio is 0.0
    # Test the new parameters
    assert args.use_mesh is False
    assert args.perturbation == 0.0
    assert args.atomic_dist_decay_rate == 0.002
    assert args.check_atomic_dist is False


def test_lattice_generator_args_scale():
    """Test LatticeGeneratorArgs scale property."""
    # Test primitive spacegroup (scale=1)
    args_primitive = GeneratorArgs(volume_of_cell=100.0, space_group_num=1)
    assert args_primitive.scale == 1

    # Test body-centered spacegroup (scale=2)
    args_body_centered = GeneratorArgs(volume_of_cell=50.0, space_group_num=217)  # I-43m
    assert args_body_centered.scale == 2

    # Test face-centered spacegroup (scale=4)
    args_face_centered = GeneratorArgs(volume_of_cell=25.0, space_group_num=225)  # Fm-3m
    assert args_face_centered.scale == 4


def test_lattice_generator_args_identical_sites():
    """Test LatticeGeneratorArgs identical_sites property."""
    # Test primitive spacegroup (no identical sites)
    args_primitive = GeneratorArgs(volume_of_cell=100.0, space_group_num=1)
    assert len(args_primitive.identical_sites) == 0

    # Test C-centered spacegroup
    args_c_centered = GeneratorArgs(volume_of_cell=100.0, space_group_num=15)  # C2/c
    assert np.allclose(args_c_centered.identical_sites, np.array([[1 / 2, 1 / 2, 0]]))

    # Test I-centered spacegroup
    args_i_centered = GeneratorArgs(volume_of_cell=50.0, space_group_num=44)  # Imm2
    assert np.allclose(args_i_centered.identical_sites, np.array([[1 / 2, 1 / 2, 1 / 2]]))

    # Test F-centered spacegroup
    args_face_centered = GeneratorArgs(volume_of_cell=25.0, space_group_num=225)  # Fm-3m
    assert np.allclose(
        args_face_centered.identical_sites, np.array([[0, 1 / 2, 1 / 2], [1 / 2, 0, 1 / 2], [1 / 2, 1 / 2, 0]])
    )


def test_wyckoff_data_property():
    """Test GeneratorArgs wyckoff_data property."""
    # Test for space group P1 (SG 1)
    args_p1 = GeneratorArgs(volume_of_cell=100.0, space_group_num=1)
    wy_data_p1 = args_p1.wyckoff_data
    assert "a" in wy_data_p1
    assert wy_data_p1["a"][0] == 1  # multiplicity
    assert wy_data_p1["a"][1] is True  # reuse

    # Test for space group Fm-3m (SG 225)
    args_fm3m = GeneratorArgs(volume_of_cell=100.0, space_group_num=225)
    wy_data_fm3m = args_fm3m.wyckoff_data
    assert "a" in wy_data_fm3m
    assert "b" in wy_data_fm3m
    assert "c" in wy_data_fm3m
    assert "d" in wy_data_fm3m
    assert wy_data_fm3m["a"][0] == 4  # multiplicity for Wyckoff position 'a'
    assert wy_data_fm3m["b"][0] == 4  # multiplicity for Wyckoff position 'b'


def test_candidate_pool_property():
    """Test GeneratorArgs candidate_pool property."""
    # Test with default wy_priority (all set to 1.0)
    args = GeneratorArgs(volume_of_cell=100.0, space_group_num=1)
    pool = args.candidate_pool

    # Check pool structure
    assert len(pool) > 0
    for item in pool:
        assert len(item) == 4  # (multiplicity, letter, reuse, probability)
        assert isinstance(item[0], int)  # multiplicity
        assert isinstance(item[1], str)  # letter
        assert isinstance(item[2], bool)  # reuse
        assert item[3] == 1.0  # default probability

    # Test with custom wy_priority
    custom_priority = {"a": 2.0, "b": 0.5}
    args_custom = GeneratorArgs(volume_of_cell=100.0, space_group_num=8, wy_priority=custom_priority)
    pool_custom = args_custom.candidate_pool

    # Find items in pool with letters 'a' and 'b'
    a_item = next((item for item in pool_custom if item[1] == "a"), None)
    b_item = next((item for item in pool_custom if item[1] == "b"), None)

    assert a_item is not None
    assert b_item is not None
    assert a_item[3] == 2.0  # custom probability for 'a'
    assert b_item[3] == 0.5  # custom probability for 'b'

    # Check that other letters have default probability of 0.0
    c_item = next((item for item in pool_custom if item[1] not in ("a", "b")), None)
    if c_item:
        assert c_item[3] == 0.0


def test_wyckoff_mixing_ratio():
    """Test wyckoff_mixing_ratio parameter effect on candidate_pool."""
    # Test with default wyckoff_mixing_ratio (0.0)
    args_default = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=5,  # Use a space group with avg_wyckoff_distribution
        wy_priority={"a": 0.8, "b": 0.2},
    )

    # Verify default value
    assert args_default.wyckoff_mixing_ratio == 0.0

    # With default ratio=0.0, the probabilities should match wy_priority exactly
    pool_default = args_default.candidate_pool
    a_item_default = next((item for item in pool_default if item[1] == "a"), None)
    b_item_default = next((item for item in pool_default if item[1] == "b"), None)

    assert a_item_default is not None
    assert b_item_default is not None
    assert a_item_default[3] == 0.8
    assert b_item_default[3] == 0.2

    # Test with wyckoff_mixing_ratio=1.0 (fully use avg_wyckoff_distribution)
    args_mixed = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=5,  # Same space group
        wy_priority={"a": 0.8, "b": 0.2},
        wyckoff_mixing_ratio=1.0,
    )

    # With ratio=1.0, the probabilities should be derived from avg_wyckoff_distribution
    pool_mixed = args_mixed.candidate_pool
    a_item_mixed = next((item for item in pool_mixed if item[1] == "a"), None)
    b_item_mixed = next((item for item in pool_mixed if item[1] == "b"), None)

    assert a_item_mixed is not None
    assert b_item_mixed is not None
    assert a_item_mixed[3] != 0.8  # Should not be the same as wy_priority
    assert b_item_mixed[3] != 0.2


def test_wy_priority_initialization():
    """Test GeneratorArgs wy_priority initialization."""
    # Test default initialization (all set to 1.0)
    args = GeneratorArgs(volume_of_cell=100.0, space_group_num=1)
    for letter in args.wyckoff_data.keys():
        assert args.wy_priority[letter] == 1.0

    # Test custom initialization
    custom_priority = {"a": 2.0, "b": 0.5}
    args_custom = GeneratorArgs(volume_of_cell=100.0, space_group_num=2, wy_priority=custom_priority)
    assert args_custom.wy_priority["a"] == 2.0
    assert args_custom.wy_priority["b"] == 0.5

    # Test that missing letters are set to 0.0
    for letter in args_custom.wyckoff_data.keys():
        if letter not in custom_priority:
            assert args_custom.wy_priority[letter] == 0.0


def test_wy_priority_validation():
    """Test that invalid Wyckoff positions in wy_priority raise GenerationError."""
    # Get valid Wyckoff positions for space group 1
    args_valid = GeneratorArgs(volume_of_cell=100.0, space_group_num=1)
    valid_keys = set(args_valid.wyckoff_data.keys())

    # Test with valid wy_priority (all keys exist in wyckoff_data)
    valid_priority = {key: 1.0 for key in list(valid_keys)[:2]}  # Take first two valid keys
    args_valid = GeneratorArgs(volume_of_cell=100.0, space_group_num=1, wy_priority=valid_priority)

    # No exception should be raised for valid keys
    assert all(key in args_valid.wy_priority for key in valid_priority)

    # Test with invalid wy_priority (includes a key not in wyckoff_data)
    # Use a key that is unlikely to be a valid Wyckoff position for any space group
    invalid_priority = {list(valid_keys)[0]: 1.0, "invalid_position": 2.0}
    with pytest.raises(GenerationError, match="Invalid Wyckoff positions in wy_priority"):
        GeneratorArgs(volume_of_cell=100.0, space_group_num=1, wy_priority=invalid_priority)


def test_generator_args_serde():
    """Test GeneratorArgs serialization/deserialization."""
    # Test basic serialization
    args = GeneratorArgs(volume_of_cell=100.0, space_group_num=1)
    serialized = args.model_dump_json()

    deserialized = GeneratorArgs.model_validate_json(serialized)

    assert deserialized.volume_of_cell == 100.0
    assert deserialized.space_group_num == 1
    assert deserialized.max_angle_degree == 150.0
    assert deserialized.min_angle_degree == 20.0
    assert deserialized.max_attempts == 1000
    assert deserialized.decimals == 7
    assert deserialized.variance_of_volume == 10.0
    assert deserialized.wyckoff_mixing_ratio == 0.0
    # Check the new parameters
    assert deserialized.use_mesh is False
    assert deserialized.perturbation == 0.0
    assert deserialized.atomic_dist_decay_rate == 0.002
    assert deserialized.check_atomic_dist is False

    # Test serialization with custom values
    custom_args = GeneratorArgs(
        volume_of_cell=200.0,
        space_group_num=225,
        max_angle_degree=120.0,
        min_angle_degree=30.0,
        max_attempts=500,
        decimals=5,
        variance_of_volume=20.0,
        wy_priority={"a": 2.0, "b": 0.5},
        wyckoff_mixing_ratio=0.5,
        use_mesh=True,
        perturbation=0.1,
        atomic_dist_decay_rate=0.003,
        check_atomic_dist=True,
    )

    serialized_custom = custom_args.model_dump_json()
    deserialized = GeneratorArgs.model_validate_json(serialized_custom)

    assert deserialized.volume_of_cell == 200.0
    assert deserialized.space_group_num == 225
    assert deserialized.max_angle_degree == 120.0
    assert deserialized.min_angle_degree == 30.0
    assert deserialized.max_attempts == 500
    assert deserialized.decimals == 5
    assert deserialized.variance_of_volume == 20.0
    assert deserialized.wy_priority["a"] == 2.0
    assert deserialized.wy_priority["b"] == 0.5
    assert deserialized.wyckoff_mixing_ratio == 0.5
    # Verify the new parameters are correctly deserialized
    assert deserialized.use_mesh is True
    assert deserialized.perturbation == 0.1
    assert deserialized.atomic_dist_decay_rate == 0.003
    assert deserialized.check_atomic_dist is True
