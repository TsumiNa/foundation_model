# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

from shotgun_csp.core.exception import GenerationError


def test_generation_error_no_class():
    """Test GenerationError without a class."""
    error = GenerationError(None, "Test message")
    assert str(error) == "GenerationError -- Test message"


def test_generation_error_with_class():
    """Test GenerationError with a class."""

    class TestClass:
        pass

    error = GenerationError(TestClass, "Test message")
    assert "GenerationError from <TestClass>" in str(error) or "GenerationError from <class 'type'>" in str(error)


def test_generation_error_message():
    """Test GenerationError message attribute."""
    error = GenerationError(None, "Test message")
    assert error.message == "Test message"


def test_generation_error_inheritance():
    """Test that GenerationError inherits from Exception."""
    error = GenerationError(None, "Test message")
    assert isinstance(error, Exception)
