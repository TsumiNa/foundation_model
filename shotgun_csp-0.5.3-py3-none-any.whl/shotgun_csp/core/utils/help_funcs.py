# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import re
import warnings
from collections import defaultdict
from pathlib import Path
from typing import Callable, Dict, List, Tuple, Union

import joblib
import numpy as np
import pandas as pd
import torch
from joblib import Parallel, delayed
from matminer.featurizers.site import CrystalNNFingerprint
from matminer.featurizers.structure import SiteStatsFingerprint
from pymatgen.core import Composition, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from scipy.special import softmax

from shotgun_csp.core.utils import WY
from shotgun_csp.descriptor import Compositions
from shotgun_csp.model.extension import TensorConverter
from shotgun_csp.model.sequential import Layer1d, LinearLayer, SequentialLinear
from shotgun_csp.model.training import Checker, Trainer

__call__ = [
    "predict_volume_of_unit_cell",
    "predict_space_group",
    "predict_proba_of_wyckoff_letters",
    "calculate_structure_dissimilarity",
    "WyckoffPositionConverter",
    "extract_ratio_and_ratioSG",
    "get_equivalent_coords",
]


def predict_proba_of_wyckoff_letters(
    compositions: List[Union[str, Composition, dict]],
    space_group_num: int,
    pred_model_path: str,
    *,
    ignore_warn=True,
    n_jobs: int = 1,
) -> List[Dict[str, float]]:
    """
    Predict the probabilities of Wyckoff letters for given compositions and space group.

    This function uses a pre-trained model to predict the probabilities of Wyckoff
    letters for a given list of compositions and a specified space group (spg). The
    predictions are normalized to ensure the probabilities sum to 1 for each composition.

    Args:
        compositions (List[Union[str, Composition, dict]]): A list of compositions to
            predict probabilities for. Each composition can be a string, a `Composition`
            object, or a dictionary.
        space_group_num (int): The space group number for which the prediction is performed.
        pred_model_path (str): The path to the directory containing the pre-trained
            models. The model for the specified space group should be named
            `spg_<spg>.pkl.z`.
        ignore_warn (bool, optional): If True, suppresses warnings during execution.
            Defaults to True.
        n_jobs (int, optional): The number of parallel jobs to use for descriptor
            calculation. Defaults to 1.

    Returns:
        List[dict]: A list of dictionaries where each dictionary contains the predicted
        probabilities of Wyckoff letters for a composition. If the model for the
        specified space group is not found, an empty dictionary is returned.

    Raises:
        FileNotFoundError: If the model file for the specified space group is not found
            in the provided `pred_model_path`. In this case, will return `{}`

    Notes:
        - The function assumes that the pre-trained model is stored as a dictionary
          containing the keys "scaler", "model", and "wy_letters".
        - The probabilities are adjusted to replace zero values with a small constant
          (1e-4) before normalization.
    """
    if ignore_warn:
        warnings.filterwarnings("ignore")
    try:
        best_model = joblib.load(f"{pred_model_path}/spg_{space_group_num}.pkl.z")
    except FileNotFoundError:
        return {}

    scaler = best_model["scaler"]
    rfr = best_model["model"]
    wy_letters = best_model["wy_letters"]

    # descriptor calculator
    composition_calc = Compositions(n_jobs=n_jobs)
    desc = composition_calc.transform(compositions)
    trans_desc = scaler.transform(desc)

    y_pred = rfr.predict(trans_desc)
    y_pred = pd.DataFrame(y_pred, columns=wy_letters)
    y_pred = y_pred.replace(to_replace=0, value=1e-4, inplace=False)

    # Normalize each row to ensure the probabilities sum to 1
    y_pred = y_pred.div(y_pred.sum(axis=1), axis=0)

    return [s[1].to_dict() for s in y_pred.iterrows()]


def predict_space_group(
    compositions: List[Union[str, Composition, dict]],
    pred_model,
    *,
    top=10,
    checkpoint="macro_precision",
    ignore_warn=True,
    n_jobs: int = 1,
) -> np.ndarray:
    """
    Predicts the space group for a given list of compositions using a pre-trained model.

    Args:
        compositions (List[Union[str, Composition, dict]]): A list of compositions to predict the space group for.
            Each composition can be represented as a string, a `Composition` object, or a dictionary.
        pred_model: The pre-trained model used for prediction.
        top (int, optional): The number of top predictions to return. Defaults to 10.
        checkpoint (str, optional): The checkpoint to use for the model during prediction. Defaults to "macro_precision".
        ignore_warn (bool, optional): Whether to suppress warnings during execution. Defaults to True.
        n_jobs (int, optional): The number of parallel jobs to use for computation. Defaults to 1.

    Returns:
        float: A numpy array containing the predicted space groups for each composition. The predictions are sorted
            by probability, and the top `top` predictions are returned for each composition.
    """
    if ignore_warn:
        warnings.filterwarnings("ignore")

    torch.serialization.add_safe_globals([SequentialLinear, LinearLayer, Layer1d])
    checker = Checker(pred_model)
    scaler = checker["scaler"]
    label_encoder = checker["label_encoder"]
    trainer = Trainer.from_checker(checker=checker).extend(
        TensorConverter(x_dtype=torch.float32, y_dtype=torch.long, argmax=False, empty_cache=True)
    )

    desc = Compositions(n_jobs=n_jobs).transform(compositions)
    desc = scaler.transform(desc)

    mat = trainer.predict(x_in=desc, checkpoint=checkpoint)
    mat = np.argsort(-softmax(mat, axis=1), axis=1)[:, :top]

    return np.apply_along_axis(label_encoder.inverse_transform, 1, mat)


def predict_volume_of_unit_cell(
    compositions: List[Union[str, Composition, dict]],
    pred_model: Union[str, Path],
    *,
    checkpoint="mae",
    ignore_warn=True,
    n_jobs=1,
) -> np.ndarray:
    """
    Predict the volume of a unit cell for given compositions using a specified prediction model.

    Args:
        compositions (List[Union[str, Composition, dict]]): A list of compositions, which can be
            represented as strings, `Composition` objects, or dictionaries.
        pred_model (Union[str, Path]): Path to the prediction model to be used for volume prediction.
        checkpoint (str, optional): The checkpoint to use for the prediction. Defaults to "mae".
        ignore_warn (bool, optional): If True, suppresses warnings during execution. Defaults to True.
        n_jobs (int, optional): Number of parallel jobs to use for processing compositions. Defaults to 1.

    Returns:
        np.array: A numpy array containing the predicted volumes for the input compositions.
    """
    if ignore_warn:
        warnings.filterwarnings("ignore")

    torch.serialization.add_safe_globals([SequentialLinear, LinearLayer, torch.nn.modules.linear.Linear])
    checker = Checker(pred_model)
    trainer = Trainer.from_checker(checker=checker).extend(TensorConverter())
    desc = Compositions(n_jobs=n_jobs).transform(compositions)

    if checkpoint is None:
        return trainer.predict(x_in=desc).flatten()
    return trainer.predict(x_in=desc, checkpoint=checkpoint).flatten().astype(np.float64)


def calculate_structure_dissimilarity(anchor_structure: Structure, *structure: Structure, n_jobs=1) -> List[float]:
    """
    Calculate the dissimilarity between a reference structure (anchor_structure)
    and one or more other structures using site statistics fingerprints.

    The dissimilarity is computed as the Euclidean distance between the feature
    vector of the anchor structure and the feature vectors of the other structures.

    Args:
        anchor_structure (Structure): The reference structure to compare against.
        *structure (Structure): One or more structures to compare to the anchor structure.
        n_jobs (int, optional): The number of parallel jobs to use for feature computation.
            Defaults to 1.

    Returns:
        List[float]: A list of dissimilarity scores, where each score corresponds to
        the Euclidean distance between the anchor structure and one of the input structures.
    """
    ssf = SiteStatsFingerprint(
        CrystalNNFingerprint.from_preset("ops", distance_cutoffs=None, x_diff_weight=0),
        stats=("mean", "std_dev", "minimum", "maximum"),
    )
    v_anchor = np.array(ssf.featurize(anchor_structure))
    tmp = Parallel(n_jobs=n_jobs, backend="loky")(delayed(ssf.featurize)(s) for s in structure)
    return [np.linalg.norm(np.array(s) - v_anchor) for s in tmp]


def extract_ratio_and_ratioSG(structure_list, n_jobs=-1):
    """
    Extracts ratio and ratioSG information from a list of pymatgen Structure objects.

    Parameters:
    -----------
    structure_list : list
        List of pymatgen Structure objects.
    n_jobs : int, optional
        Number of jobs to run in parallel. Default is -1 (use all available processors).

    Returns:
    --------
    pd.DataFrame
        DataFrame containing only the ratio and ratioSG columns.
    """

    def _inner(struct):
        tmp = {}
        try:
            # No need to create Structure object since input is already Structure
            composition = struct.composition
            spg_analyzer = SpacegroupAnalyzer(struct, symprec=1e-4)

            # space group info
            spg_num = spg_analyzer.get_space_group_number()
            ratio_ = tuple(sorted([v for v in composition.as_dict().values()]))
            ratioSG_ = f"{'_'.join([str(s) for s in ratio_])}-{spg_num}"

            # Only extract the required columns
            tmp["ratio"] = ratio_
            tmp["ratioSG"] = ratioSG_
            tmp["errors_msg"] = None
        except Exception as e:
            tmp["errors_msg"] = f"{e}"

        return tmp

    results = Parallel(n_jobs=n_jobs, backend="loky")(delayed(_inner)(s) for s in structure_list)

    # Create a DataFrame with only the required columns
    return pd.DataFrame(results)


def get_equivalent_coords(structure: Structure, *, mapper: Callable[[str, str, int], str] = None):
    """
    Generate a DataFrame containing equivalent atomic coordinates and related information
    for a given crystal structure.

    Args:
        structure (Structure): A pymatgen `Structure` object representing the crystal structure.
        mapper (Callable[[str, str, int], str], optional): A callable function that maps
            the element, Wyckoff letter, and multiplicity to a target element. Defaults to None.

    Returns:
        pd.DataFrame: A DataFrame where each row corresponds to an equivalent site in the
        structure. The columns include:
            - "element": The chemical species of the site.
            - "space_group_num": The space group number of the structure.
            - "multiplicity": The multiplicity of the Wyckoff position.
            - "wyckoff_letter": The Wyckoff letter of the position.
            - "target_element": The result of the `mapper` function, if provided.
            - "coordinate": The fractional coordinates of the site.
    """
    struct = SpacegroupAnalyzer(structure).get_symmetrized_structure()

    def _inner(i, sites, mapper=None):
        site = sites[0]
        wy_symbol = struct.wyckoff_symbols[i]
        row = {"element": site.species_string}
        row["space_group_num"] = struct.get_space_group_info()[1]
        row["multiplicity"] = int(wy_symbol[:-1])
        row["wyckoff_letter"] = wy_symbol[-1]
        if mapper is not None:
            row["target_element"] = mapper(site.species_string, row["wyckoff_letter"], row["multiplicity"])
        row["coordinate"] = list(site.frac_coords)

        return row

    return pd.DataFrame([_inner(i, sites, mapper=mapper) for i, sites in enumerate(struct.equivalent_sites)])


def get_wyckoff_config(structure: Structure) -> dict[str, list[str]]:
    """
    Gets the Wyckoff positions configuration for each element in the crystal structure.

    Args:
        structure (Structure): A pymatgen Structure object representing the crystal structure

    Returns:
        dict[str, list[str]]: A dictionary mapping element symbols to their Wyckoff positions,
            where keys are element symbols and values are lists of Wyckoff letters
    """
    # Create a SpacegroupAnalyzer to get the symmetry information
    sga = SpacegroupAnalyzer(structure)
    # Get the Wyckoff positions of all sites in the structure
    sym_data = sga.get_symmetry_dataset()
    wyckoff_positions = sym_data["wyckoffs"]
    equivalent_atoms = sym_data["equivalent_atoms"]
    elements = [str(site.specie) for site in structure.sites]

    wyckoff_dict = defaultdict(list)
    d = pd.DataFrame({"element": elements, "wyckoff_letter": wyckoff_positions, "equivalent_atom": equivalent_atoms})
    d = d.groupby("equivalent_atom").head(1)

    for _, (e, l, _) in d.iterrows():
        wyckoff_dict[e].append(l)

    # Convert defaultdict to a regular dict
    return dict(wyckoff_dict)


class WyckoffPositionConverter:
    """Convert fraction coordinates into Wyckoff position formate."""

    class _Coordinate:
        patten = re.compile(r"(?P<xyz>-?\d?[xyz])|(?P<cons_frac>\d\/\d?)|(?P<cons>\d)")

        @classmethod
        def _inner(cls, s):
            if "-" in s:
                coeff = -1
            else:
                coeff = 1
            if "2" in s:
                coeff *= 2

            return coeff

        def __call__(self, coordinates):
            const = 0
            x_coeff, y_coeff, z_coeff, const = 0, 0, 0, 0

            for e in self.patten.findall(coordinates):
                if e[0] != "":
                    s = e[0].lower()
                    if "x" in s:
                        x_coeff = self._inner(s)
                        continue

                    if "y" in s:
                        y_coeff = self._inner(s)
                        continue

                    if "z" in s:
                        z_coeff = self._inner(s)
                        continue

                if e[1] != "":
                    s = e[1].split("/")
                    const = float(s[0]) / float(s[1])
                    continue

                if e[2] != "":
                    const = float(e[2])
                    continue

            return x_coeff, y_coeff, z_coeff, const

    class _Particle:
        patten = re.compile(r",\s*")

        def __init__(self):
            self.Coordinate = WyckoffPositionConverter._Coordinate()

        def __call__(self, position):
            return [self.Coordinate(coord) for coord in self.patten.split(position)]

    patten = re.compile(r"(?<=\)),\s*")

    def __init__(self, space_group_num: int):
        wys = WY[space_group_num - 1]
        self.particle = WyckoffPositionConverter._Particle()
        self.wyckoff_pos = {letter: self.patten.split(val[2])[0][1:-1] for letter, val in wys.items()}

    def _inner(self, wy_letter, coord):
        b = np.asarray(coord)
        a = np.array(self.particle(self.wyckoff_pos[wy_letter]))
        idx = []

        if np.count_nonzero(a[:, 0]):
            idx.append(0)
        if np.count_nonzero(a[:, 1]):
            idx.append(1)
        if np.count_nonzero(a[:, 2]):
            idx.append(2)
        b[idx] -= a[idx, -1]

        if len(idx) > 1:
            solves = np.linalg.solve(a[idx][:, idx], b[idx] - a[idx, -1])
            b[idx] = solves

        return b.tolist()

    def __call__(
        self,
        wyckoff_letters: Union[str, pd.Series, List[str]],
        coords: Union[str, pd.Series, List[Tuple[float, float, float]]],
        elements: Union[str, pd.Series, List[str], None] = None,
        *,
        data: pd.DataFrame = None,
    ):
        if data is not None:
            if not isinstance(wyckoff_letters, str) or not isinstance(coords, str):
                raise ValueError("`wyckoff_letters` and `coords` must be the column name when `data` is set")

            if elements is not None and isinstance(elements, str):
                wy_and_coord = [a for _, a in data[[wyckoff_letters, coords, elements]].iterrows()]
            else:
                wy_and_coord = [a for _, a in data[[wyckoff_letters, coords]].iterrows()]
        else:
            if isinstance(wyckoff_letters, str) or isinstance(coords, str) or isinstance(elements, str):
                raise ValueError(
                    "found `wyckoff_letters`, `coords`, and `elements` as column name but `data` is not given"
                )

            if elements is None:
                if not len(wyckoff_letters) == len(coords):
                    raise ValueError("`wyckoff_letters`and `coords` have different lengths")
                wy_and_coord = list(zip(wyckoff_letters, coords))
            else:
                if not len(wyckoff_letters) == len(coords) == len(elements):
                    raise ValueError("`wyckoff_letters`, `coords`, and `elements` have different lengths")
                wy_and_coord = list(zip(wyckoff_letters, coords, elements))

        if len(wy_and_coord[0]) == 2:
            return [(wy, self._inner(wy, b)) for wy, b in wy_and_coord]
        if len(wy_and_coord[0]) == 3:
            return [(f"{elem}:{wy}", self._inner(wy, b)) for wy, b, elem in wy_and_coord]
        raise ValueError("`wy_and_coord` must be a list of (wyckoff_letter, coord) or (wyckoff_letter, coord, element)")
