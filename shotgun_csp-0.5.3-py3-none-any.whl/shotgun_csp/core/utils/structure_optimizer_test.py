# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import os
from pathlib import Path

import pytest
from ase import Atoms

from shotgun_csp.core.utils.structure_optimizer import StructureOptimizer


@pytest.fixture
def test_structures():
    """Create sample structures for testing."""
    return [
        # H2O
        Atoms("H2O", positions=[[0, 0, 0], [0, 0, 1], [1, 0, 0]], cell=[5, 5, 5], pbc=True),
        # H2
        Atoms("H2", positions=[[0, 0, 0], [0, 0, 1]], cell=[5, 5, 5], pbc=True),
        # CO2
        Atoms("CO2", positions=[[0, 0, 0], [0, 0, 1], [0, 0, -1]], cell=[5, 5, 5], pbc=True),
    ]


def test_basic_optimization(test_structures, tmp_path):
    """Test basic structure optimization functionality."""
    # Create logs directory
    logs_dir = tmp_path / "logs"
    logs_dir.mkdir()

    # Setup optimizer without groundtruth
    optimizer = StructureOptimizer(device="cpu", logfile=str(logs_dir))

    # Run with all three structures (using the new API)
    optimized, df = optimizer(*test_structures)

    # Check that we got the right number of structures back
    assert len(optimized) == 3
    assert len(df) == 3

    # Check essential dataframe columns - only check for a subset that should always be present
    essential_columns = [
        "index",
        "Energy (before) [eV/atom]",
        "Energy (after) [eV/atom]",
        "Space group (before)",
        "Space group (after)",
        "Time elapsed (step 0) [s]",
        "Time elapsed (step 1) [s]",
        "Time elapsed (step 2) [s]",
        "Total time elapsed [s]",
        "Mean force (before) [eV/Å]",
        "Mean force (after) [eV/Å]",
        "Max force (before) [eV/Å]",
        "Max force (after) [eV/Å]",
        "Min force (before) [eV/Å]",
        "Min force (after) [eV/Å]",
        "Std force (before) [eV/Å]",
        "Std force (after) [eV/Å]",
        "Max stress (final) [eV/Å³]",
        "Converged (final)",
    ]
    for col in essential_columns:
        assert col in df.columns

    # Check optimization results for each structure
    for i in range(3):
        row = df.iloc[i]
        assert row["Energy (after) [eV/atom]"] < row["Energy (before) [eV/atom]"]
        assert row["Converged (final)"]

        # Check that forces were reduced
        assert row["Mean force (after) [eV/Å]"] < row["Mean force (before) [eV/Å]"]


def test_with_output_files(test_structures, tmp_path):
    """Test optimization with trajectory and log files."""
    traj_dir = tmp_path / "trajectories"
    log_dir = tmp_path / "logs"

    # Create directories to avoid creation issues
    traj_dir.mkdir()
    log_dir.mkdir()

    # Create optimizer without groundtruth
    optimizer = StructureOptimizer(
        device="cpu",
        save_trajectory=str(traj_dir),
        logfile=str(log_dir),
    )

    # Run optimizer with all structures (using the new API)
    _, _ = optimizer(*test_structures)

    # Check that trajectory and log files were created
    assert os.path.exists(traj_dir)
    assert os.path.exists(log_dir)

    # Check file count - should have one file for each input structure
    traj_files = list(Path(traj_dir).glob("*.traj"))
    log_files = list(Path(log_dir).glob("*.log"))
    assert len(traj_files) == 3
    assert len(log_files) == 3

    # Verify that files for each structure type exist
    structure_formulas = ["H2O", "H2", "CO2"]
    for formula in structure_formulas:
        assert any(formula in file.name for file in traj_files)
        assert any(formula in file.name for file in log_files)

    # Check that trajectory files actually contain data (not empty)
    for traj_file in traj_files:
        # Verify file size is not zero
        assert os.path.getsize(traj_file) > 0

        # Import Trajectory reader to verify content can be read
        from ase.io import read

        try:
            # Try to read first frame from trajectory
            atoms = read(traj_file, index=0)
            # Verify it contains valid structure
            assert isinstance(atoms, Atoms)
            assert len(atoms) > 0  # Contains atoms
        except Exception as e:
            pytest.fail(f"Failed to read trajectory file {traj_file}: {e}")


def test_group_by_formula(test_structures, tmp_path):
    """Test grouping output files by chemical formula."""
    traj_dir = tmp_path / "trajectories"
    log_dir = tmp_path / "logs"

    # Create directories to avoid creation issues
    traj_dir.mkdir()
    log_dir.mkdir()

    # Create optimizer without groundtruth but with formula grouping
    optimizer = StructureOptimizer(
        device="cpu",
        save_trajectory=str(traj_dir),
        logfile=str(log_dir),
        group_output_files_by_formula=True,
    )

    # Run optimizer with all structures (using the new API)
    _, _ = optimizer(*test_structures)

    # Check that formula directories were created for each structure type
    formula_dirs = ["H2O", "H2", "CO2"]
    for formula in formula_dirs:
        assert os.path.exists(os.path.join(traj_dir, formula))
        assert os.path.exists(os.path.join(log_dir, formula))

        # Check that files exist in these directories
        assert list(Path(os.path.join(traj_dir, formula)).glob("*.traj"))
        assert list(Path(os.path.join(log_dir, formula)).glob("*.log"))


def test_eval_only(test_structures, tmp_path):
    """Test evaluation-only mode (no optimization)."""
    # Create optimizer without groundtruth
    optimizer = StructureOptimizer(
        device="cpu",
        logfile=str(tmp_path),
    )

    # Test eval_only mode with all structures (using the new API)
    optimized, df = optimizer(*test_structures, eval_only=True)

    # Check that only "before" metrics are present
    assert "Energy (before) [eV/atom]" in df.columns
    assert "Space group (before)" in df.columns

    # Check that optimization metrics are not present or are zero
    if "Time elapsed (step 0) [s]" in df.columns:
        assert all(df["Time elapsed (step 0) [s]"] == 0)

    # Check that we got the right number of structures back
    assert len(optimized) == 0
    assert len(df) == 3


def test_invalid_only_top_n(test_structures, tmp_path):
    """Test invalid only_top_n parameter values."""
    optimizer = StructureOptimizer(
        device="cpu",
        logfile=str(tmp_path),
    )

    # Test negative value with minimal setup (using the new API)
    with pytest.raises(ValueError):
        optimizer(test_structures[0], only_top_n=-1)

    # Test non-integer value with minimal setup (using the new API)
    with pytest.raises(TypeError):
        optimizer(test_structures[0], only_top_n=1.5)


def test_only_top_n(test_structures, tmp_path):
    """Test the only_top_n parameter with multiple structures."""
    # Create logs and trajectory directories
    logs_dir = tmp_path / "logs"
    logs_dir.mkdir()
    traj_dir = tmp_path / "trajectories"
    traj_dir.mkdir()

    # Setup optimizer with trajectory saving
    optimizer = StructureOptimizer(device="cpu", logfile=str(logs_dir), save_trajectory=str(traj_dir))

    # Run with top 2 structures only
    optimized, df = optimizer(*test_structures, only_top_n=2)

    # Check that we got exactly 3 structures back (all structures are returned,
    # but only the top n are optimized)
    assert len(optimized) == 3
    assert len(df) == 3

    # Check which structures were optimized by examining the "Converged (final)" column
    # At least 2 structures should have been optimized
    optimized_count = df["Converged (final)"].sum()
    assert optimized_count >= 2

    # Verify that non-optimized structures have zero for optimization time
    # and the optimized ones have non-zero time
    optimized_indices = []
    for i, row in df.iterrows():
        if row["Converged (final)"]:
            assert row["Total time elapsed [s]"] > 0
            optimized_indices.append(row["index"])
        else:
            assert row["Total time elapsed [s]"] == 0

    # Count trajectory files
    traj_files = list(Path(traj_dir).glob("*.traj"))

    # Verify the number of trajectory files matches the number of optimized structures
    assert len(traj_files) == optimized_count

    # Check that trajectory files only exist for optimized structures
    for traj_file in traj_files:
        # Extract index from filename (assumes format like "H2O_0.traj")
        file_idx = int(traj_file.stem.split("_")[-1])
        # Verify this index is in the list of optimized indices
        assert file_idx in optimized_indices


def test_save_cif(test_structures, tmp_path):
    """Test saving structures in CIF format."""
    # Create CIF directory
    cif_dir = tmp_path / "cifs"
    cif_dir.mkdir()

    # Create logs directory
    logs_dir = tmp_path / "logs"
    logs_dir.mkdir()

    # Setup optimizer with CIF saving
    optimizer = StructureOptimizer(device="cpu", save_cif=str(cif_dir), logfile=str(logs_dir))

    # Run optimizer with all structures
    _ = optimizer(*test_structures)

    # Get all CIF files
    cif_files = list(Path(cif_dir).glob("*.cif"))

    # Should have 2 CIF files per structure (before and after optimization)
    assert len(cif_files) == 2 * len(test_structures)

    # Verify that both initial and optimized files exist
    structure_formulas = ["H2O", "H2", "CO2"]
    for formula in structure_formulas:
        # Check for initial files (without "_relax" suffix)
        # More precise formula matching by looking for 'formula_' in the name
        initial_files = [f for f in cif_files if f"{formula}_" in f.name and "_relax" not in f.name]
        assert len(initial_files) == 1, (
            f"Expected 1 initial file for {formula}, got {len(initial_files)}: {initial_files}"
        )

        # Check for optimized files (with "_relax" suffix)
        optimized_files = [f for f in cif_files if f"{formula}_" in f.name and "_relax" in f.name]
        assert len(optimized_files) == 1, (
            f"Expected 1 optimized file for {formula}, got {len(optimized_files)}: {optimized_files}"
        )

        # Check file content (files should not be empty)
        for cif_file in initial_files + optimized_files:
            assert os.path.getsize(cif_file) > 0

            # Read file content to verify it's a valid CIF
            with open(cif_file, "r") as f:
                content = f.read()
                assert "data_" in content  # CIF files start with data_ block
                assert "_cell_length_a" in content  # Should contain cell parameters
                assert "_atom_site_" in content  # Should contain atomic positions


def test_only_top_n_with_cif(test_structures, tmp_path):
    """Test the only_top_n parameter with CIF saving."""
    # Create CIF directory
    cif_dir = tmp_path / "cifs"
    cif_dir.mkdir()

    # Create logs directory
    logs_dir = tmp_path / "logs"
    logs_dir.mkdir()

    # Setup optimizer with CIF saving
    optimizer = StructureOptimizer(device="cpu", save_cif=str(cif_dir), logfile=str(logs_dir))

    # Run with top 2 structures only
    _, df = optimizer(*test_structures, only_top_n=2)

    # Check which structures were optimized
    optimized_count = df["Converged (final)"].sum()
    optimized_indices = []
    for i, row in df.iterrows():
        if row["Converged (final)"]:
            optimized_indices.append(row["index"])

    # Get all CIF files
    cif_files = list(Path(cif_dir).glob("*.cif"))

    # Should have 1 initial CIF per structure + 1 optimized CIF per optimized structure
    assert len(cif_files) == len(test_structures) + optimized_count

    # Count initial and optimized CIF files
    initial_cifs = [f for f in cif_files if "_relax" not in f.name]
    optimized_cifs = [f for f in cif_files if "_relax" in f.name]

    # Verify counts
    assert len(initial_cifs) == len(test_structures)  # All structures have initial CIFs
    assert len(optimized_cifs) == optimized_count  # Only optimized structures have optimized CIFs

    # Check that optimized CIFs only exist for optimized structures
    for cif_file in optimized_cifs:
        # Extract index from filename (format: "{formula}_{idx}_energy_...")
        file_parts = cif_file.stem.split("_")
        file_idx = int(file_parts[1])  # Second part should be the index
        # Verify this index is in the list of optimized indices
        assert file_idx in optimized_indices
