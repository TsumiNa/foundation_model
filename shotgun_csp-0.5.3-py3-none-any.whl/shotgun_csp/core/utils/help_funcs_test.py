# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import os
from pathlib import Path

import numpy as np
import pytest

from shotgun_csp.core.utils.help_funcs import (
    predict_proba_of_wyckoff_letters,
    predict_space_group,
    predict_volume_of_unit_cell,
)

# Path to downloaded models relative to project root
MODEL_DIR = Path(os.path.join(os.path.dirname(__file__), "../../../..", "notebooks", "prediction_models"))

# Test compositions from the CSP Benchmark Dataset
TEST_COMPOSITIONS = {
    "mp-5182": {"formula": "Nd8Fe56B4", "space_group": 136},
    "mp-9770": {"formula": "Ag32Ge4S24", "space_group": 33},
}


# Added 2025-04-24 for ML model prediction testing
class TestPredictionFunctions:
    """Test suite for machine learning prediction functions."""

    def setup_class(cls):
        """Check if prediction models are available"""
        required_paths = [
            MODEL_DIR / "space_group",
            MODEL_DIR / "composition_volume_of_primitive_cell",
            MODEL_DIR / "wyckoff_proba",
        ]

        if not all(path.exists() for path in required_paths):
            pytest.skip("Prediction models not available")

    def test_predict_space_group(self):
        """Test space group prediction function with benchmark compositions."""
        # Prepare compositions list
        compositions = [TEST_COMPOSITIONS["mp-5182"]["formula"], TEST_COMPOSITIONS["mp-9770"]["formula"]]
        expected_space_groups = [
            TEST_COMPOSITIONS["mp-5182"]["space_group"],
            TEST_COMPOSITIONS["mp-9770"]["space_group"],
        ]

        # Get predictions
        predictions = predict_space_group(compositions, pred_model=str(MODEL_DIR / "space_group"), top=30)

        # Basic structure validation
        assert len(predictions) == len(compositions)
        assert predictions.shape[1] == 30  # top=30
        assert predictions.dtype == np.int64 or predictions.dtype == np.int32

        # Verify correct space groups are in predictions
        for i, expected_sg in enumerate(expected_space_groups):
            assert expected_sg in predictions[i], (
                f"Expected space group {expected_sg} not in predictions for {compositions[i]}"
            )

    def test_predict_volume_of_unit_cell(self):
        """Test volume prediction function with benchmark compositions."""
        # Prepare compositions list
        compositions = [TEST_COMPOSITIONS["mp-5182"]["formula"], TEST_COMPOSITIONS["mp-9770"]["formula"]]

        # Get predictions
        volumes = predict_volume_of_unit_cell(
            compositions, pred_model=str(MODEL_DIR / "composition_volume_of_primitive_cell")
        )

        # Basic validation
        assert len(volumes) == len(compositions)
        assert all(isinstance(v, (float, np.float64)) for v in volumes)
        assert all(v > 0 for v in volumes)  # Volumes should be positive

        # We can't check exact values as they may change with model updates,
        # but we can check they're in a reasonable range
        nd_fe_b_volume, ag_ge_s_volume = volumes
        assert 500 < nd_fe_b_volume < 2000, f"Nd8Fe56B4 volume {nd_fe_b_volume} outside expected range"
        assert 500 < ag_ge_s_volume < 2000, f"Ag32Ge4S24 volume {ag_ge_s_volume} outside expected range"

    def test_predict_proba_of_wyckoff_letters(self):
        """Test Wyckoff letter probability prediction with benchmark compositions."""
        # Test for Nd8Fe56B4 (space group 136)
        proba_nd_fe_b = predict_proba_of_wyckoff_letters(
            [TEST_COMPOSITIONS["mp-5182"]["formula"]],
            space_group_num=TEST_COMPOSITIONS["mp-5182"]["space_group"],
            pred_model_path=str(MODEL_DIR / "wyckoff_proba"),
        )

        # Test for Ag32Ge4S24 (space group 33)
        proba_ag_ge_s = predict_proba_of_wyckoff_letters(
            [TEST_COMPOSITIONS["mp-9770"]["formula"]],
            space_group_num=TEST_COMPOSITIONS["mp-9770"]["space_group"],
            pred_model_path=str(MODEL_DIR / "wyckoff_proba"),
        )

        # Validate Nd8Fe56B4 results
        if proba_nd_fe_b and proba_nd_fe_b[0]:
            assert isinstance(proba_nd_fe_b[0], dict)
            # Check probabilities sum approximately to 1
            values = list(proba_nd_fe_b[0].values())
            assert abs(sum(values) - 1.0) < 1e-5

            # Check expected Wyckoff letters for space group 136
            key_letters = ["c", "e", "f", "g", "j", "k"]
            for letter in key_letters:
                assert letter in proba_nd_fe_b[0], f"Expected Wyckoff letter {letter} not in predictions for Nd8Fe56B4"
        else:
            pytest.skip("No model available for Nd8Fe56B4 (space group 136)")

        # Validate Ag32Ge4S24 results
        if proba_ag_ge_s and proba_ag_ge_s[0]:
            assert isinstance(proba_ag_ge_s[0], dict)
            # Check probabilities sum approximately to 1
            values = list(proba_ag_ge_s[0].values())
            assert abs(sum(values) - 1.0) < 1e-5

            # Check expected Wyckoff letters for space group 33
            assert "a" in proba_ag_ge_s[0], "Expected Wyckoff letter 'a' not in predictions for Ag32Ge4S24"
        else:
            pytest.skip("No model available for Ag32Ge4S24 (space group 33)")
