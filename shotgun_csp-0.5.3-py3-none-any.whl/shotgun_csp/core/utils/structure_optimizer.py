# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import os
import time
from contextlib import contextmanager
from copy import deepcopy
from typing import Literal, Optional

import numpy as np
import pandas as pd
from ase import Atoms
from ase.constraints import FixAtoms, FixSymmetry
from ase.filters import UnitCellFilter
from ase.io import Trajectory, write
from ase.optimize import FIRE
from pymatgen.core import Structure
from pymatgen.io.ase import AseAtomsAdaptor
from tqdm.auto import tqdm

from shotgun_csp.core.utils.help_funcs import calculate_structure_dissimilarity

try:
    from ase.filters import UnitCellFilter
except ImportError:
    from ase.constraints import UnitCellFilter


class _SafeTrajectory:
    def __init__(self, traj_path, atoms):
        self.traj_path = traj_path
        self.traj = None
        if traj_path:
            # Get energies and forces to ensure they are calculated and stored
            if atoms.calc is not None:
                atoms.get_potential_energy()
                atoms.get_forces()
            # Write directly using ASE's write function with 'w' mode to create file
            write(traj_path, atoms, format="traj")
            # Now open in append mode for subsequent writes
            self.traj = Trajectory(traj_path, "a")

    def write(self, atoms):
        if self.traj_path and atoms.calc is not None:
            # Calculate properties to ensure they're stored
            atoms.get_potential_energy()
            atoms.get_forces()

            # Append directly to the file
            write(self.traj_path, atoms, format="traj", append=True)

    def close(self):
        if self.traj:
            self.traj.close()
            self.traj = None


@contextmanager
def _open_log_writer(log_path, header: str = ""):
    if isinstance(log_path, str) and log_path != "-":
        with open(log_path, "a") as f:
            if header:
                f.write(header)
            yield f
            f.write("\n")
    else:
        yield log_path


def _get_force_stats(forces):
    norms = np.linalg.norm(forces, axis=1)
    return {
        "Mean force": np.mean(norms),
        "Max force": np.max(norms),
        "Min force": np.min(norms),
        "Std force": np.std(norms),
    }


class StructureOptimizer:
    """
    A class for optimizing ASE structures in three steps and collecting energy/force/time/symmetry metrics.
    """

    def __init__(
        self,
        *,
        device: str = None,
        load_path: Optional[Literal["mattersim-v1.0.0-1m", "mattersim-v1.0.0-5m"]] = None,
        keep_symmetry_level: int = 0,
        groundtruth: Optional[Structure] = None,
        save_trajectory: Optional[str] = None,
        logfile: Optional[str] = os.devnull,
        save_cif: Optional[str] = None,
        group_output_files_by_formula: bool = False,
        logging: bool = False,
    ):
        """
        Initialize the StructureOptimizer.

        Parameters
        ----------
        device : str, optional
            Device to run MatterSim calculations on, by default "cuda" if available else "cpu"
        load_path : Optional[Literal["mattersim-v1.0.0-1m", "mattersim-v1.0.0-5m"]], optional
            Path to load MatterSim model from, by default None
        keep_symmetry_level : int, optional
            Level of symmetry constraints to apply during optimization, by default 0
        groundtruth : Optional[Structure], optional
            Reference structure for calculating dissimilarity, by default None
        save_trajectory : Optional[str], optional
            Directory to save optimization trajectories, by default None
        logfile : Optional[str], optional
            Directory or file to save optimization logs, by default os.devnull
        save_cif : Optional[str], optional
            Directory to save structures in CIF format, by default None
        group_output_files_by_formula : bool, optional
            Whether to organize trajectory, log, and CIF files in subdirectories grouped by chemical formula,
            by default False
        logging : bool, optional
            Whether to use loguru for logging instead of print statements, by default False
        """
        # Import here to avoid circular imports
        import torch
        from mattersim.forcefield import MatterSimCalculator
        from mattersim.forcefield.potential import Potential

        # Initialize logging
        self.logging = logging
        self.logger = None
        if self.logging:
            try:
                from loguru import logger

                self.logger = logger
            except ImportError:
                self.logging = False
                print("Warning: loguru not installed. Falling back to print statements.")

        # Set default device if not provided
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"

        self.device = device
        self.load_path = load_path

        # Add helper method for logging
        def _log_or_print(self, message, level="INFO"):
            """Log a message using loguru if logging is enabled, otherwise print"""
            if self.logging and self.logger is not None:
                if level == "INFO":
                    self.logger.info(message)
                elif level == "WARNING":
                    self.logger.warning(message)
                elif level == "ERROR":
                    self.logger.error(message)
                elif level == "DEBUG":
                    self.logger.debug(message)
            else:
                print(message)

        # Make _log_or_print a method of the instance
        self._log_or_print = _log_or_print.__get__(self)

        # Initialize MatterSim Potential
        self._log_or_print(f"Running MatterSim on {self.device}")
        self.potential = Potential.from_checkpoint(device=self.device, load_path=self.load_path)

        # Initialize MatterSimCalculator
        self.calculator = MatterSimCalculator(potential=self.potential, device=device)

        self.keep_symmetry_level = keep_symmetry_level
        self.groundtruth = groundtruth
        self.save_trajectory = save_trajectory
        self.logfile = logfile
        self.save_cif = save_cif
        self.group_output_files_by_formula = group_output_files_by_formula

        if self.keep_symmetry_level > 3:
            raise ValueError(f"keep_symmetry_level must be in [0, 1, 2], got {self.keep_symmetry_level}")

        if self.save_trajectory:
            os.makedirs(self.save_trajectory, exist_ok=True)

        if self.logfile not in (None, "-") and not os.path.exists(self.logfile):
            os.makedirs(self.logfile, exist_ok=True)

        if self.save_cif:
            os.makedirs(self.save_cif, exist_ok=True)

    def _save_structure_as_cif(
        self, structure: Structure, idx: int, full_formula: str, energy_per_atom: float, is_optimized: bool = False
    ):
        """
        Save a structure to CIF format.

        Parameters
        ----------
        structure : Structure
            Pymatgen Structure to save
        idx : int
            Structure index
        full_formula : str
            Chemical formula
        energy_per_atom : float
            Energy per atom value
        is_optimized : bool, optional
            Whether this is an optimized structure, by default False
        """
        if not self.save_cif:
            return

        # Determine CIF file path based on formula grouping setting
        if self.group_output_files_by_formula:
            cif_dir = os.path.join(self.save_cif, full_formula)
            os.makedirs(cif_dir, exist_ok=True)
            if is_optimized:
                cif_path = os.path.join(cif_dir, f"{full_formula}_{idx}_energy_{energy_per_atom:.5f}_relax.cif")
            else:
                cif_path = os.path.join(cif_dir, f"{full_formula}_{idx}_energy_{energy_per_atom:.5f}.cif")
        else:
            if is_optimized:
                cif_path = os.path.join(self.save_cif, f"{full_formula}_{idx}_energy_{energy_per_atom:.5f}_relax.cif")
            else:
                cif_path = os.path.join(self.save_cif, f"{full_formula}_{idx}_energy_{energy_per_atom:.5f}.cif")

        # Write CIF file
        with open(cif_path, "w") as f:
            f.write(structure.to(fmt="cif", symprec=0.01))

    def _sample_structures_for_optimization(self, energy_per_atom: list, only_top_n: int = None) -> set:
        """
        Sample structures for optimization based on their energy.

        Sampling rules:
        1. Only consider structures with negative energy
        2. If no negative energy structures are found, return an empty set (no optimization)
        3. If fewer negative energy structures than only_top_n, use all negative energy structures
        4. If sufficient negative energy structures, sample from top_n * 2 candidate pool
        5. Sampling weights are proportional to the absolute value of negative energies

        Parameters
        ----------
        energy_per_atom : list
            List of energy per atom for each structure
        only_top_n : int, optional
            Number of structures to optimize, by default None

        Returns
        -------
        set
            Set of structure indices to optimize
        """
        # import numpy as np

        # Filter structures with negative energy
        negative_energy_indices = [idx for idx, energy in enumerate(energy_per_atom) if energy < 0]
        if not negative_energy_indices:
            self._log_or_print("No negative energy structures found. Skipping optimization.", level="WARNING")
            return set()

        # Sort negative energy structures by energy (lowest first)
        negative_energy_indices = sorted(negative_energy_indices, key=lambda idx: energy_per_atom[idx])

        # If only_top_n is not specified or zero, return all negative energy structures
        if only_top_n is None or only_top_n <= 0:
            return set(negative_energy_indices)

        # If fewer negative energy structures than only_top_n, use all negative energy structures
        if len(negative_energy_indices) <= only_top_n:
            self._log_or_print(
                f"Only {len(negative_energy_indices)} structures with negative energy found. "
                f"Using all of them instead of requested {only_top_n}.",
                level="WARNING",
            )
            return set(negative_energy_indices)

        # Determine candidate pool size (2x requested or all available)
        candidate_pool_size = min(only_top_n * 2, len(negative_energy_indices))
        candidate_indices = negative_energy_indices[:candidate_pool_size]

        # Calculate candidate structure energies (all negative)
        candidate_energies = [energy_per_atom[idx] for idx in candidate_indices]

        # Get energy range
        e_min = min(candidate_energies)
        e_max = max(candidate_energies)
        e_range = e_max - e_min

        # Calculate weights with exponential emphasis on lower energies
        if e_range > 1e-6:  # Avoid division by near-zero
            # Normalize energies (preserving sort order) and amplify differences
            rel_energies = [(e - e_min) / e_range for e in candidate_energies]
            # Use exponential to amplify differences, negative sign makes lower energy -> higher weight
            weights = [np.exp(-5 * e_rel) for e_rel in rel_energies]
        else:
            # If energies are almost identical, use absolute value of original energies
            weights = [abs(e) for e in candidate_energies]

        # Normalize weights
        total_weight = sum(weights)
        weights = [w / total_weight for w in weights]

        # Sample only_top_n structures based on weights (without replacement)
        sampled_indices = np.random.choice(candidate_indices, size=only_top_n, replace=False, p=weights)

        return set(sampled_indices)

    def __call__(
        self,
        *structures: Atoms,
        show_progress: bool = False,
        eval_only: bool = False,
        only_top_n: Optional[int] = None,
        n_jobs: int = max(os.cpu_count() - 1, 1),
    ):
        """
        Optimize ASE structures in three steps and collect energy/force/time/symmetry metrics.

        Parameters
        ----------
        *structures : Atoms
            One or more ASE structure objects to optimize
        show_progress : bool, optional
            Whether to display a progress bar, by default False
        eval_only : bool, optional
            If True, only evaluate metrics without optimizing structures, by default False
        only_top_n : Optional[int], optional
            If set, only optimize the top N structures with lowest initial energy.
            0 or None means optimize all structures. Must be non-negative.
        n_jobs : int, optional
            Number of parallel jobs to run, by default max(os.cpu_count() - 1, 1)

        Returns
        -------
        optimized_structures : list of ase.Atoms
            The optimized structures
        df : pandas.DataFrame
            DataFrame containing optimization metrics
        """
        # Import here to avoid circular imports
        from mattersim.datasets.utils.build import build_dataloader

        # Convert structures tuple to list
        structures_list = list(structures)

        # Validation for only_top_n
        if only_top_n is not None:
            if not isinstance(only_top_n, int):
                raise TypeError(f"only_top_n must be an integer or None, got {type(only_top_n)}")
            if only_top_n < 0:
                raise ValueError(f"only_top_n must be non-negative, got {only_top_n}")
            if only_top_n == 0:
                only_top_n = None  # Treat as optimizing all
            elif only_top_n > len(structures_list):
                self._log_or_print(
                    f"Warning: only_top_n ({only_top_n}) is larger than the number of structures"
                    f"({len(structures_list)}). All structures will be optimized.",
                    level="WARNING",
                )
                only_top_n = None  # Treat as optimizing all

        # First, calculate energy for all structures using batch prediction regardless of eval_only
        ase_atoms_list = [struct.copy() for struct in structures_list]

        # Build the dataloader that is compatible with MatterSim
        dataloader = build_dataloader(ase_atoms_list, only_inference=True)

        # Make batch predictions
        self._log_or_print("Calculating energy, forces, and stresses for all structures...")
        predictions = self.potential.predict_properties(dataloader, include_forces=True, include_stresses=True)

        # Extract predictions
        energies, forces, stresses = predictions[0], predictions[1], predictions[2]
        self._log_or_print("Batch prediction completed.")

        # Always calculate energy_per_atom and sort structures by energy
        energy_per_atom = [e / len(atoms) for e, atoms in zip(energies, ase_atoms_list)]
        initial_energies = [(idx, energy) for idx, energy in enumerate(energy_per_atom)]
        sorted_indices = [idx for idx, _ in sorted(initial_energies, key=lambda x: x[1])]

        # Use the sampling function to determine which structures to optimize
        top_n_indices = self._sample_structures_for_optimization(energy_per_atom, only_top_n)

        # Pre-compute dissimilarity scores if groundtruth is available
        dissimilarities_before = None
        if self.groundtruth is not None:
            # Convert all structures to pymatgen Structure
            structures_before_list = [AseAtomsAdaptor.get_structure(s) for s in structures_list]
            # Use maximum parallelism with n_jobs
            self._log_or_print(f"Calculating dissimilarities using {n_jobs} parallel jobs...")
            # Calculate dissimilarities in parallel
            dissimilarities_before = calculate_structure_dissimilarity(
                self.groundtruth, *structures_before_list, n_jobs=n_jobs
            )
            self._log_or_print("Dissimilarity calculation completed.")

        # If eval_only=True, process all structures and return early
        if eval_only:
            all_entries = []

            for idx in sorted_indices:
                entry = {"index": idx}

                # Use precomputed energy and forces
                force = forces[idx]

                entry["Energy (before) [eV/atom]"] = energy_per_atom[idx]
                forces_before = _get_force_stats(force)
                for k, v in forces_before.items():
                    entry[f"{k} (before) [eV/Å]"] = v

                # Save initial structure as CIF if requested
                structure_before = AseAtomsAdaptor.get_structure(structures_list[idx])
                full_formula = structures_list[idx].get_chemical_formula().replace(" ", "")
                if self.save_cif:
                    self._save_structure_as_cif(structure_before, idx, full_formula, energy_per_atom[idx])

                entry["Space group (before)"] = structure_before.get_space_group_info()[1]

                if self.groundtruth is not None:
                    entry["Dissimilarity (before)"] = dissimilarities_before[idx]

                all_entries.append(entry)

            df = pd.DataFrame(all_entries)
            # Filter column_order to only include columns that exist in the df
            column_order = [
                "index",
                "Energy (before) [eV/atom]",
                "Space group (before)",
                "Mean force (before) [eV/Å]",
                "Max force (before) [eV/Å]",
                "Min force (before) [eV/Å]",
                "Std force (before) [eV/Å]",
                "Dissimilarity (before)",
            ]
            column_order = [col for col in column_order if col in df.columns]
            column_order += [col for col in df.columns if col not in column_order]
            df = df[column_order]
            return [], df

        # Normal optimization flow (eval_only=False)
        optimized_structures = []
        all_entries = []

        for idx, atoms in (
            tqdm(list(enumerate(structures_list)), desc="Optimizing", leave=True)
            if show_progress
            else enumerate(structures_list)
        ):
            atoms = atoms.copy()
            atoms.calc = deepcopy(self.calculator)
            entry = {"index": idx}

            # Use the precomputed energy and forces for initial measurements
            force = forces[idx]
            stress = stresses[idx] if stresses is not None else None

            # Use precomputed energy per atom
            entry["Energy (before) [eV/atom]"] = energy_per_atom[idx]
            forces_before = _get_force_stats(force)
            for k, v in forces_before.items():
                entry[f"{k} (before) [eV/Å]"] = v

            # Get the chemical formula and ensure no spaces
            full_formula = atoms.get_chemical_formula().replace(" ", "")

            # Save initial structure as CIF if requested
            structure_before = AseAtomsAdaptor.get_structure(atoms)
            if self.save_cif:
                self._save_structure_as_cif(structure_before, idx, full_formula, energy_per_atom[idx])

            # Determine if this structure should be optimized based on top_n
            should_optimize = idx in top_n_indices

            # Initialize trajectory and log path
            traj = None
            log_path = None

            if should_optimize:
                # Set up trajectory file only for structures that will be optimized
                if self.save_trajectory:
                    if self.group_output_files_by_formula:
                        formula_dir = os.path.join(self.save_trajectory, full_formula)
                        os.makedirs(formula_dir, exist_ok=True)
                        traj_path = os.path.join(formula_dir, f"{full_formula}_{idx}.traj")
                    else:
                        traj_path = os.path.join(self.save_trajectory, f"{full_formula}_{idx}.traj")
                    traj = _SafeTrajectory(traj_path, atoms)

                # Set up log file path only for structures that will be optimized
                if self.logfile not in (None, "-"):
                    if self.group_output_files_by_formula:
                        formula_dir = os.path.join(self.logfile, full_formula)
                        os.makedirs(formula_dir, exist_ok=True)
                        log_path = os.path.join(formula_dir, f"{full_formula}_{idx}.log")
                    else:
                        log_path = os.path.join(self.logfile, f"{full_formula}_{idx}.log")

                # Optimization step 0 - Relax atoms only
                if self.keep_symmetry_level > 0:
                    atoms.set_constraint(FixSymmetry(atoms, symprec=1e-3, adjust_positions=True, adjust_cell=False))

                start = time.perf_counter()
                with _open_log_writer(log_path, "# Step 0: Relax atoms only\n") as f:
                    _ = FIRE(atoms, logfile=f).run(fmax=0.1)
                entry["Time elapsed (step 0) [s]"] = time.perf_counter() - start
                atoms.set_constraint()
                if traj is not None:
                    traj.write(atoms)

                # Optimization step 1 - Relax cell
                atoms.set_constraint(FixAtoms(indices=range(len(atoms))))
                ucf = UnitCellFilter(atoms)
                start = time.perf_counter()
                with _open_log_writer(log_path, "# Step 1: Fix atoms, optimize lattice\n") as f:
                    _ = FIRE(ucf, logfile=f).run(fmax=0.1, steps=150)
                entry["Time elapsed (step 1) [s]"] = time.perf_counter() - start
                atoms.set_constraint()
                if traj is not None:
                    traj.write(atoms)

                # Optimization step 2 - Final relaxation
                if self.keep_symmetry_level == 2:
                    atoms.set_constraint(FixSymmetry(atoms, symprec=1e-3, adjust_positions=True, adjust_cell=False))

                start = time.perf_counter()
                with _open_log_writer(log_path, "# Step 2: Fix lattice, relax atoms\n") as f:
                    opt2 = FIRE(atoms, logfile=f)
                    for _ in range(10):
                        opt2.run(fmax=0.05, steps=100)
                        if opt2.converged():
                            break
                entry["Time elapsed (step 2) [s]"] = time.perf_counter() - start
                entry["Converged (final)"] = opt2.converged()
                atoms.set_constraint()

                # After stats
                entry["Total time elapsed [s]"] = (
                    entry["Time elapsed (step 0) [s]"]
                    + entry["Time elapsed (step 1) [s]"]
                    + entry["Time elapsed (step 2) [s]"]
                )
            else:
                # Skip optimization, fill in default values
                entry["Time elapsed (step 0) [s]"] = 0
                entry["Time elapsed (step 1) [s]"] = 0
                entry["Time elapsed (step 2) [s]"] = 0
                entry["Total time elapsed [s]"] = 0
                entry["Converged (final)"] = False

            # Write the final state to trajectory and close it (only if it exists)
            if traj is not None:
                traj.write(atoms)
                traj.close()

            # Always evaluate the final state
            energy_per_atom_after = atoms.get_potential_energy() / len(atoms)
            entry["Energy (after) [eV/atom]"] = energy_per_atom_after
            forces_after = _get_force_stats(atoms.get_forces())
            for k, v in forces_after.items():
                entry[f"{k} (after) [eV/Å]"] = v

            try:
                stress = atoms.get_stress()
                entry["Max stress (final) [eV/Å³]"] = float(np.max(np.abs(stress)))
            except Exception:
                entry["Max stress (final) [eV/Å³]"] = None

            structure_before = AseAtomsAdaptor.get_structure(structures_list[idx])
            structure_after = AseAtomsAdaptor.get_structure(atoms)
            entry["Space group (before)"] = structure_before.get_space_group_info()[1]
            space_group_after = structure_after.get_space_group_info()[1]
            entry["Space group (after)"] = space_group_after

            # Save optimized structure as CIF if requested and if it was optimized
            if self.save_cif and should_optimize:
                self._save_structure_as_cif(
                    structure_after, idx, full_formula, energy_per_atom_after, is_optimized=True
                )

            if self.groundtruth is not None:
                # Use pre-computed dissimilarity for the initial structure
                d_before = dissimilarities_before[idx]
                # Calculate dissimilarity for the optimized structure
                d_after = calculate_structure_dissimilarity(self.groundtruth, structure_after)[0]
                entry["Dissimilarity (before)"] = d_before
                entry["Dissimilarity (after)"] = d_after

            optimized_structures.append(atoms)
            all_entries.append(entry)

        df = pd.DataFrame(all_entries)

        # Final column order (manually defined, stable and clear)
        column_order = [
            "index",
            "Energy (before) [eV/atom]",
            "Energy (after) [eV/atom]",
            "Space group (before)",
            "Space group (after)",
            "Time elapsed (step 0) [s]",
            "Time elapsed (step 1) [s]",
            "Time elapsed (step 2) [s]",
            "Total time elapsed [s]",
            "Mean force (before) [eV/Å]",
            "Mean force (after) [eV/Å]",
            "Max force (before) [eV/Å]",
            "Max force (after) [eV/Å]",
            "Min force (before) [eV/Å]",
            "Min force (after) [eV/Å]",
            "Std force (before) [eV/Å]",
            "Std force (after) [eV/Å]",
            "Max stress (final) [eV/Å³]",
            "Converged (final)",
            "Dissimilarity (before)",
            "Dissimilarity (after)",
        ]
        # Filter column_order to only include columns that exist in the df
        column_order = [col for col in column_order if col in df.columns]
        # Add any extra columns not in the list
        column_order += [col for col in df.columns if col not in column_order]
        df = df[column_order]

        return optimized_structures, df
