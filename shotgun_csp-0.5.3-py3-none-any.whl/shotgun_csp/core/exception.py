# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0


class GenerationError(Exception):
    """
    Exception raised when there is an error during the generation process.

    :param cls: The class where the error occurred. Can be None.
    :param message: A descriptive error message.
    """

    def __init__(self, cls_or_instance, message: str):
        self.message = message
        if cls_or_instance is None:
            super().__init__(f"GenerationError -- {message}")
        else:
            if isinstance(cls_or_instance, type):
                super().__init__(f"GenerationError from <{cls_or_instance.__name__}> -- {message}")
            else:
                super().__init__(f"GenerationError from <{cls_or_instance.__class__.__name__}> -- {message}")
