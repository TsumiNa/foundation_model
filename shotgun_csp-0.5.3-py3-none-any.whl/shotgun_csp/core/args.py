# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

from copy import copy
from functools import cached_property
from typing import Dict, Optional, Tuple

import numpy as np
from numpy import float64
from pydantic import BaseModel, Field, computed_field, model_validator

from shotgun_csp.core.exception import GenerationError
from shotgun_csp.core.utils import SPG_TYPES, WY
from shotgun_csp.core.utils.const import AVG_WY_DIST


class GeneratorArgs(BaseModel):
    """
    A class to handle and validate crystal generation parameters.

    This class manages various parameters required for crystal structure generation,
    including cell volume, space group, angular constraints, and Wyckoff position priorities.

    Attributes:
        volume_of_cell (float): Volume of the crystal cell (must be > 10)
        space_group_num (int): Space group number (1-230)
        max_angle_degree (float): Maximum allowed angle in degrees (default: 150.0)
        min_angle_degree (float): Minimum allowed angle in degrees (default: 20.0)
        max_attempts (int): Maximum number of generation attempts (default: 1000)
        decimals (int): Number of decimal places for rounding (default: 7)
        variance_of_volume (float): Allowed volume variance (default: volume_of_cell * 0.1)
        low_length (float): Minimum cell length (default: volume_of_cell^(1/3) * 0.5)
        high_length (float): Maximum cell length (default: volume_of_cell^(1/3) * 1.5)
        wy_priority (Dict[str, float]): Wyckoff position priorities (default: equal priorities)
        wyckoff_mixing_ratio (float): Ratio to mix between wy_priority and avg_wyckoff_distribution values.
            A value of 0.0 (default) means use only wy_priority values, while 1.0 means use only
            avg_wyckoff_distribution values. Values between 0.0 and 1.0 will linearly interpolate
            between the two distributions.
    """

    volume_of_cell: float
    space_group_num: int
    max_angle_degree: float = 150.0
    min_angle_degree: float = 20.0
    max_attempts: int = 1_000
    decimals: int = 7
    wyckoff_mixing_ratio: float = 0.0
    use_mesh: bool = False
    perturbation: float = 0.0
    atomic_dist_decay_rate: float = 0.002
    check_atomic_dist: bool = False
    structure_matcher_params: Dict[str, float] = Field(default_factory=lambda: {"ltol": 0.05, "angle_tol": 3})
    variance_of_volume: Optional[float] = None
    low_length: Optional[float] = None
    high_length: Optional[float] = None
    wy_priority: Optional[Dict[str, float]] = None

    model_config = {
        "arbitrary_types_allowed": True,  # Allow numpy types
        "json_encoders": {np.ndarray: lambda v: v.tolist(), np.float64: lambda v: float(v), np.int64: lambda v: int(v)},
    }

    # Validate and set default values
    @model_validator(mode="after")
    def validate_and_set_defaults(self) -> "GeneratorArgs":
        # Validate volume_of_cell
        if self.volume_of_cell < 10:
            raise GenerationError(self, "volume_of_cell must be greater than 10")

        # Set default variance_of_volume
        if self.variance_of_volume is None:
            self.variance_of_volume = self.volume_of_cell * 0.1

        # Set default low_length and high_length
        if self.low_length is None:
            self.low_length = self.volume_of_cell ** (1 / 3) * 0.4
        if self.high_length is None:
            self.high_length = self.volume_of_cell ** (1 / 3) * 1.6

        # Validate other parameters
        if self.max_attempts < 100:
            raise GenerationError(self, "max_attempts must be greater than 100")
        if not (1 <= self.space_group_num <= 230):
            raise GenerationError(self, f"Space group must be between 1 and 230, got {self.space_group_num}")
        if self.variance_of_volume < 0 or self.variance_of_volume > self.volume_of_cell / 4:
            raise GenerationError(self, "variance_of_volume must be between 0 and volume_of_cell / 4")
        if self.min_angle_degree < 10.0 or self.max_angle_degree > 170.0:
            raise GenerationError(self, "angle_degree must be between 10 and 150")
        if self.min_angle_degree >= self.max_angle_degree:
            raise GenerationError(self, "min_angle_degree must be greater than max_angle_degree")
        if not (0.0 <= self.wyckoff_mixing_ratio <= 1.0):
            raise GenerationError(self, "wyckoff_mixing_ratio must be between 0.0 and 1.0")

        # Process wy_priority
        wyckoff_data = WY[self.space_group_num - 1]

        if self.wy_priority:
            # Validate that all keys in wy_priority exist in wyckoff_data
            invalid_keys = [key for key in self.wy_priority if key not in wyckoff_data]
            if invalid_keys:
                raise GenerationError(
                    self,
                    f"Invalid Wyckoff positions in wy_priority for space group "
                    f"{self.space_group_num}: {', '.join(invalid_keys)}",
                )

            # Set default values for all Wyckoff positions
            for letter in wyckoff_data:
                if letter not in self.wy_priority:
                    self.wy_priority[letter] = 0.0
        else:
            # Default equal probabilities
            self.wy_priority = {letter: 1.0 for letter in wyckoff_data}

        return self

    @computed_field
    @cached_property
    def candidate_pool(self) -> list:
        if self.wyckoff_mixing_ratio == 0.0:
            # Use original wy_priority values
            priorities = self.wy_priority
        else:
            # Mix wy_priority with avg_wyckoff_distribution
            mixed_priorities = {}

            # Calculate mixed priorities
            for letter in self.wy_priority:
                orig_priority = self.wy_priority[letter]
                avg_priority = self.avg_wyckoff_distribution.get(letter, 0.0)
                mixed_priorities[letter] = (
                    1 - self.wyckoff_mixing_ratio
                ) * orig_priority + self.wyckoff_mixing_ratio * avg_priority

            # Normalize the mixed distribution to ensure it sums to 1.0
            total = sum(mixed_priorities.values())
            if total > 0:
                for letter in mixed_priorities:
                    mixed_priorities[letter] /= total

            priorities = mixed_priorities

        # Create the candidate pool
        candidate_pool = []
        for letter, prob in priorities.items():
            multiplicity, reuse, _ = self.wyckoff_data[letter]
            candidate_pool.append((int(multiplicity), letter, reuse, float(prob)))

        return candidate_pool

    @computed_field
    @cached_property
    def scale(self) -> int:
        # Set scaling factor based on space group type
        spg_type = SPG_TYPES[self.space_group_num - 1]
        return {
            "A": 2,
            "B": 2,
            "C": 2,
            "I": 2,
            "S": 3,
            "T": 3,
            "F": 4,
        }.get(spg_type, 1)

    @computed_field
    @cached_property
    def avg_wyckoff_distribution(self) -> Dict[str, float]:
        spg = str(self.space_group_num)
        return copy(AVG_WY_DIST[spg] if spg in AVG_WY_DIST else self.wy_priority)

    @computed_field
    @cached_property
    def identical_sites(self) -> np.ndarray:
        spg_type = SPG_TYPES[self.space_group_num - 1]

        if spg_type == "A":
            identical_sites = [[0, 1 / 2, 1 / 2]]
        elif spg_type == "B":
            identical_sites = [[1 / 2, 0, 1 / 2]]
        elif spg_type == "C":
            identical_sites = [[1 / 2, 1 / 2, 0]]
        elif spg_type == "I":
            identical_sites = [[1 / 2, 1 / 2, 1 / 2]]
        elif spg_type == "S":
            identical_sites = [[1 / 3, 1 / 3, 2 / 3], [2 / 3, 2 / 3, 1 / 3]]
        elif spg_type == "T":
            identical_sites = [[1 / 3, 2 / 3, 1 / 3], [2 / 3, 1 / 3, 2 / 3]]
        elif spg_type == "F":
            identical_sites = [[0, 1 / 2, 1 / 2], [1 / 2, 0, 1 / 2], [1 / 2, 1 / 2, 0]]
        else:
            identical_sites = []

        return np.array(identical_sites, dtype=float64)

    @computed_field
    @cached_property
    def wyckoff_data(self) -> Dict[str, Tuple[int, bool, float]]:
        return WY[self.space_group_num - 1]
