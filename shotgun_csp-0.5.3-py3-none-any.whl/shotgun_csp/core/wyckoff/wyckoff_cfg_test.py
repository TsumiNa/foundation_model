# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0


from collections import Counter

import numba as nb
import numpy as np
import pytest

from shotgun_csp.core import GeneratorArgs
from shotgun_csp.core.exception import GenerationError

# Import the functions directly from configuration.py
from shotgun_csp.core.wyckoff.wyckoff_cfg import (
    WyckoffCfgGenerator,
    _gen_one,
    _list_to_dict,
    _sample_weighted_index_nb,
    _shuffle_array_nb,
)


def test_sample_weighted_index_uniform():
    # Test with uniform weights
    weights = np.array([1.0, 1.0, 1.0, 1.0])

    # Since sampling is random, we'll test the distribution
    # by running multiple samples and checking the counts
    # Set seed for reproducibility
    counter = Counter()
    n_samples = 10000

    for _ in range(n_samples):
        idx = _sample_weighted_index_nb(weights)
        counter[idx] += 1

        # Check that returned indices are within bounds
        assert idx >= 0
        assert idx < len(weights)

    # Check that all indices are sampled roughly equally
    for i in range(len(weights)):
        assert i in counter
        # Allow for some randomness, but each index should be sampled ~25% of the time
        expected = n_samples / len(weights)
        assert abs(counter[i] / n_samples - 1 / len(weights)) < 0.05


def test_sample_weighted_index_non_uniform():
    # Test with non-uniform weights
    weights = np.array([1.0, 2.0, 3.0, 4.0])
    total_weight = sum(weights)
    counter = Counter()
    n_samples = 10000

    for _ in range(n_samples):
        idx = _sample_weighted_index_nb(weights)
        counter[idx] += 1

    # Check that indices are sampled proportionally to weights
    for i in range(len(weights)):
        assert i in counter
        expected_ratio = weights[i] / total_weight
        actual_ratio = counter[i] / n_samples
        assert abs(actual_ratio - expected_ratio) < 0.05


def test_shuffle_array():
    # Test shuffling a numeric array
    arr = np.arange(20)
    original = arr.copy()

    _shuffle_array_nb(arr)

    # The array should be shuffled (different order)
    assert not np.array_equal(arr, original)

    # The array should contain the same elements
    assert set(arr) == set(original)

    # Test multiple shuffles for randomness
    shuffled_arrays = []
    for _ in range(10):
        arr = np.arange(10)
        _shuffle_array_nb(arr)
        shuffled_arrays.append(arr.copy())

    # Check that we get different permutations
    unique_permutations = set(tuple(arr) for arr in shuffled_arrays)
    assert len(unique_permutations) > 1


def test_wyckoff_cfg_generator_init():
    """Test initialization of WyckoffCfgGenerator."""

    # Create a simple GeneratorArgs
    args = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=1,  # Space group number is required
    )

    # Initialize the generator
    generator = WyckoffCfgGenerator(args)

    assert generator._candidate_pool == args.candidate_pool
    assert generator._scale == args.scale
    assert generator._wy_priority == args.wy_priority
    assert generator._max_attempts == args.max_attempts


def test_wyckoff_cfg_generator_gen_one():
    """Test __call__ of WyckoffCfgGenerator."""

    # Create a simple GeneratorArgs
    args = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=1,
        wy_priority={"a": 1.0},  # Space group 1 only has Wyckoff position 'a'
        max_attempts=100,
    )

    # Initialize the generator
    generator = WyckoffCfgGenerator(args)

    # Test with valid composition
    composition = {"Si": 4, "O": 8}
    config = generator(composition)

    # Check that the configuration has the right elements
    assert isinstance(config, dict)
    assert set(config.keys()) == {"Si", "O"}

    # Check that all letters in the config are from the candidate pool
    valid_letters = set(item[1] for item in args.candidate_pool)
    for element, letters in config.items():
        for letter in letters:
            assert letter in valid_letters


def test_wyckoff_cfg_generator_multiple_configs():
    """Test generating multiple configurations."""

    # Create a simple GeneratorArgs
    args = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=1,
        wy_priority={"a": 1.0},  # Space group 1 only has Wyckoff position 'a'
        max_attempts=100,
    )

    # Initialize the generator
    generator = WyckoffCfgGenerator(args)

    # Test generating multiple configurations
    composition = {"Si": 4, "O": 8}
    expect_size = 5

    configs = generator(composition, expect_size=expect_size)

    # Check that we get the right number of configurations
    assert isinstance(configs, list)
    assert len(configs) == expect_size

    # Check that all configurations have the right elements
    for config in configs:
        if config:  # Some configurations might be empty if generation failed
            assert set(config.keys()) == {"Si", "O"}


def test_wyckoff_cfg_generator_invalid_inputs():
    """Test error handling for invalid inputs."""

    # Create a simple GeneratorArgs
    args = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=1,
        wy_priority={"a": 1.0},  # Space group 1 only has Wyckoff position 'a'
        max_attempts=100,
    )

    # Initialize the generator
    generator = WyckoffCfgGenerator(args)

    # Test with invalid expect_size
    with pytest.raises(GenerationError, match="Expect size must be greater than 0"):
        generator({"Si": 4}, expect_size=-1)

    # Test with empty composition
    with pytest.raises(GenerationError, match="Composition is empty"):
        generator({})

    # Test with invalid composition
    with pytest.raises(GenerationError, match="Invalid composition: list index out of range"):
        generator({"Invalid Element": 4})


def test_wyckoff_cfg_generator_numba_gen():
    """Test get_generator method of WyckoffCfgGenerator."""

    # Create a simple GeneratorArgs
    args = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=1,
        wy_priority={"a": 1.0},  # Space group 1 only has Wyckoff position 'a'
        max_attempts=100,
    )

    # Test with valid composition
    composition = {"Si": 4, "O": 8}

    # Initialize the generator
    pool_ = tuple(args.candidate_pool)
    scale_ = args.scale
    max_attempts_ = args.max_attempts
    comp_ = tuple((k, int(v) * scale_) for k, v in composition.items())

    ret = _gen_one(
        comp_,
        pool_,
        max_attempts_,
    )

    # Check that the configuration has the right elements
    assert isinstance(ret, nb.typed.List)
    assert len(ret) == 12

    assert set([i for i, _ in ret]) == {"Si", "O"}
    assert set([i for _, i in ret]) == {"a"}

    ret = _list_to_dict(ret)
    assert set(ret.keys()) == {"Si", "O"}
    assert set(ret["Si"]) == {"a"}
    assert set(ret["O"]) == {"a"}
    assert len(ret["Si"]) == 4
    assert len(ret["O"]) == 8


def test_wyckoff_cfg_generator_numba_gen_in_order():
    """Test get_generator method of WyckoffCfgGenerator."""

    # Create a simple GeneratorArgs
    args = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=5,
        wy_priority={"a": 1.0, "b": 1.0, "c": 1.0},
        max_attempts=100,
    )

    # Test with valid composition
    composition = {"Si": 4, "O": 8}

    # Initialize the generator
    pool_ = tuple(args.candidate_pool)
    scale_ = args.scale
    max_attempts_ = args.max_attempts
    comp_ = tuple((k, int(v) * scale_) for k, v in composition.items())

    ret = _gen_one(
        comp_,
        pool_,
        max_attempts_,
    )

    ret = _list_to_dict(ret)

    assert sorted(ret.keys()) == list(ret.keys())
    assert sorted(ret["O"]) == list(ret["O"])


def test_wyckoff_mixing_ratio_basic():
    """Test the wyckoff_mixing_ratio parameter in WyckoffCfgGenerator.__call__."""

    # Test using a simpler approach - directly verify the functionality
    # Create a GeneratorArgs with custom wy_priority and a space group with avg_wyckoff_distribution
    # We'll use space group 5 which has distribution values in AVG_WY_DIST
    args = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=5,  # Use space group 5 which has avg_wyckoff_distribution values
        # Set wy_priority different from avg_wyckoff_distribution for testing
        wy_priority={"a": 0.5, "b": 0.3, "c": 0.2},
        max_attempts=100,
    )

    generator = WyckoffCfgGenerator(args)

    # Verify that the avg_wyckoff_distribution is stored and accessible
    assert hasattr(generator, "_avg_wyckoff_distribution")
    assert isinstance(generator._avg_wyckoff_distribution, dict)

    # Test functionality directly
    composition = {"Si": 4}

    # Case 1: Use default ratio (0.0) - should use only wy_priority
    result1 = generator(composition)
    assert isinstance(result1, dict)

    # Case 2: Use ratio 1.0 - should use only avg_wyckoff_distribution
    result2 = generator(composition, wyckoff_mixing_ratio=1.0)
    assert isinstance(result2, dict)

    # Case 3: Use ratio 0.5 - should mix both
    result3 = generator(composition, wyckoff_mixing_ratio=0.5)
    assert isinstance(result3, dict)


def test_wyckoff_mixing_ratio_detailed():
    """Test the detailed functionality of wyckoff_mixing_ratio at both GeneratorArgs and __call__ levels."""
    from shotgun_csp.core.utils.const import AVG_WY_DIST

    # Use space group 10 which has a rich avg_wyckoff_distribution
    space_group = 10
    sg_key = str(space_group)

    # Create a GeneratorArgs with custom wy_priority
    args1 = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=space_group,
        # Set custom wy_priority that's different from avg_wyckoff_distribution
        wy_priority={"a": 0.9, "b": 0.05, "c": 0.05},
    )

    # Verify avg_wyckoff_distribution is loaded
    assert args1.avg_wyckoff_distribution == AVG_WY_DIST[sg_key]
    assert args1.wyckoff_mixing_ratio == 0.0  # Default is 0.0

    # Initialize the generator
    generator1 = WyckoffCfgGenerator(args1)

    # Test 1: Default ratio (0.0) - should use only wy_priority
    # Get priorities from the candidate pool
    default_priorities = {letter: prob for _, letter, _, prob in generator1._candidate_pool}

    # The priorities should match wy_priority exactly for key letters
    assert abs(default_priorities.get("a", 0) - args1.wy_priority.get("a", 0)) < 1e-10
    assert abs(default_priorities.get("b", 0) - args1.wy_priority.get("b", 0)) < 1e-10
    assert abs(default_priorities.get("c", 0) - args1.wy_priority.get("c", 0)) < 1e-10

    # Test 2: With wyckoff_mixing_ratio = 0.5
    args2 = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=space_group,
        wy_priority={"a": 0.9, "b": 0.05, "c": 0.05},
        wyckoff_mixing_ratio=0.5,  # Mix 50% with avg_wyckoff_distribution
    )

    assert args2.wyckoff_mixing_ratio == 0.5

    generator2 = WyckoffCfgGenerator(args2)

    # Get priorities from the candidate pool
    mixed_priorities = {letter: prob for _, letter, _, prob in generator2._candidate_pool}

    # The priorities should be a mix of wy_priority and avg_wyckoff_distribution
    # Letter 'a' should have a value between wy_priority and avg_distribution
    # (exact values depend on normalization)
    a_in_wy = args2.wy_priority.get("a", 0.0)
    a_in_avg = args2.avg_wyckoff_distribution.get("a", 0.0)
    assert mixed_priorities.get("a", 0) > min(a_in_wy, a_in_avg)
    assert mixed_priorities.get("a", 0) < max(a_in_wy, a_in_avg)

    # For letters not in our wy_priority but in avg_distribution
    # They should now have non-zero values
    avg_letters = set(args2.avg_wyckoff_distribution.keys()) - set(args2.wy_priority.keys())
    if avg_letters:  # If there are such letters
        sample_letter = next(iter(avg_letters))
        assert mixed_priorities.get(sample_letter, 0) > 0

    # Test 3: Override wyckoff_mixing_ratio in __call__
    composition = {"Si": 4}

    # Use generator1 (which has wyckoff_mixing_ratio=0.0 in GeneratorArgs)
    # but override in __call__ to use only avg_wyckoff_distribution
    result1 = generator1(composition, wyckoff_mixing_ratio=1.0)
    assert isinstance(result1, dict)

    # Use generator2 (which has wyckoff_mixing_ratio=0.5 in GeneratorArgs)
    # with None to use the pre-mixed value
    result2 = generator2(composition, wyckoff_mixing_ratio=None)
    assert isinstance(result2, dict)
