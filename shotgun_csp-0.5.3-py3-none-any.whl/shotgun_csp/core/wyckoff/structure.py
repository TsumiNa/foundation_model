# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

from collections import defaultdict
from functools import cached_property
from typing import Any, List, Union

import numpy as np
from ase import Atoms
from numpy.typing import NDArray
from pydantic import BaseModel, field_serializer, field_validator
from pymatgen.core import Structure


class CrystalStructure(BaseModel):
    """Crystal structure representation.

    Attributes:
        space_group_num: Space group number (1-230)
        volume: Unit cell volume
        lattice: 3x3 lattice matrix
        particles: Nx3 matrix of particle coordinates
        elements: List of element symbols
        wyckoff_letters: List of Wyckoff letters
    """

    space_group_num: int
    volume: Union[float, int]
    lattice: NDArray[np.float_]  # 3x3 matrix
    positions: NDArray[np.float_]  # Nx3 matrix
    atoms: List[str]
    wyckoff_letters: List[str]

    # Configure the model to allow arbitrary types (needed for NumPy arrays)
    model_config = {"arbitrary_types_allowed": True}

    # Validators for NumPy arrays to handle serialization and deserialization
    @field_validator("lattice", mode="before")
    def validate_lattice(cls, v: Any) -> NDArray[np.float_]:
        """Convert list to numpy array if needed."""
        if isinstance(v, list):
            return np.array(v, dtype=np.float_)
        return v

    @field_validator("positions", mode="before")
    def validate_positions(cls, v: Any) -> NDArray[np.float_]:
        """Convert list to numpy array if needed."""
        if isinstance(v, list):
            return np.array(v, dtype=np.float_)
        return v

    # Serializers for NumPy arrays when converted to JSON or dict
    @field_serializer("lattice")
    def serialize_lattice(self, v: NDArray[np.float_]) -> List[List[float]]:
        """Convert numpy array to list for serialization."""
        return v.tolist()

    @field_serializer("positions")
    def serialize_positions(self, v: NDArray[np.float_]) -> List[List[float]]:
        """Convert numpy array to list for serialization."""
        return v.tolist()

    def __eq__(self, other: object) -> bool:
        """Compare two Crystal objects for equality."""
        if not isinstance(other, CrystalStructure):
            return NotImplemented

        return (
            np.allclose(self.lattice, other.lattice, atol=1e-5)
            and np.allclose(self.positions, other.positions, atol=1e-5)
            and self.atoms == other.atoms
        )

    def __len__(self) -> int:
        return len(self.atoms)

    @cached_property
    def pymatgen_structure(self):
        return Structure(lattice=self.lattice, coords=self.positions, species=self.atoms)

    @cached_property
    def ase_atoms(self):
        return Atoms(symbols=self.atoms, cell=self.lattice, scaled_positions=self.positions, pbc=True)

    @cached_property
    def wyckoff_cfg(self):
        """Configuration for Wyckoff positions."""
        wyckoff_dict = defaultdict(list)
        for l, e in zip(self.wyckoff_letters, self.atoms):
            wyckoff_dict[e].append(l)
        return dict(wyckoff_dict)

    def to_dict(self) -> dict:
        """Convert the model to a dictionary, excluding cached properties.

        Returns:
            A dictionary representation of the model without cached properties.
        """
        # Find all cached_properties to exclude
        exclude_set = set()
        for attr_name, attr_value in self.__class__.__dict__.items():
            if isinstance(attr_value, cached_property):
                exclude_set.add(attr_name)

        # Return the dictionary excluding cached properties
        return self.model_dump(exclude=exclude_set)
