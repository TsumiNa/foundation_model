# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

from collections import defaultdict

import numba as nb
import numpy as np
from beartype.typing import Dict, List, Tuple
from numba import njit, prange
from numba_progress import ProgressBar
from pymatgen.core import Composition

from shotgun_csp.core import GeneratorArgs
from shotgun_csp.core.exception import GenerationError


@njit(nogil=True, fastmath=True, cache=False)
def _sample_weighted_index_nb(weights: np.ndarray) -> int:
    """Sample an index based on weights using Numba.

    Args:
        weights: Array of weights

    Returns:
        Sampled index
    """
    cumsum = np.cumsum(weights)
    r = np.random.random() * cumsum[-1]
    return np.searchsorted(cumsum, r)


@njit(nogil=True, fastmath=True, cache=False)
def _shuffle_array_nb(arr: np.ndarray) -> None:
    """Shuffle an array in-place using Numba."""

    # Shuffle composition list
    n = len(arr)
    _idx = np.arange(n)

    np.random.shuffle(_idx)
    for i, j in enumerate(_idx):
        temp = arr[i]
        arr[i] = arr[j]
        arr[j] = temp


_nb_type_str_str = nb.types.UniTuple(nb.types.unicode_type, 2)


@njit(nogil=True, fastmath=True)
def _gen_one(comp_, pool_, max_attempts_) -> List[Tuple[str, str]]:
    # Initialize variables
    empty_pool = True
    for _ in prange(max_attempts_):
        if empty_pool:
            ret: List[Tuple[str, str]] = nb.typed.List.empty_list(_nb_type_str_str)
            used_letter: List[str] = nb.typed.List.empty_list(nb.types.string)
            comp_list: List = nb.typed.List([a for a in comp_])
            empty_pool = False

        # Shuffle composition list
        _shuffle_array_nb(comp_list)

        # Process each element
        n = len(comp_list)
        for i in prange(n):
            element, num = comp_list[i]
            # Filter available Wyckoff positions
            # pool: [(multiplicity: int, letter: str, reuse: bool, priority: float)]
            pool = [
                (multiplicity, letter, reuse, proba)
                for multiplicity, letter, reuse, proba in pool_
                if letter not in used_letter and multiplicity <= num and proba > 0
            ]

            if len(pool) == 0:
                # No available Wyckoff positions
                empty_pool = True
                break

            # Sample position using weighted probabilities
            probs = np.array([p[3] for p in pool])
            idx = _sample_weighted_index_nb(probs)
            mult, letter, reuse, _ = pool[idx]

            # Update tracking
            if not reuse:
                used_letter.append(letter)

            comp_list[i] = (element, num - mult)
            ret.append((element, letter))

        # Remove fully assigned elements
        comp_list = nb.typed.List([(e, n) for e, n in comp_list if n > 0])
        if len(comp_list) == 0:
            return ret

    return nb.typed.List.empty_list(_nb_type_str_str)


@njit(nogil=True, fastmath=True)
def _serial_gen(expect_size, comp_, pool_, max_attempts_):
    return [_gen_one(comp_, pool_, max_attempts_) for _ in range(expect_size)]


@njit(nogil=True, fastmath=True)
def _serial_gen_with_process_bar(expect_size, progress_proxy, comp_, pool_, max_attempts_):
    ret = []
    for _ in range(expect_size):
        ret.append(_gen_one(comp_, pool_, max_attempts_))
        progress_proxy.update(1)
    return ret


def _list_to_dict(lst: List[Tuple[str, str]]) -> Dict[str, List[str]]:
    result = defaultdict(list)
    for key, value in lst:
        result[key].append(value)

    # Sort the values for each key
    # and convert the defaultdict to a regular dict
    return {k: tuple(sorted(result[k])) for k in sorted(result)}


def _drop_duplicates(dict_list: List[Dict]) -> List[Dict]:
    """
    Remove duplicate dictionaries from a list.
    Two dictionaries are considered duplicates if they have the same key-value pairs,
    regardless of the order.

    Parameters:
        dict_list (list of dict): The list of dictionaries.

    Returns:
        list of dict: A list of unique dictionaries.
    """
    # Create a dictionary comprehension where each key is a tuple of sorted dictionary items.
    unique_dicts = {tuple(sorted(d.items())): d for d in dict_list}.values()
    return list(unique_dicts)


class WyckoffCfgGenerator:
    """Class for generating Wyckoff configurations for a given composition and space group."""

    def __init__(self, generator_args: GeneratorArgs):
        """
        Initializes the configuration for Wyckoff position generation.

        Args:
            generator_args (GeneratorArgs): An object containing the following attributes:
            - candidate_pool (List[Tuple[int, str, bool, float]]): A list of tuples representing
              the candidate pool for Wyckoff positions. Each tuple contains:
                * multiplicity (int): The multiplicity of the Wyckoff position.
                * letter (str): The Wyckoff letter.
                * reuse (bool): Whether the position can be reused.
                * priority (float): The priority or probability weight for selection.
            - scale (int): A scaling factor applied to the composition values.
            - wy_priority (Dict[str, float]): A dictionary mapping Wyckoff letters to their
              priority weights.
            - max_attempts (int): The maximum number of attempts allowed for generating a
              valid configuration.
        """
        self._candidate_pool = generator_args.candidate_pool
        self._scale = generator_args.scale
        self._wy_priority = generator_args.wy_priority
        self._max_attempts = generator_args.max_attempts
        self._avg_wyckoff_distribution = generator_args.avg_wyckoff_distribution

    def __call__(
        self,
        composition: Dict[str, float],
        *,
        expect_size: int = 1,
        progress_bar: bool = False,
        drop_duplicates: bool = False,
        wyckoff_mixing_ratio: float = None,
    ):
        """
        Generate one or more candidate structures based on the provided composition.

        Args:
            composition (Dict[str, float]): A dictionary representing the composition,
                where keys are element symbols and values are their respective amounts.
            expect_size (int, optional): The number of candidate structures to generate.
                Defaults to 1.
            progress_bar (bool, optional): Whether to display a progress bar during generation.
                Defaults to False.
            drop_duplicates (bool, optional): Whether to remove duplicate structures from the
                results. Defaults to False.
            wyckoff_mixing_ratio (float, optional): Ratio to mix between wy_priority and
                avg_wyckoff_distribution values. If None (default), uses the value from generator_args.
                A value of 0.0 means use only wy_priority values, while 1.0 means use only
                avg_wyckoff_distribution values. Values between 0.0 and 1.0 will linearly
                interpolate between the two distributions.

        Returns:
            Dict or List[Dict]: A single candidate structure as a dictionary if `expect_size` is 1,
                otherwise a list of candidate structure dictionaries.

        Raises:
            GenerationError: If the composition is empty, invalid, or if `expect_size` is less than 1.
        """
        if not composition:
            raise GenerationError(self, "Composition is empty")
        try:
            _ = Composition.from_dict(composition)
        except Exception as e:
            raise GenerationError(self, f"Invalid composition: {e}")

        comp_ = tuple((k, int(v) * self._scale) for k, v in composition.items())

        # Determine which wyckoff_mixing_ratio to use
        mixing_ratio = wyckoff_mixing_ratio

        # If wyckoff_mixing_ratio is None, use the value from generator_args
        # This allows passing a GeneratorArgs instance with a custom wyckoff_mixing_ratio
        if mixing_ratio is None:
            # Use the value stored in the _generator_args
            # Implicitly, this comes from self._candidate_pool which was pre-mixed
            pool_ = tuple(self._candidate_pool)
        else:
            # Explicit mixing ratio provided, need to mix on-the-fly
            if mixing_ratio == 0.0:
                # Use original wy_priority values
                pool_ = tuple(self._candidate_pool)
            else:
                # Mix wy_priority with avg_wyckoff_distribution
                mixed_priorities = {}

                # Calculate mixed priorities
                for letter in self._wy_priority:
                    orig_priority = self._wy_priority[letter]
                    avg_priority = self._avg_wyckoff_distribution.get(letter, 0.0)
                    mixed_priorities[letter] = (1 - mixing_ratio) * orig_priority + mixing_ratio * avg_priority

                # Normalize the mixed distribution to ensure it sums to 1.0
                total = sum(mixed_priorities.values())
                if total > 0:
                    for letter in mixed_priorities:
                        mixed_priorities[letter] /= total

                # Create a new candidate pool using the mixed priorities
                modified_pool = []
                for multiplicity, letter, reuse, _ in self._candidate_pool:
                    # Use the mixed priority instead of the original one
                    modified_pool.append((multiplicity, letter, reuse, float(mixed_priorities.get(letter, 0.0))))

                pool_ = tuple(modified_pool)

        max_attempts_ = self._max_attempts
        expect_size = int(expect_size)

        if expect_size < 1:
            raise GenerationError(self, "Expect size must be greater than 0")

        if expect_size == 1:
            return _list_to_dict(_gen_one(comp_, pool_, max_attempts_))
        else:
            if progress_bar:
                with ProgressBar(total=expect_size) as progress:
                    ret = _serial_gen_with_process_bar(expect_size, progress, comp_, pool_, max_attempts_)
            else:
                ret = _serial_gen(expect_size, comp_, pool_, max_attempts_)
        ret = [_list_to_dict(r_) for r_ in ret]

        if drop_duplicates:
            ret = _drop_duplicates(ret)
        return ret
