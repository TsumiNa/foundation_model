# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import numpy as np
from numba import njit, prange

# Pre-compute image translations (all length 3 combinations of [-1,0,1])
IMAGES = np.array(
    [
        [-1.0, -1.0, -1.0],
        [-1.0, -1.0, 0.0],
        [-1.0, -1.0, 1.0],
        [-1.0, 0.0, -1.0],
        [-1.0, 0.0, 0.0],
        [-1.0, 0.0, 1.0],
        [-1.0, 1.0, -1.0],
        [-1.0, 1.0, 0.0],
        [-1.0, 1.0, 1.0],
        [0.0, -1.0, -1.0],
        [0.0, -1.0, 0.0],
        [0.0, -1.0, 1.0],
        [0.0, 0.0, -1.0],
        [0.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
        [0.0, 1.0, -1.0],
        [0.0, 1.0, 0.0],
        [0.0, 1.0, 1.0],
        [1.0, -1.0, -1.0],
        [1.0, -1.0, 0.0],
        [1.0, -1.0, 1.0],
        [1.0, 0.0, -1.0],
        [1.0, 0.0, 0.0],
        [1.0, 0.0, 1.0],
        [1.0, 1.0, -1.0],
        [1.0, 1.0, 0.0],
        [1.0, 1.0, 1.0],
    ]
)


@njit(fastmath=True, nogil=True)
def _dot_2d_mod(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Compute dot product with modulo operation.

    Args:
        a: First matrix
        b: Second matrix

    Returns:
        Result matrix
    """
    ii, kk = a.shape  # ii = 27, kk = 3
    jj = b.shape[1]  # jj = 3

    o = np.zeros_like(a)
    for j in prange(jj):
        for k in prange(kk):
            for i in prange(ii):
                tmp = a[i, k] % 1.0
                if tmp < 0.0:
                    tmp += 1.0
                o[i, j] += tmp * b[k, j]

    return o


@njit(fastmath=True, nogil=True)
def _gram_schmidt_process(basis: np.ndarray) -> np.ndarray:
    """Perform Gram-Schmidt orthogonalization.

    Args:
        basis: Input basis vectors

    Returns:
        Orthogonalized basis
    """
    basis = basis.copy()
    n_vectors = basis.shape[0]

    for i in prange(1, n_vectors):
        for j in prange(i):
            b_i = basis[i]
            b_j = basis[j]
            alpha = np.dot(b_j, b_i) / np.dot(b_j, b_j)
            basis[i] = b_i - alpha * b_j

    return basis


@njit(fastmath=True, nogil=True)
def lll_reduce(basis: np.ndarray, delta: float = 0.75) -> tuple[np.ndarray, np.ndarray]:
    """Lattice reduction using the Lenstra-Lenstra-Lovász algorithm.

    Args:
        basis: A generating matrix for the lattice
        delta: Parameter in the Lovász condition (default: 0.75)

    Returns:
        Tuple of (reduced basis, transformation matrix)
    """
    basis = basis.copy()
    ortho = _gram_schmidt_process(basis)
    n = basis.shape[0]
    k = 1
    mapping = np.eye(3)

    while k < n:
        # Size reduction
        for j in prange(k - 1, -1, -1):
            o_j = ortho[j]
            b_k = basis[k]
            mu_kj = np.dot(o_j, b_k) / np.dot(o_j, o_j)

            if abs(mu_kj) > 0.5:
                round_mu_kj = round(mu_kj)
                basis[k] = b_k - round_mu_kj * basis[j]
                mapping[k] = mapping[k] - round_mu_kj * mapping[j]
                ortho = _gram_schmidt_process(basis)

        # Lovász condition
        o_k = ortho[k]
        sdot_o_k = np.dot(o_k, o_k)
        o_k_1 = ortho[k - 1]
        b_k = basis[k]
        sdot_o_k_1 = np.dot(o_k_1, o_k_1)
        mu_kk_1 = np.dot(o_k_1, b_k) / sdot_o_k_1

        if sdot_o_k >= sdot_o_k_1 * (delta - mu_kk_1 * mu_kk_1):
            k += 1
        else:
            # Swap vectors k and k-1
            basis[k], basis[k - 1] = basis[k - 1].copy(), basis[k].copy()
            mapping[k], mapping[k - 1] = mapping[k - 1].copy(), mapping[k].copy()
            ortho = _gram_schmidt_process(basis)
            k = max(k - 1, 1)

    return basis, mapping


@njit(["float64[:,:](float64[:,:],float64[:,:],optional(float64[:,:]))"], fastmath=True, nogil=True)
def pbc_all_distances(lattice: np.ndarray, frac_coords1: np.ndarray, frac_coords2: np.ndarray = None) -> np.ndarray:
    """Calculate shortest vectors between coordinates with periodic boundary conditions.

    Args:
        lattice: 3x3 lattice matrix
        frac_coords1: Nx3 matrix of fractional coordinates
        frac_coords2: Nx3 matrix of fractional coordinates

    Returns:
        NxN matrix of distances between sites
    """

    # Perform LLL reduction
    lll_matrix, mapping = lll_reduce(lattice)
    lll_inv = np.linalg.inv(mapping)

    frac_coords1 = np.ascontiguousarray(frac_coords1)  # Ensure contiguous array
    lll_inv = np.ascontiguousarray(lll_inv)

    # Get inverse coordinates
    n_sites1 = len(frac_coords1)
    fc1_ = np.dot(frac_coords1, lll_inv)
    cart_f1 = _dot_2d_mod(fc1_, lll_matrix)

    if frac_coords2 is not None:
        frac_coords2 = np.ascontiguousarray(np.asarray(frac_coords2))
        n_sites2 = len(frac_coords2)
        fc2_ = np.dot(frac_coords2, lll_inv)
        cart_f2 = _dot_2d_mod(fc2_, lll_matrix)
        reduced = False
    else:
        n_sites2 = n_sites1
        cart_f2 = cart_f1.copy()
        reduced = True

    # Initialize distance matrix
    distances = np.zeros((n_sites1, n_sites2))

    cart_im = np.dot(IMAGES, lll_matrix)
    # Calculate distances
    if reduced:
        for i in range(n_sites1 - 1):
            for j in range(i + 1, n_sites2):
                pre_im = cart_f2[j] - cart_f1[i]
                best = 1e100

                # Check all periodic images
                for k in range(27):
                    da = pre_im[0] + cart_im[k, 0]
                    db = pre_im[1] + cart_im[k, 1]
                    dc = pre_im[2] + cart_im[k, 2]
                    d = da * da + db * db + dc * dc
                    if d < best:
                        best = d

                distances[i, j] = np.sqrt(best)
    else:
        for i in range(n_sites1):
            for j in range(n_sites2):
                pre_im = cart_f2[j] - cart_f1[i]
                best = 1e100

                # Check all periodic images
                for k in range(27):
                    da = pre_im[0] + cart_im[k, 0]
                    db = pre_im[1] + cart_im[k, 1]
                    dc = pre_im[2] + cart_im[k, 2]
                    d = da * da + db * db + dc * dc
                    if d < best:
                        best = d

                distances[i, j] = np.sqrt(best)

    return distances
