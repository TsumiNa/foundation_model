# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

from functools import cached_property

import numba as nb
import numpy as np
from beartype.typing import Tuple
from numba import njit, prange

from shotgun_csp.core import GeneratorArgs

from .pbc import pbc_all_distances


@njit(nogil=True, fastmath=True)
def create_lattice(abc: np.ndarray, angles: np.ndarray, volume=None, decimals=7) -> np.ndarray:
    """Create a lattice matrix from lattice parameters.

    Args:
        abc: Array of lattice constants [a, b, c]
        angles: Array of angles [alpha, beta, gamma] in degrees

    Returns:
        3x3 lattice matrix as numpy array
    """

    a, b, c = abc  # Unpack lattice parameters

    # Convert angles to radians
    alpha, beta, gamma = angles * np.pi / 180

    cos_a, cos_b, cos_g = np.cos(alpha), np.cos(beta), np.cos(gamma)
    sin_a, sin_b = np.sin(alpha), np.sin(beta)

    # Calculate gamma_star
    gamma_star = (cos_a * cos_b - cos_g) / (sin_a * sin_b)
    # Correct for potential rounding errors
    gamma_star = np.arccos(max(-1.0, min(1.0, gamma_star)))

    # Create lattice vectors
    lattice = np.zeros((3, 3))

    # Vector a
    lattice[0, 0] = a * sin_b
    lattice[0, 2] = a * cos_b

    # Vector b
    lattice[1, 0] = -b * sin_a * np.cos(gamma_star)
    lattice[1, 1] = b * sin_a * np.sin(gamma_star)
    lattice[1, 2] = b * cos_a

    # Vector c
    lattice[2, 2] = c

    if volume is not None:
        # Calculate volume from lattice matrix
        current_volume = np.abs(np.linalg.det(lattice))
        # Adjust lattice matrix to match target volume
        s = (volume / current_volume) ** (1 / 3)
        return s * lattice

    return np.round(lattice, decimals)


@njit(nogil=True, fastmath=True)
def calculate_volume(abc: np.ndarray, angles: np.ndarray) -> float:
    """Calculate unit cell volume from lattice parameters.

    Args:
        abc: Array of lattice constants [a, b, c]
        angles: Array of angles [alpha, beta, gamma] in degrees

    Returns:
        Unit cell volume
    """
    a, b, c = abc
    # Convert angles to radians
    angles_rad = angles * np.pi / 180.0
    cos_alpha, cos_beta, cos_gamma = np.cos(angles_rad)

    term = 1.0 + 2.0 * cos_alpha * cos_beta * cos_gamma - cos_alpha**2 - cos_beta**2 - cos_gamma**2
    return a * b * c * np.sqrt(term)


@njit("f8(f8[:,:])", nogil=True, fastmath=True)
def calculate_volume_from_lattice(lattice: np.ndarray) -> float:
    """Calculate unit cell volume from lattice matrix.

    Args:
        lattice: 3x3 lattice matrix as numpy array

    Returns:
        Unit cell volume
    """
    # Calculate volume as the determinant of the lattice matrix
    return np.abs(np.linalg.det(lattice))


@njit("f8(f8, f8[:])", nogil=True, fastmath=True)
def get_multiplied_length(volume: float, angles: np.ndarray) -> float:
    """Calculate multiplied length from volume and angles.

    Args:
        volume: Unit cell volume
        angles: Array of angles [alpha, beta, gamma] in degrees

    Returns:
        Multiplied length (a*b*c)
    """
    # Convert angles to radians
    angles_rad = angles * np.pi / 180.0

    # Calculate cosines of angles
    cos_alpha, cos_beta, cos_gamma = np.cos(angles_rad)

    # Calculate the denominator term (same as in calculate_volume)
    term = 1.0 + 2.0 * cos_alpha * cos_beta * cos_gamma - cos_alpha**2 - cos_beta**2 - cos_gamma**2

    # Return a*b*c
    return volume / np.sqrt(term)


@njit("b1(f8[:,:],f8[:,:],f8)", nogil=True, fastmath=True)
def check_distance(
    lattice: np.ndarray,
    particles: np.ndarray,
    min_dist: float,
) -> bool:
    """Check if all particle pairs satisfy minimum distance criteria.

    This function validates if all pairs of particles in the system maintain a minimum
    required distance between them, considering periodic boundary conditions.

    Args:
        lattice (np.ndarray): 3x3 matrix defining the lattice vectors.
        particles (np.ndarray): Nx3 array of particle positions in fractional coordinates.
        min_dist (float): Minimum allowed distance between any pair of particles.

    Returns:
        bool: True if all particle pairs are separated by at least min_dist,
              False otherwise.

    Note:
        The function uses periodic boundary conditions when calculating distances
        between particles.
    """
    # Get distance matrix
    distance_matrix = pbc_all_distances(lattice, particles, None)

    # Calculate minimum allowed distances for all pairs
    n_particles = particles.shape[0]
    for i in prange(n_particles):
        for j in prange(i + 1, n_particles):
            # Check if actual distance is less than minimum allowed
            if distance_matrix[i, j] < min_dist:
                return False

    return True


@njit(nogil=True, fastmath=True)
def lattice_to(lattice: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Convert lattice matrix to lattice parameters.

    Args:
        lattice: 3x3 lattice matrix as numpy array

    Returns:
        Tuple of (abc, angles), where:
            abc: Array of lattice constants [a, b, c]
            angles: Array of angles [alpha, beta, gamma] in degrees
    """
    # Calculate lattice constants (a, b, c)
    # Manually compute the norms since np.linalg.norm with axis is not supported in Numba's nopython mode
    abc = np.zeros(3)
    for i in range(3):
        abc[i] = np.sqrt(np.sum(lattice[i] ** 2))

    angles = np.zeros(3)
    for i in prange(3):
        j = (i + 1) % 3
        k = (i + 2) % 3
        # Dot product of vectors j and k
        dot_product = np.sum(lattice[j] * lattice[k])
        # Cosine of the angle
        cos_angle = dot_product / (abc[j] * abc[k])
        # Clamp to valid range [-1, 1]
        cos_angle = max(-1.0, min(1.0, cos_angle))
        # Convert to degrees
        angles[i] = np.arccos(cos_angle) * 180.0 / np.pi

    return abc, angles


class Lattice:
    def __init__(self, args: GeneratorArgs):
        self.args = args

    @cached_property
    def generator(self):
        min_angle_degree = self.args.min_angle_degree
        max_angle_degree = self.args.max_angle_degree
        variance_of_volume = self.args.variance_of_volume
        space_group_num = self.args.space_group_num
        low_length = self.args.low_length
        high_length = self.args.high_length
        scale = self.args.scale
        decimals = self.args.decimals

        volume_of_cell = self.args.volume_of_cell * scale

        # ============ Lattice Generators ============
        # Select lattice generator based on spacegroup

        # ------------------- Triclinic -------------------
        # α≠β≠γ；a≠b≠c
        @njit(nogil=True, fastmath=True)
        def triclinic_lattice_gen():
            # Random volume
            vol = np.abs(np.random.normal(volume_of_cell, variance_of_volume))

            # Keep sampling until every criterion is satisfied
            while True:
                # ── Random angles ───────────────────────────────────────────────
                alpha, beta = np.random.uniform(min_angle_degree, max_angle_degree, 2)
                # γ ∈ [min_angle_degree, α + β − 10°]
                gamma = np.random.uniform(min_angle_degree, alpha + beta - 10.0)

                # Quick filter: reject overly obtuse total angle
                if alpha + beta + gamma > 330.0:
                    continue

                # ── Volume test (term) ─────────────────────────────────────────
                cos_a = np.cos(alpha * np.pi / 180.0)
                cos_b = np.cos(beta * np.pi / 180.0)
                cos_g = np.cos(gamma * np.pi / 180.0)
                term = 1.0 + 2.0 * cos_a * cos_b * cos_g - cos_a * cos_a - cos_b * cos_b - cos_g * cos_g

                # term → 0 implies the three lattice vectors are nearly coplanar
                if term < 1.0e-3:
                    continue

                # ── All checks passed ─────────────────────────────────────────
                angles = np.array((alpha, beta, gamma))
                break

            # Random edge lengths, then build the lattice matrix
            abc = np.random.uniform(low_length, high_length, 3)
            lattice = create_lattice(abc, angles, vol, decimals)
            return lattice, abc, angles, vol

        # ------------------- Monoclinic -------------------
        # α=γ=90°，β≠90°；a≠b≠c
        @njit(nogil=True, fastmath=True)
        def monoclinic_lattice_gen():
            vol = np.abs(np.random.normal(volume_of_cell, variance_of_volume))
            # β should not be 90 degree, so we subtract 5 degree
            alpha, gamma = 90.0, 90.0
            while True:
                beta = np.random.uniform(min_angle_degree, max_angle_degree)

                # ── Volume test (term) ─────────────────────────────────────────
                cos_a = np.cos(alpha * np.pi / 180.0)
                cos_b = np.cos(beta * np.pi / 180.0)
                cos_g = np.cos(gamma * np.pi / 180.0)
                term = 1.0 + 2.0 * cos_a * cos_b * cos_g - cos_a * cos_a - cos_b * cos_b - cos_g * cos_g
                if term < 1.0e-3:
                    continue

                if beta < 85.0 or beta > 95.0:
                    break
            angles = np.array([alpha, beta, gamma])
            abc = np.random.uniform(low_length, high_length, 3)
            lattice = create_lattice(abc, angles, vol, decimals)
            return lattice, abc, angles, vol

        # ------------------- Orthorhombic -------------------
        # α=β=γ=90°；a≠b≠c
        @njit(nogil=True, fastmath=True)
        def orthorhombic_lattice_gen():
            vol = np.abs(np.random.normal(volume_of_cell, variance_of_volume))
            angles = np.array([90.0, 90.0, 90.0])
            abc = np.random.uniform(low_length, high_length, 3)
            return create_lattice(abc, angles, vol, decimals), abc, angles, vol

        # ------------------- Tetragonal -------------------
        # α=β=γ=90°；a=b≠c
        @njit(nogil=True, fastmath=True)
        def tetragonal_lattice_gen():
            vol = np.abs(np.random.normal(volume_of_cell, variance_of_volume))
            angles = np.array([90.0, 90.0, 90.0])
            a, c = np.random.uniform(low_length, high_length, 2)
            abc = np.array([a, a, c])

            return create_lattice(abc, angles, vol, decimals), abc, angles, vol

        # ------------------- Trigonal -------------------
        # α=β=90°，γ=120°；a=b≠c
        @njit(nogil=True, fastmath=True)
        def trigonal_lattice_gen():
            vol = np.abs(np.random.normal(volume_of_cell, variance_of_volume))
            if space_group_num not in [146, 148, 155, 160, 161, 166, 167]:
                angles = np.array([90.0, 90.0, 120.0])
                a, c = np.random.uniform(low_length, high_length, 2)
                abc = np.array([a, a, c])
            else:  # α=β=γ<90°；a=b=c
                beta = np.random.uniform(min_angle_degree, min(max_angle_degree, 85.0))
                angles = np.array([beta, beta, beta])
                a = np.random.uniform(low_length, high_length)
                abc = np.array([a, a, a])
            return create_lattice(abc, angles, vol, decimals), abc, angles, vol

        # ------------------- Hexagonal -------------------
        # α=β=90°，γ=120°；a=b≠c
        @njit(nogil=True, fastmath=True)
        def hexagonal_lattice_gen():
            vol = np.abs(np.random.normal(volume_of_cell, variance_of_volume))
            angles = np.array([90.0, 90.0, 120.0])
            a, c = np.random.uniform(low_length, high_length, 2)
            abc = np.array([a, a, c])
            return create_lattice(abc, angles, vol, decimals), abc, angles, vol

        # ------------------- Cubic -------------------
        # α=β=γ=90°；a=b=c
        @njit(nogil=True, fastmath=True)
        def cubic_lattice_gen():
            vol = np.abs(np.random.normal(volume_of_cell, variance_of_volume))
            angles = np.array([90.0, 90.0, 90.0])
            a = np.random.uniform(low_length, high_length)
            abc = np.array([a, a, a])
            return create_lattice(abc, angles, vol, decimals), abc, angles, vol

        # Select lattice generator based on spacegroup
        if 1 <= space_group_num <= 2:  # Triclinic
            return triclinic_lattice_gen
        elif 3 <= space_group_num <= 15:  # Monoclinic
            return monoclinic_lattice_gen
        elif 16 <= space_group_num <= 74:  # Orthorhombic
            return orthorhombic_lattice_gen
        elif 75 <= space_group_num <= 142:  # Tetragonal
            return tetragonal_lattice_gen
        elif 143 <= space_group_num <= 167:  # Trigonal
            return trigonal_lattice_gen
        elif 168 <= space_group_num <= 194:  # Hexagonal
            return hexagonal_lattice_gen
        else:  # Cubic
            return cubic_lattice_gen

    @property
    def parallel_generator(self):
        lattice_gen = self.generator

        @njit(parallel=True, fastmath=True)
        def parallel_gen(n):
            place_holder = np.empty((3, 3))
            lattices = nb.typed.List(
                [(place_holder, np.empty(3, dtype=np.float64), np.empty(3, dtype=np.float64), 0.0) for _ in range(n)]
            )
            for i in prange(n):
                lattices[i] = lattice_gen()
            return lattices

        return parallel_gen

    @property
    def serial_generator(self):
        lattice_gen = self.generator

        @njit(parallel=False, fastmath=True)
        def serial_gen(n):
            return [lattice_gen() for _ in range(n)]

        return serial_gen
