# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import numpy as np
from numpy.testing import assert_allclose

from shotgun_csp.core import GeneratorArgs
from shotgun_csp.core.wyckoff.lattice import (
    Lattice,
    calculate_volume,
    calculate_volume_from_lattice,
    check_distance,
    create_lattice,
    get_multiplied_length,
    lattice_to,
)


def test_create_lattice():
    """Test lattice matrix creation."""
    abc = np.array([14.019043922424316, 6.381750106811523, 9.891742706298828])
    angles = np.array([90.0, 90.0, 90.0])

    lattice = create_lattice(abc, angles)

    expected = np.array([[14.019043922424316, 0.0, 0.0], [0.0, 6.381750106811523, 0.0], [0.0, 0.0, 9.891742706298828]])

    assert_allclose(lattice, expected, atol=1e-7)


def test_calculate_volume():
    """Test volume calculation."""
    abc = np.array([14.019043922424316, 6.381750106811523, 9.891742706298828])
    angles = np.array([90.0, 90.0, 90.0])

    volume = calculate_volume(abc, angles)
    expected = 14.019043922424316 * 6.381750106811523 * 9.891742706298828

    assert_allclose(volume, expected, atol=1e-7)


def test_get_multiplied_length():
    """Test multiplied length calculation."""
    volume = 100.0
    angles = np.array([90.0, 90.0, 90.0])

    length = get_multiplied_length(volume, angles)
    expected = 100.0

    assert_allclose(length, expected, atol=1e-7)


def test_check_distance():
    """Test interatomic distance checking."""
    lattice = np.array([[5.0, 0.0, 0.0], [0.0, 5.0, 0.0], [0.0, 0.0, 5.0]])

    # Two particles far apart
    particles = np.array([[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])

    scale_factor = 0.1

    # Should pass distance check
    assert check_distance(lattice, particles * (1 - scale_factor), 1.0)

    # Two particles too close
    particles_close = np.array([[0.0, 0.0, 0.0], [0.1, 0.1, 0.1]])

    # Should fail distance check
    assert not check_distance(lattice, particles_close, 1.0)


def test_lattice_to():
    """Test conversion from lattice matrix to parameters."""
    lattice = np.array([[5.0, 0.0, 0.0], [0.0, 5.0, 0.0], [0.0, 0.0, 5.0]])

    abc, angles = lattice_to(lattice)

    assert_allclose(abc, [5.0, 5.0, 5.0], atol=1e-7)
    assert_allclose(angles, [90.0, 90.0, 90.0], atol=1e-7)


def test_lattice_to_non_orthogonal():
    """Test conversion for non-orthogonal lattice."""
    # Hexagonal lattice
    a = 5.0
    c = 8.0
    lattice = np.array([[a, 0.0, 0.0], [-a / 2, a * np.sqrt(3) / 2, 0.0], [0.0, 0.0, c]])

    abc, angles = lattice_to(lattice)

    assert_allclose(abc, [5.0, 5.0, 8.0], rtol=1e-7)
    assert_allclose(angles, [90.0, 90.0, 120.0], rtol=1e-7)


def test_calculate_volume_from_lattice():
    """Test volume calculation from lattice matrix."""
    # Create a simple cubic lattice
    lattice = np.array([[5.0, 0.0, 0.0], [0.0, 5.0, 0.0], [0.0, 0.0, 5.0]])
    volume = calculate_volume_from_lattice(lattice)
    expected = 125.0  # 5^3
    assert_allclose(volume, expected, atol=1e-7)

    # Test with non-orthogonal lattice
    # Hexagonal lattice
    a = 5.0
    c = 8.0
    lattice = np.array([[a, 0.0, 0.0], [-a / 2, a * np.sqrt(3) / 2, 0.0], [0.0, 0.0, c]])
    volume = calculate_volume_from_lattice(lattice)
    # Volume of hexagonal unit cell = a^2 * c * sin(120°) * 3/2
    expected = a**2 * c * np.sqrt(3) / 2
    assert_allclose(volume, expected, atol=1e-7)


def test_create_lattice_non_orthogonal():
    """Test lattice matrix creation for non-orthogonal cases."""
    # Test a monoclinic cell (α = γ = 90°, β ≠ 90°)
    abc = np.array([5.0, 6.0, 7.0])
    angles = np.array([90.0, 110.0, 90.0])

    lattice = create_lattice(abc, angles)

    # Check that the lattice parameters and angles are recovered
    abc_recovered, angles_recovered = lattice_to(lattice)

    assert_allclose(abc_recovered, abc, atol=1e-7)
    assert_allclose(angles_recovered, angles, atol=1e-7)

    # Test a triclinic cell (α ≠ β ≠ γ ≠ 90°)
    abc = np.array([4.0, 5.0, 6.0])
    angles = np.array([70.0, 80.0, 100.0])

    lattice = create_lattice(abc, angles)

    # Check that the lattice parameters and angles are recovered
    abc_recovered, angles_recovered = lattice_to(lattice)

    assert_allclose(abc_recovered, abc, atol=1e-7)
    assert_allclose(angles_recovered, angles, atol=1e-7)


def test_check_distance_edge_cases():
    """Test interatomic distance checking for edge cases."""
    lattice = np.array([[5.0, 0.0, 0.0], [0.0, 5.0, 0.0], [0.0, 0.0, 5.0]])

    # Test with particles exactly at allowed distance
    radii = np.array([1.0, 1.0])
    scale_factor = 0.1
    min_dist = (radii[0] + radii[1]) * (1.0 - scale_factor)  # 1.8

    # Place particles exactly at the minimum distance
    particles = np.array([[0.0, 0.0, 0.0], [0.5, 0.0, 0.0]])

    # Should pass distance check (equal to min distance)
    assert check_distance(lattice, particles, 0.9)

    # Test with slightly less than minimum distance
    particles_too_close = np.array([[0.0, 0.0, 0.0], [min_dist / 5 - 0.01, 0.0, 0.0]])
    assert not check_distance(
        lattice,
        particles_too_close,
        min_dist,
    )

    # Test with multiple particles
    particles_multi = np.array([[0.0, 0.0, 0.0], [0.4, 0.4, 0.4], [0.6, 0.0, 0.0]])

    # Should pass distance check
    assert check_distance(
        lattice,
        particles_multi,
        1.8,
    )


def test_random_lattice_gen_triclinic():
    """Test random lattice generation for triclinic spacegroup."""

    options = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=2,  # Triclinic
        variance_of_volume=5.0,
        max_angle_degree=30.0,
        min_angle_degree=20.0,
    )

    # Test single lattice generation
    generator = Lattice(options).generator
    lattice, abc, angles, volume = generator()

    # Check lattice shape
    assert lattice.shape == (3, 3)

    # Check volume is close to target
    assert 80.0 <= volume <= 120.0

    # Check actual volume from lattice matches returned volume
    calc_vol = calculate_volume_from_lattice(lattice)
    assert_allclose(calc_vol, volume, rtol=1e-5)

    # Check that we get angles in the expected range
    assert np.all((angles >= options.min_angle_degree) | (angles >= 80.0))  # Either it's min_angle or it's orthogonal


def test_random_lattice_gen_cubic():
    """Test random lattice generation for cubic spacegroup."""

    options = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=200,  # Cubic
        variance_of_volume=5.0,
    )

    # Test serial generation
    serial_generator = Lattice(options).serial_generator
    lattices = serial_generator(5)

    assert len(lattices) == 5

    # Check all lattices are valid cubic lattices
    for lattice, abc, angles, volume in lattices:
        # Check lattice shape
        assert lattice.shape == (3, 3)

        # For cubic, a=b=c
        assert_allclose(abc[0], abc[1], rtol=1e-5)
        assert_allclose(abc[0], abc[2], rtol=1e-5)

        # Angles should be 90 degrees
        assert_allclose(angles, [90.0, 90.0, 90.0], rtol=1e-5)

        # Volume should be close to target
        assert 80.0 <= volume <= 120.0


def test_random_lattice_gen_parallel():
    """Test parallel random lattice generation."""

    options = GeneratorArgs(
        volume_of_cell=100.0,
        space_group_num=75,  # Tetragonal
        variance_of_volume=5.0,
    )

    # Test parallel generation
    parallel_generator = Lattice(options).parallel_generator
    lattices = parallel_generator(10)

    assert len(lattices) == 10

    # Check all lattices are valid tetragonal lattices
    for lattice, abc, angles, vol in lattices:
        # Check lattice shape
        assert lattice.shape == (3, 3)

        # For tetragonal, a=b≠c
        assert_allclose(abc[0], abc[1], rtol=1e-5)
        assert abs(abc[0] - abc[2]) > 1e-5  # a != c

        # Angles should be 90 degrees
        assert_allclose(angles, [90.0, 90.0, 90.0], rtol=1e-5)


def test_random_lattice_gen_special_spacegroups():
    """Test random lattice generation for special spacegroups with multiples."""

    # Test Body-centered ("I") spacegroup which has multiple=2
    i_options = GeneratorArgs(
        volume_of_cell=50.0,  # Will be multiplied by 2
        space_group_num=217,  # I-43m, body-centered cubic
    )

    generator = Lattice(i_options).generator
    _, _, _, volume = generator()

    # Volume should be ~100 (50*2)
    assert 70.0 <= volume <= 130.0

    # Test Face-centered ("F") spacegroup which has multiple=4
    f_options = GeneratorArgs(
        volume_of_cell=25.0,  # Will be multiplied by 4
        space_group_num=225,  # Fm-3m, face-centered cubic
    )

    generator = Lattice(f_options).generator
    _, _, _, volume = generator()

    # Volume should be ~100 (25*4)
    assert 70.0 <= volume <= 130.0


def test_random_lattice_gen_all_crystal_systems():
    """Test random lattice generation for each crystal system."""

    # Test representative spacegroups from each crystal system
    test_cases = [
        (1, "Triclinic", 1),  # P1 - primitive
        (3, "Monoclinic", 1),  # P2 - primitive
        (21, "Orthorhombic", 2),  # C222 - C-centered (multiple=2)
        (82, "Tetragonal", 2),  # I4 - body-centered (multiple=2)
        (149, "Trigonal", 1),  # P312 - primitive
        (178, "Hexagonal", 1),  # P6122 - primitive
        (200, "Cubic", 1),  # Pm-3 - primitive
    ]

    for spg_num, _, _ in test_cases:
        print(f"Testing crystal system: {spg_num}")
        options = GeneratorArgs(volume_of_cell=100.0, space_group_num=spg_num)

        generator = Lattice(options).generator
        lattice, _, _, volume = generator()

        # Basic checks for all crystal systems
        assert lattice.shape == (3, 3)

        # Calculate volume from lattice and verify it matches
        calc_vol = calculate_volume_from_lattice(lattice)
        assert_allclose(calc_vol, volume, rtol=1e-5)
