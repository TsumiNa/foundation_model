# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0


# Import core functionality
import warnings

from numba.core.errors import NumbaExperimentalFeatureWarning

from .generator import CrystalGenerator
from .lattice import (
    calculate_volume,
    check_distance,
    create_lattice,
    get_multiplied_length,
    lattice_to,
)
from .position import WyckoffPosition
from .structure import CrystalStructure
from .wyckoff_cfg import WyckoffCfgGenerator

__all__ = [
    # Core classes
    "CrystalGenerator",
    "WyckoffCfgGenerator",
    "CrystalStructure",
    "WyckoffPosition",
    "get_wyckoff_cfg_generator",
    # Lattice utilities
    "calculate_volume",
    "check_distance",
    "create_lattice",
    "get_multiplied_length",
    "lattice_to",
]

__version__ = "0.4.0"

warnings.filterwarnings("ignore", category=NumbaExperimentalFeatureWarning)
