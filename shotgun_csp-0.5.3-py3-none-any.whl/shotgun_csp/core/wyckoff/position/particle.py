# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import re
from functools import cached_property

import numpy as np
from numba import njit

from shotgun_csp.core.exception import GenerationError

from .coordinate import Coordinate


class Particle:
    """Class representing a particle defined by three coordinates."""

    def __init__(self, s: str) -> None:
        """Parse a particle from a string representation."""

        parts = re.split(r",\s*", s)
        if len(parts) != 3:
            raise GenerationError(self, f"particle coordinate must be 3-dim, but got {len(parts)}")

        self._coords = [Coordinate(part) for part in parts]

    @cached_property
    def generator(self) -> np.ndarray:
        x_gen, y_gen, z_gen = [c.generator for c in self._coords]

        @njit("float64[:](float64, float64, float64)", nogil=True, fastmath=True)
        def f_(x: float, y: float, z: float) -> np.ndarray:
            return np.array([x_gen(x, y, z), y_gen(x, y, z), z_gen(x, y, z)])

        return f_

    @property
    def coord_x(self) -> Coordinate:
        """Get the x-coordinate."""
        return self._coords[0]

    @property
    def coord_y(self) -> Coordinate:
        """Get the y-coordinate."""
        return self._coords[1]

    @property
    def coord_z(self) -> Coordinate:
        """Get the z-coordinate."""
        return self._coords[2]

    def gen(self, x: float, y: float, z: float) -> np.ndarray:
        """Generate a tuple of values based on the input x, y, z values."""
        return self.generator(x, y, z)
