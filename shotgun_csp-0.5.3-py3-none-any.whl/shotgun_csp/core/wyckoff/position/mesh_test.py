# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import numpy as np

from shotgun_csp.core.wyckoff.position.mesh import (
    _check_upper_triangle,
    _generate_coords,
    _generate_mesh,
    _process_with_history,
    select_rows2,
    select_rows3,
)


def test_generate_coords_basic():
    # Test basic functionality
    coords = _generate_coords(10)
    assert isinstance(coords, np.ndarray)
    assert coords.dtype == np.float64
    assert all(0 < x < 1 for x in coords)


def test_generate_coords_increasing():
    # Test coordinates are strictly increasing
    coords = _generate_coords(8)
    diffs = np.diff(coords)
    assert all(diff > 0 for diff in diffs)


def test_generate_coords_avoids_special_points():
    # Test avoids special points (0, 0.25, 1/3, 0.5, 2/3, 0.75, 1.0)
    special_pts = np.array([0, 0.25, 1 / 3, 0.5, 2 / 3, 0.75, 1.0])
    coords = _generate_coords(20)
    for pt in special_pts:
        assert not np.isclose(pt, coords).any()


def test_generate_coords_spacing():
    # Test minimum spacing between points
    coords = _generate_coords(50)
    min_spacing = np.min(np.diff(coords))
    assert min_spacing > 0


def test_generate_coords_bounds():
    # Test generated coordinates are within [0,1] bounds
    coords = _generate_coords(15)
    assert np.all(coords >= 0)
    assert np.all(coords <= 1)


def test_generate_coords_different_sizes():
    # Test with different input sizes
    sizes = [5, 10, 20]
    for size in sizes:
        coords = _generate_coords(size)
        assert len(coords) > 0


def test_generate_mesh_basic():
    # Test basic functionality
    abc = np.array([3.0, 3.0, 3.0])
    coord_freedom = (True, True, True)
    min_dist = 1.0

    mesh = _generate_mesh(abc, coord_freedom, min_dist)
    assert isinstance(mesh, np.ndarray)
    assert mesh.shape[1] == 3
    assert np.all(mesh >= 0) and np.all(mesh < 1)


def test_generate_mesh_constrained():
    # Test with some directions constrained
    abc = np.array([3.0, 3.0, 3.0])
    coord_freedom = (True, False, True)
    min_dist = 1.0

    mesh = _generate_mesh(abc, coord_freedom, min_dist)
    assert np.all(mesh[:, 1] == 0.5)  # y coordinates should all be 0.5
    assert not np.all(mesh[:, 0] == 0.5)  # x coordinates should vary
    assert not np.all(mesh[:, 2] == 0.5)  # z coordinates should vary


def test_generate_mesh_perturbation():
    # Test perturbation effect
    abc = np.array([3.0, 3.0, 3.0])
    coord_freedom = (True, True, True)
    min_dist = 1.0
    perturbation = 0.1

    np.random.seed(42)  # For reproducibility
    mesh1 = _generate_mesh(abc, coord_freedom, min_dist)
    np.random.seed(42)  # Reset seed
    mesh2 = _generate_mesh(abc, coord_freedom, min_dist, perturbation)

    assert not np.allclose(mesh1, mesh2)
    assert np.all(mesh2 >= 0) and np.all(mesh2 <= 1)


def test_generate_mesh_different_cell_params():
    # Test with different cell parameters
    abc = np.array([2.0, 3.0, 4.0])
    coord_freedom = (True, True, True)
    min_dist = 1.0

    mesh = _generate_mesh(abc, coord_freedom, min_dist)
    assert len(mesh) == len(_generate_coords(2)) * len(_generate_coords(3)) * len(_generate_coords(4))


def test_generate_mesh_fully_constrained():
    # Test fully constrained case
    abc = np.array([3.0, 3.0, 3.0])
    coord_freedom = (False, False, False)
    min_dist = 1.0

    mesh = _generate_mesh(abc, coord_freedom, min_dist)
    assert mesh.shape == (1, 3)
    assert np.all(mesh == 0.5)


def test_check_upper_triangle_basic():
    # Test basic case with distances above threshold
    dist_matrix = np.array([[2.0, 3.0], [3.0, 2.0]])
    threshold = 1.0
    assert not _check_upper_triangle(dist_matrix, threshold)

    # Test basic case with distances below threshold
    dist_matrix = np.array([[0.5, 3.0], [3.0, 2.0]])
    assert _check_upper_triangle(dist_matrix, threshold)


def test_check_upper_triangle_3x3():
    # Test 3x3 matrix
    dist_matrix = np.array([[2.0, 3.0, 4.0], [3.0, 2.0, 0.5], [4.0, 0.5, 2.0]])
    threshold = 1.0
    assert _check_upper_triangle(dist_matrix, threshold)

    dist_matrix = np.array([[2.0, 3.0, 4.0], [3.0, 2.0, 3.0], [4.0, 3.0, 2.0]])
    assert not _check_upper_triangle(dist_matrix, threshold)


def test_check_upper_triangle_diagonal():
    # Test diagonal elements
    dist_matrix = np.array([[0.5, 2.0], [2.0, 2.0]])
    threshold = 1.0
    assert _check_upper_triangle(dist_matrix, threshold)


def test_check_upper_triangle_edge_cases():
    # Test 1x1 matrix
    dist_matrix = np.array([[2.0]])
    threshold = 1.0
    assert not _check_upper_triangle(dist_matrix, threshold)

    dist_matrix = np.array([[0.5]])
    assert _check_upper_triangle(dist_matrix, threshold)


def test_select_rows2_basic():
    # Test basic case with integers
    arr = np.array([[1, 2], [3, 4], [5, 6]])
    indices = np.array([0, 2])
    result = select_rows2(arr, indices)
    assert np.array_equal(result, np.array([[1, 2], [5, 6]]))


def test_select_rows2_float():
    # Test with floating point numbers
    arr = np.array([[1.5, 2.5], [3.5, 4.5], [5.5, 6.5]], dtype=np.float64)
    indices = np.array([1])
    result = select_rows2(arr, indices)
    assert np.array_equal(result, np.array([[3.5, 4.5]]))


def test_select_rows2_single_column():
    # Test with single column array
    arr = np.array([[1], [2], [3]])
    indices = np.array([0, 2])
    result = select_rows2(arr, indices)
    assert np.array_equal(result, np.array([[1], [3]]))


def test_select_rows2_all_rows():
    # Test selecting all rows
    arr = np.array([[1, 2], [3, 4]])
    indices = np.array([0, 1])
    result = select_rows2(arr, indices)
    assert np.array_equal(result, arr)


def test_select_rows2_dtype_preservation():
    # Test that dtype is preserved
    arr = np.array([[1, 2], [3, 4]], dtype=np.int64)
    indices = np.array([0])
    result = select_rows2(arr, indices)
    assert result.dtype == arr.dtype


def test_select_rows3_basic():
    # Test basic case with integers
    arr = np.array([[[1, 2], [3, 4]], [[5, 6], [7, 8]], [[9, 10], [11, 12]]])
    indices = np.array([0, 2])
    result = select_rows3(arr, indices)
    assert np.array_equal(result, np.array([[[1, 2], [3, 4]], [[9, 10], [11, 12]]]))


def test_select_rows3_float():
    # Test with floating point numbers
    arr = np.array([[[1.5, 2.5], [3.5, 4.5]], [[5.5, 6.5], [7.5, 8.5]]], dtype=np.float64)
    indices = np.array([1])
    result = select_rows3(arr, indices)
    assert np.array_equal(result, np.array([[[5.5, 6.5], [7.5, 8.5]]], dtype=np.float64))


def test_select_rows3_single_row():
    # Test with single row array
    arr = np.array([[[1, 2, 3]], [[4, 5, 6]]])
    indices = np.array([0])
    result = select_rows3(arr, indices)
    assert np.array_equal(result, np.array([[[1, 2, 3]]]))


def test_select_rows3_all_rows():
    # Test selecting all rows
    arr = np.array([[[1, 2], [3, 4]], [[5, 6], [7, 8]]])
    indices = np.array([0, 1])
    result = select_rows3(arr, indices)
    assert np.array_equal(result, arr)


def test_select_rows3_dtype_preservation():
    # Test that dtype is preserved
    arr = np.array([[[1, 2]], [[3, 4]]], dtype=np.int64)
    indices = np.array([0])
    result = select_rows3(arr, indices)
    assert result.dtype == arr.dtype


def test_process_with_history_basic():
    # Test basic functionality with no previous coords
    lattice = np.eye(3)
    current_coords = np.array([[[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]], [[0.2, 0.2, 0.2], [0.7, 0.7, 0.7]]])
    min_dist = 0.3

    result = _process_with_history(lattice, current_coords, None, min_dist)
    assert len(result) > 0
    assert isinstance(result, np.ndarray)


def test_process_with_history_previous_coords():
    # Test with previous coordinates
    lattice = np.eye(3)
    current_coords = np.array([[[0.2, 0.2, 0.2], [0.7, 0.7, 0.7]], [[0.4, 0.4, 0.4], [0.9, 0.9, 0.9]]])
    previous_coords = np.array([[0.1, 0.1, 0.1]])
    min_dist = 0.2

    result = _process_with_history(lattice, current_coords, previous_coords, min_dist)
    assert len(result) == 1
    assert result[0] == 1  # Only second group should be valid


def test_process_with_history_all_invalid():
    # Test when all positions are invalid
    lattice = np.eye(3)
    current_coords = np.array([[[0.1, 0.1, 0.1], [0.2, 0.2, 0.2]], [[0.15, 0.15, 0.15], [0.25, 0.25, 0.25]]])
    min_dist = 0.3

    result = _process_with_history(lattice, current_coords, None, min_dist)
    assert len(result) == 0


def test_process_with_history_pbc():
    # Test with periodic boundary conditions
    lattice = 2.0 * np.eye(3)  # Larger lattice
    current_coords = np.array(
        [
            [[0.1, 0.1, 0.1], [0.9, 0.9, 0.9]],  # These are close due to PBC
            [[0.4, 0.4, 0.4], [0.7, 0.7, 0.7]],
        ]
    )
    min_dist = 0.8

    result = _process_with_history(lattice, current_coords, None, min_dist)
    assert len(result) == 1  # Only one group should be valid


def test_process_with_history_different_shapes():
    # Test with coordinate groups of different shapes
    lattice = np.eye(3)
    current_coords = np.array(
        [[[0.1, 0.1, 0.1], [0.6, 0.6, 0.6]], [[0.3, 0.3, 0.3], [0.8, 0.8, 0.8]], [[0.5, 0.5, 0.5], [0.9, 0.9, 0.9]]]
    )
    previous_coords = np.array([[0.0, 0.0, 0.0], [1.0, 1.0, 1.0]])
    min_dist = 0.2

    result = _process_with_history(lattice, current_coords, previous_coords, min_dist)
    assert isinstance(result, np.ndarray)
    assert result.ndim == 1
