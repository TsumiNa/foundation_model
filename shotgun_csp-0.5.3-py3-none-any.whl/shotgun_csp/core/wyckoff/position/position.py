# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import re
import warnings
from functools import cached_property

import numpy as np
from beartype.typing import Optional, Tuple
from numba import njit, prange
from numba.core.errors import NumbaExperimentalFeatureWarning

from shotgun_csp.core.exception import GenerationError

from .particle import Particle

# Ignore NumbaExperimentalFeatureWarning
# "First-class function type feature is experimental"
warnings.resetwarnings()
warnings.simplefilter("ignore", NumbaExperimentalFeatureWarning)


@njit(["float64[:,:](float64[:,:])"], fastmath=True, nogil=True)
def _process_array(arr: np.ndarray) -> np.ndarray:
    # Use numpy.where for vectorized operations
    arr = np.where(arr > 1, arr - 1, arr)  # For values > 1, subtract 1
    arr = np.where(arr < 0, arr + 1, arr)  # For values < 0, add 1
    return arr


class WyckoffPosition:
    """Class representing a Wyckoff position consisting of multiple particles."""

    # FULL_PATTERN:
    # The entire string must consist solely of one or more complete blocks.
    # A block is defined as:
    #   - A left parenthesis "(",
    #   - Followed by optional whitespace,
    #   - Followed by one or more allowed characters (digits, '+', '-', 'x', 'y', 'z', '/', ',', or whitespace),
    #   - Followed by optional whitespace,
    #   - Followed by a right parenthesis ")".
    FULL_PATTERN = re.compile(
        r"^"  # Start of string
        r"(?:\(\s*[+\-0-9xyz/,\s]+\s*\))"  # First complete block
        r"(?:\s*(?:,\s*)?\(\s*[+\-0-9xyz/,\s]+\s*\))*"  # Subsequent blocks (optional comma separator allowed)
        r"$"  # End of string
    )

    # EXTRACT_PATTERN: Uses the same BLOCK_PATTERN to extract tokens from each block.
    EXTRACT_PATTERN = re.compile(r"\(\s*([+\-0-9xyz/,\s]+?)\s*\)")

    def __init__(self, s: str, *, shifts: Optional[np.ndarray] = None, decimals: int = 7):
        if self.FULL_PATTERN.fullmatch(s) is None:
            raise GenerationError(self, "the string must be something like `(x,y,1/2)(-y,x-y,1/2)`")

        self._particles = [Particle(p) for p in self.EXTRACT_PATTERN.findall(s)]
        self._decimals = decimals
        self._coord_freedom = self._check_xyz(s)
        self._shifts = shifts
        self._cached = None

        if not any(self._coord_freedom):
            positions = np.empty((len(self._particles), 3), dtype=np.float64)
            for i, particle in enumerate(self._particles):
                positions[i] = particle.gen(0.0, 0.0, 0.0)

            if self._shifts is not None:
                all_positions = [positions]
                for shift in self._shifts:
                    all_positions.append(positions + shift)
                all_positions = np.vstack(all_positions)
                self._cached = np.round(_process_array(all_positions), decimals=self._decimals)
            else:
                self._cached = np.round(_process_array(positions), decimals=self._decimals)

    @cached_property
    def generator(self):
        _cached = self._cached
        _particles_gen = tuple([p.generator for p in self._particles])
        _decimals = self._decimals
        _shifts = self._shifts

        @njit(["float64[:,:](float64, float64, float64)"], fastmath=True, nogil=True)
        def gen(x: float, y: float, z: float) -> np.ndarray:
            """Generate positions based on input x, y, z values."""

            if _cached is not None:
                return _cached.copy()

            positions = np.empty((len(_particles_gen), 3), dtype=np.float64)
            for i, gen in enumerate(_particles_gen):
                positions[i] = gen(x, y, z)

            if _shifts is not None:
                m = _shifts.shape[0] + 1
                n = positions.shape[0]
                all_positions = np.empty((n * m, 3), dtype=np.float64)
                all_positions[:n, :] = positions
                for i in prange(_shifts.shape[0]):
                    all_positions[n * (i + 1) : n * (i + 2), :] = positions + _shifts[i]

                return np.round(_process_array(all_positions), decimals=_decimals)
            else:
                return np.round(_process_array(positions), decimals=_decimals)

        return gen

    @cached_property
    def serial_generator(self):
        _gen = self.generator
        _n_particles = len(self._particles)
        _n_shifts = self._shifts.shape[0] if self._shifts is not None else 0
        _size = _n_particles * (_n_shifts + 1)

        @njit(["float64[:,:,:](int64)"], fastmath=True, nogil=True)
        def gen(num: int) -> np.ndarray:
            """Generate positions based on input x, y, z values."""

            tmp = np.empty((num, _size, 3), dtype=np.float64)
            for i in prange(num):
                x, y, z = np.random.uniform(0.0, 1.0, 3)
                tmp[i] = _gen(x, y, z)

            return tmp

        return gen

    @cached_property
    def parallel_generator(self):
        _gen = self.generator
        _n_particles = len(self._particles)
        _n_shifts = self._shifts.shape[0] if self._shifts is not None else 0
        _size = _n_particles * (_n_shifts + 1)

        @njit(["float64[:,:,:](int64)"], parallel=True, fastmath=True, nogil=True)
        def gen(num: int) -> np.ndarray:
            """Generate positions based on input x, y, z values."""

            tmp = np.empty((num, _size, 3), dtype=np.float64)
            for i in prange(num):
                x, y, z = np.random.uniform(0.0, 1.0, 3)
                tmp[i] = _gen(x, y, z)

            return tmp

        return gen

    @staticmethod
    def _check_xyz(input_string: str) -> Tuple[bool, bool, bool]:
        # Create a tuple to store boolean values for x,y,z existence
        has_x = "x" in input_string
        has_y = "y" in input_string
        has_z = "z" in input_string

        return (has_x, has_y, has_z)

    @property
    def is_cached(self) -> bool:
        """Check if the position has been cached."""
        return False if self._cached is None else True

    @cached_property
    def coord_freedom(self) -> Tuple[bool, bool, bool]:
        """Get the coordinate freedom tuple."""
        return {"x": self._coord_freedom[0], "y": self._coord_freedom[1], "z": self._coord_freedom[2]}

    @cached_property
    def n_particles(self) -> int:
        """Get the particles."""
        return self.generator(0.0, 0.0, 0.0).shape[0]

    def gen(self, x: float, y: float, z: float) -> np.ndarray:
        """Generate positions based on input x, y, z values."""

        return self.generator(x, y, z)

    def random_gen(self) -> np.ndarray:
        """Generate positions based on input x, y, z values."""
        x, y, z = np.random.uniform(0.0, 1.0, 3)
        return self.generator(x, y, z)

    def __len__(self) -> int:
        return len(self._particles)
