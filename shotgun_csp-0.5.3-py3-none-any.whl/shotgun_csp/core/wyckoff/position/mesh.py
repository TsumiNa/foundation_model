# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0


import numpy as np
from beartype.typing import List
from numba import njit

from shotgun_csp.core.wyckoff.lattice.pbc import pbc_all_distances


@njit("f8[:](i8)", fastmath=True, nogil=True)
def _generate_coords(num_points: int) -> np.ndarray:
    """Generate coordinates with specified number of points.

    Args:
        num_points (int): Number of points to generate

    Returns:
        np.ndarray: Generated coordinates
    """
    # Special points to avoid
    special_pts = np.array([0, 0.25, 1 / 3, 0.5, 2 / 3, 0.75, 1.0], dtype=np.float64)
    spacing = 1.0 / num_points
    dist = np.diff(special_pts)
    nums = np.ceil(dist / spacing)
    # Calculate total points needed per segment (including endpoints)
    n_points = nums.astype(np.int64) + 2

    # Create list storing insertion points (excluding endpoints)
    segments = [np.linspace(special_pts[i], special_pts[i + 1], n)[1:-1] for i, n in enumerate(n_points)]
    n = sum([len(seg) for seg in segments])
    ret = np.zeros(n, dtype=np.float64)
    n_ = 0
    for seg in segments:
        for i in seg:
            ret[n_] = i
            n_ += 1
    return ret


@njit("b1(f8[:,:],f8)", fastmath=True, nogil=True)
def _check_upper_triangle(dist_matrix, threshold):
    """
    Check if there exists any pair of points in the upper triangular part of a distance matrix
    that are closer than a given threshold.

    Args:
        dist_matrix (numpy.ndarray): Square distance matrix between points
        threshold (float): Distance threshold value

    Returns:
        bool: True if any pair of points has distance <= threshold, False otherwise

    Notes:
        Only checks upper triangular part of matrix including diagonal.
    """

    n = dist_matrix.shape[0]
    for i in range(n):
        for j in range(i, n):
            if dist_matrix[i, j] <= threshold:
                return True
    return False


@njit(["f8[:,:](f8[:,:],i8[:])", "i8[:,:](i8[:,:],i8[:])"], fastmath=True, nogil=True)
def select_rows2(arr, indices):
    """Select rows from a 2D array based on given indices.
    Args:
        arr (ndarray): Input array
        indices (ndarray): Indices of rows to select
    Returns:
        ndarray: Array with selected rows
    """
    # if indices.size == 0:
    #     return np.empty((0, arr.shape[1]), dtype=arr.dtype)
    result = np.empty((len(indices), arr.shape[1]), dtype=arr.dtype)
    for i in range(len(indices)):
        result[i] = arr[indices[i]]
    return result


@njit(["f8[:,:,:](f8[:,:,:],i8[:])", "i8[:,:,:](i8[:,:,:],i8[:])"], fastmath=True, nogil=True)
def select_rows3(arr, indices):
    """Select rows from a 3D array based on given indices.
    Args:
        arr (ndarray): Input array
        indices (ndarray): Indices of rows to select
    Returns:
        ndarray: Array with selected rows
    """
    result = np.empty((len(indices), arr.shape[1], arr.shape[2]), dtype=arr.dtype)

    for i in range(len(indices)):
        result[i] = arr[indices[i]]
    return result


@njit("i8[:](f8[:,:], f8[:,:,:], optional(f8[:,:]), f8)", fastmath=True, nogil=True)
def _process_with_history(lattice, current_coord_groups, previous_coords, min_dist):
    """Process coordinate groups with history to find valid positions based on minimum distance criteria.

    This function checks coordinates against both historical positions and other coordinates in the current
    group to ensure they maintain a minimum distance from each other. It performs the check in two stages:
    1. Checking against historical coordinates
    2. Self-check within current coordinates and neighbor-check for future coordinates

    Parameters
    ----------
    lattice : array_like
        The lattice matrix defining the periodic boundary conditions
    current_coord_groups : array_like
        Array of coordinate groups to process, shape (N, M, 3) where N is number of groups
        and M is number of coordinates per group
    previous_coords : array_like or None
        Historical coordinates to check against, shape (K, 3) where K is number of historical points
    min_dist : float
        Minimum allowed distance between any two coordinates

    Returns
    -------
    ndarray
        Indices of valid coordinate groups that satisfy the minimum distance criteria

    Notes
    -----
    The function uses periodic boundary conditions for distance calculations and can be
    partially parallelized in both stages of processing.
    """
    current_coord_groups = np.ascontiguousarray(current_coord_groups)
    N = current_coord_groups.shape[0]
    mask = np.ones(N, dtype=np.bool_)

    # Stage 1: 与历史 previous_coords 交叉检测 (可并行)
    if previous_coords is not None:
        for i in range(N):
            coords_i = current_coord_groups[i]

            dist = pbc_all_distances(lattice, coords_i, previous_coords)
            if np.any(dist <= min_dist):
                mask[i] = False

    # Stage 2: self 检测 + 未来 neighbor 检测 (也可并行)
    for i in range(N):
        if not mask[i]:
            continue

        coords_i = current_coord_groups[i]

        dist = pbc_all_distances(lattice, coords_i, None)
        np.fill_diagonal(dist, 1e5)  # Ignore self-distance
        if _check_upper_triangle(dist, min_dist):
            mask[i] = False
            continue

        # Neighbor-check
        for j in range(i + 1, N):
            if not mask[j]:
                continue

            coords_j = current_coord_groups[j]
            dist = pbc_all_distances(lattice, coords_i, coords_j)
            if np.any(dist <= min_dist):
                mask[j] = False

    return np.nonzero(mask)[0]


@njit(fastmath=True, nogil=True)
def _generate_mesh(
    abc: np.ndarray, coord_freedom: np.ndarray, min_dist: float, perturbation: float = 0.0
) -> np.ndarray:
    """Generate a mesh of points in fractional coordinates.

    This function creates a regular mesh of points in fractional coordinates (ranging from 0 to 1)
    based on the unit cell parameters and coordinate freedoms. Optional random perturbation
    can be applied to the mesh points.

    Args:
        abc (np.ndarray): Unit cell parameters [a, b, c] in Angstroms.
        coord_freedom (tuple): Boolean tuple (length 3) indicating which directions (a,b,c)
            should have multiple mesh points. True allows multiple points, False constrains to center.
        min_dist (float): Minimum distance between mesh points in Angstroms.
        perturbation (float, optional): Standard deviation for random normal perturbation
            to apply to mesh points. Defaults to 0.0.

    Returns:
        np.ndarray: Array of shape (N,3) containing fractional coordinates of mesh points,
            where N is the total number of points in the mesh. Values are clipped to [0,1).
    """

    # Calculate number of mesh points in a, b, c directions
    a, b, c = abc[0], abc[1], abc[2]
    l = int(np.ceil(a / min_dist)) if coord_freedom[0] else 1
    m = int(np.ceil(b / min_dist)) if coord_freedom[1] else 1
    n = int(np.ceil(c / min_dist)) if coord_freedom[2] else 1

    x = _generate_coords(l) if coord_freedom[0] else np.array([0.5])
    y = _generate_coords(m) if coord_freedom[1] else np.array([0.5])
    z = _generate_coords(n) if coord_freedom[2] else np.array([0.5])

    # Cartesian product without meshgrid
    mesh = np.zeros((len(x) * len(y) * len(z), 3))
    idx = 0
    for i in range(len(x)):
        for j in range(len(y)):
            for k in range(len(z)):
                mesh[idx, 0] = x[i]
                mesh[idx, 1] = y[j]
                mesh[idx, 2] = z[k]
                idx += 1

    if perturbation > 0.0:
        # Ensure that the generated coordinates are within the range [0, 1)
        mesh += np.random.normal(0, perturbation, mesh.shape)
        mesh = np.clip(mesh, 0, 1)

    return mesh


@njit(fastmath=True, nogil=True)
def generate_valid_positions(
    lattice: np.ndarray,
    abc: np.ndarray,
    pos_generators: List,
    free_coords: np.ndarray,
    min_dist: float,
    perturbation: float = 0.0,
):
    """Generate valid atomic positions based on Wyckoff positions and minimum distance constraints.

    This function generates crystallographically valid positions by applying Wyckoff position generators
    and filtering them based on minimum distance requirements between atoms.

    Args:
        lattice (np.ndarray): 3x3 matrix representing the lattice vectors
        pos_generators (list): List of Wyckoff position generator functions
        free_coords (list): List of boolean arrays indicating free coordinates for each Wyckoff position
        min_dist (float): Minimum allowed distance between atoms in Angstroms
        perturbation (float, optional): Random perturbation magnitude to add to mesh points. Defaults to 0.0

    Returns:
        tuple:
            - position_idx_pool (np.ndarray): Array containing (start_idx, size, multiplicity) for each Wyckoff position
            - valid_positions (np.ndarray): Array of valid atomic positions in fractional coordinates

    Notes:
        - Each generator function takes (x,y,z) coordinates and returns all equivalent positions
        - Free coordinates determine which dimensions can be varied for position generation
        - Positions are filtered to maintain minimum distance constraints both within and between Wyckoff positions
        - Results are returned as contiguous arrays for efficient processing
    """

    n = 0
    valid_positions = np.empty((0, 3), dtype=np.float64)
    position_idx_pool = np.empty((free_coords.shape[0], 3), dtype=np.int64)
    for i, (generator, freed_coord) in enumerate(zip(pos_generators, free_coords)):
        # Verify generator behavior with (0.0, 0.0, 0.0)
        mul = generator(0.0, 0.0, 0.0).shape[0]
        # Generate corresponding mesh based on wyckoff_pos freedom
        if not np.any(freed_coord):
            wyckoff_mesh = np.array([[0.5, 0.5, 0.5]])
        else:
            wyckoff_mesh = _generate_mesh(abc, freed_coord, min_dist, perturbation)

        # Randomly shuffle mesh
        np.random.shuffle(wyckoff_mesh)

        # Generate mesh points
        current_pos_group = np.zeros((wyckoff_mesh.shape[0], mul, 3), dtype=np.float64)
        for j in range(wyckoff_mesh.shape[0]):
            current_pos_group[j] = generator(wyckoff_mesh[j][0], wyckoff_mesh[j][1], wyckoff_mesh[j][2])

        if valid_positions.shape[0] > 0:  # Reject previous positions
            mesh_mask = _process_with_history(lattice, current_pos_group, valid_positions, min_dist)
        else:  # Reject self narrow distances mesh
            mesh_mask = _process_with_history(lattice, current_pos_group, None, min_dist)

        # Save valid positions as previous_pos
        current_pos = select_rows3(current_pos_group, mesh_mask)
        current_pos = np.ascontiguousarray(current_pos)

        position_idx_pool[i] = np.array((n, current_pos.shape[0], current_pos_group.shape[1]), dtype=np.int64)
        if current_pos.shape[0] > 0:
            n += current_pos.shape[0] * current_pos.shape[1]
        valid_positions = np.vstack((valid_positions, current_pos.reshape(-1, 3)))

    return position_idx_pool, valid_positions
