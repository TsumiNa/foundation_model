# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import pytest

from shotgun_csp.core.exception import GenerationError
from shotgun_csp.core.wyckoff.position import Particle


def test_particle_parsing():
    """Test parsing of particle positions."""
    # Test basic particle
    particle = Particle("x,y,1/2")
    assert particle.coord_x.x == 1.0 and particle.coord_x.y == 0.0 and particle.coord_x.z == 0.0
    assert particle.coord_y.x == 0.0 and particle.coord_y.y == 1.0 and particle.coord_y.z == 0.0
    assert particle.coord_z.x == 0.0 and particle.coord_z.y == 0.0 and particle.coord_z.bias == 0.5

    # Test complex particle
    particle = Particle("y-2x+1/2, x-2z+1/2, z-2y+1/2")
    assert particle.coord_x.x == -2.0 and particle.coord_x.y == 1.0 and particle.coord_x.bias == 0.5
    assert particle.coord_y.x == 1.0 and particle.coord_y.z == -2.0 and particle.coord_y.bias == 0.5
    assert particle.coord_z.y == -2.0 and particle.coord_z.z == 1.0 and particle.coord_z.bias == 0.5


def test_invalid_particle():
    """Test error handling for invalid particle expressions."""
    with pytest.raises(GenerationError):
        Particle("x,y")  # Missing z coordinate

    with pytest.raises(GenerationError):
        Particle("x,y,z,w")  # Extra coordinate

    with pytest.raises(GenerationError):
        Particle("x;y;z")  # Wrong separator


def test_particle_gen():
    """Test the generation of particle positions based on input coordinates."""
    # Test basic generation
    particle = Particle("x,y,z")
    coords = particle.gen(0.5, 0.25, 0.75)
    assert coords[0] == pytest.approx(0.5)
    assert coords[1] == pytest.approx(0.25)
    assert coords[2] == pytest.approx(0.75)

    # Test with constants
    particle = Particle("1/4,1/2,3/4")
    coords = particle.gen(0.1, 0.2, 0.3)
    assert coords[0] == pytest.approx(0.25)
    assert coords[1] == pytest.approx(0.5)
    assert coords[2] == pytest.approx(0.75)

    # Test with linear combinations
    particle = Particle("x+y,y+z,x-z")
    coords = particle.gen(0.1, 0.2, 0.3)
    assert coords[0] == pytest.approx(0.3)  # 0.1 + 0.2
    assert coords[1] == pytest.approx(0.5)  # 0.2 + 0.3
    assert coords[2] == pytest.approx(-0.2)  # 0.1 - 0.3
