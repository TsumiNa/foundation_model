# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import numpy as np
import pytest
from numpy.testing import assert_allclose

from shotgun_csp.core.exception import GenerationError
from shotgun_csp.core.wyckoff.position import WyckoffPosition


def test_wyckoff_pos_parsing():
    """Test parsing of Wyckoff position strings."""
    # Test basic Wyckoff position
    wyckoff = WyckoffPosition("(x,y,z), (-x,y+1/2,-z+1/2), (-x,-y,-z), (x,-y+1/2,z+1/2)")
    assert len(wyckoff._particles) == 4

    wyckoff = WyckoffPosition("(x,y,1/2)(-y,x-y,1/2)(-x+y,-x,1/2)")
    assert len(wyckoff._particles) == 3

    # Test position generation
    coords = wyckoff.gen(1.0, 1.0, 1.0)
    expected = np.array([[1.0, 1.0, 0.5], [0.0, 0.0, 0.5], [0.0, 0.0, 0.5]])
    assert_allclose(coords, expected, atol=1e-7)


def test_invalid_wyckoff_pos():
    """Test error handling for invalid Wyckoff position strings."""
    with pytest.raises(GenerationError):
        WyckoffPosition("x,y,z")  # Missing parentheses

    with pytest.raises(GenerationError):
        WyckoffPosition("(x,y,z")  # Unclosed parenthesis

    with pytest.raises(GenerationError):
        WyckoffPosition("(x,y,z)(")  # Invalid second position

    with pytest.raises(GenerationError):
        WyckoffPosition("  (a,b,c)   (d,e,f)  ")  # Invalid characters


def test_wyckoff_pos_with_shifts():
    """Test Wyckoff positions with shifts."""
    wyckoff = WyckoffPosition("(x,y,1/2)(-y,x-y,1/2)", shifts=np.array([(0.1, 0.1, 0.1)]))

    coords = wyckoff.gen(1.0, 1.0, 1.0)
    expected = np.array(
        [
            [1.0, 1.0, 0.5],
            [0.0, 0.0, 0.5],
            [0.1, 0.1, 0.6],  # Original + shift
            [0.1, 0.1, 0.6],  # Original + shift
        ]
    )
    assert_allclose(coords, expected, atol=1e-7)

    # Test cached property is correct
    coords = wyckoff.gen(0.5, 1.0, 0.5)
    expected = np.array(
        [
            [0.5, 1.0, 0.5],
            [0.0, 0.5, 0.5],
            [0.6, 0.1, 0.6],  # Original + shift
            [0.1, 0.6, 0.6],  # Original + shift
        ]
    )
    assert_allclose(coords, expected, atol=1e-7)

    # Test new Wyckoff position with different shifts
    wyckoff = WyckoffPosition("(-z,y,1/2)(x,x-y,1/2)", shifts=np.array([(0.2, 0.1, 0.0)]))

    coords = wyckoff.gen(1.0, 1.0, 1.0)
    expected = np.array(
        [
            [0.0, 1.0, 0.5],
            [1.0, 0.0, 0.5],
            [0.2, 0.1, 0.5],  # Original + shift
            [0.2, 0.1, 0.5],  # Original + shift
        ]
    )
    assert_allclose(coords, expected, atol=1e-7)


def test_wyckoff_pos_caching():
    """Test caching of constant Wyckoff positions."""
    # Position without variables should be cached
    wyckoff = WyckoffPosition("(1/2,1/2,1/2)")
    assert wyckoff.is_cached

    coords1 = wyckoff.gen(0.0, 0.0, 0.0)
    coords2 = wyckoff.gen(1.0, 1.0, 1.0)
    assert_allclose(coords1, coords2, atol=1e-7)  # Should return same cached values
    assert_allclose(coords1, [[0.5, 0.5, 0.5]], atol=1e-7)

    # Position with variables should not be cached
    wyckoff = WyckoffPosition("(x,y,z)")
    assert not wyckoff.is_cached


def test_wyckoff_pos_random_gen():
    """Test random generation of Wyckoff positions."""
    wyckoff = WyckoffPosition("(x,y,z)")
    coords1 = wyckoff.random_gen()
    coords2 = wyckoff.random_gen()
    assert not np.allclose(coords1, coords2)  # Should generate different positions

    # Cached positions should return same values
    wyckoff = WyckoffPosition("(1/2,1/2,1/2)")
    coords1 = wyckoff.random_gen()
    coords2 = wyckoff.random_gen()
    assert_allclose(coords1, coords2, atol=1e-7)
