# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import pytest

from shotgun_csp.core.exception import GenerationError
from shotgun_csp.core.wyckoff.position import Coordinate


def test_coordinate_parsing():
    """Test parsing of coordinate expressions."""
    # Test basic coordinates
    coord = Coordinate("x")
    assert coord.x == 1.0 and coord.y == 0.0 and coord.z == 0.0 and coord.bias == 0.0

    coord = Coordinate("-y")
    assert coord.x == 0.0 and coord.y == -1.0 and coord.z == 0.0 and coord.bias == 0.0

    coord = Coordinate("2z")
    assert coord.x == 0.0 and coord.y == 0.0 and coord.z == 2.0 and coord.bias == 0.0

    # Test fractions and constants
    coord = Coordinate("1/2")
    assert coord.x == 0.0 and coord.y == 0.0 and coord.z == 0.0 and coord.bias == 0.5

    coord = Coordinate("1")
    assert coord.x == 0.0 and coord.y == 0.0 and coord.z == 0.0 and coord.bias == 1.0

    # Test complex expressions
    coord = Coordinate("-x+y-2z+1/2")
    assert coord.x == -1.0 and coord.y == 1.0 and coord.z == -2.0 and coord.bias == 0.5


def test_invalid_coordinate():
    """Test error handling for invalid coordinate expressions."""
    with pytest.raises(GenerationError):
        Coordinate("invalid")

    with pytest.raises(GenerationError):
        Coordinate("x+")

    with pytest.raises(GenerationError):
        Coordinate("1/")

    with pytest.raises(GenerationError):
        Coordinate("xx+yy+zz")


def test_coordinate_gen():
    """Test the gen method of Coordinate class."""
    # Test with single coordinate component
    coord_generator = Coordinate("x").generator
    assert coord_generator(0.5, 0.0, 0.0) == 0.5
    assert coord_generator(1.0, 0.0, -2.0) == 1.0
    assert coord_generator(-1.0, 5.0, 0.0) == -1.0

    coord_generator = Coordinate("y").generator
    assert coord_generator(0.0, 0.5, 0.0) == 0.5
    assert coord_generator(1.0, 1.0, 0.0) == 1.0

    coord_generator = Coordinate("z").generator
    assert coord_generator(2.0, 1.0, 0.5) == 0.5

    # Test with coefficients
    coord_generator = Coordinate("2x").generator
    assert coord_generator(0.5, 0.0, 0.0) == 1.0

    coord_generator = Coordinate("-3y").generator
    assert coord_generator(0.0, 0.5, 0.0) == -1.5

    # Test with bias
    coord_generator = Coordinate("1/2").generator
    assert coord_generator(0.0, 0.0, 0.0) == 0.5
    assert coord_generator(1.0, 1.0, 1.0) == 0.5

    # Test with multiple components
    coord_generator = Coordinate("x+y").generator
    assert coord_generator(0.5, 0.5, 0.0) == 1.0
    assert coord_generator(0.3, 0.7, 0.0) == 1.0

    coord_generator = Coordinate("x+y+z").generator
    assert coord_generator(0.3, 0.3, 0.4) == 1.0

    # Test with complex expressions
    coord_generator = Coordinate("-x+2y-3z+1/4").generator
    assert coord_generator(0.5, 0.5, 0.5) == -0.5 + 1.0 - 1.5 + 0.25
    assert coord_generator(1.0, 2.0, 3.0) == -1.0 + 4.0 - 9.0 + 0.25

    # Test with zero values
    coord_generator = Coordinate("x-y+z").generator
    assert coord_generator(0.0, 0.0, 0.0) == 0.0
