# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import re
from functools import cached_property

from numba import njit

from shotgun_csp.core.exception import GenerationError


class Coordinate:
    """Class representing a 3D coordinate with an optional bias term."""

    # Regex pieces for coordinate and offset blocks
    COORD_BLOCK = r"[+-]?\s*(?:[0-9]\d*)?\s*[xyz]"
    ADDITIONAL_COORDS = r"(?:\s*[+-]\s*(?:[0-9]\d*)?\s*[xyz])*"
    # In coordinate expressions, offset must start with a sign.
    OFFSET_BLOCK = r"[+-]\s*(?:[0-9]\d*)(?:\s*/\s*[0-9]\d*)?"
    # For offset-only expressions, the '+' sign can be omitted.
    OFFSET_ONLY_BLOCK = r"[+-]?\s*(?:[0-9]\d*)(?:\s*/\s*[0-9]\d*)?"

    # Full pattern accepts either:
    #   1. A coordinate expression (one or more coordinate blocks) optionally followed by an offset block, or
    #   2. An offset-only expression.
    PATTERN_COORDS_WITH_OPTIONAL_OFFSET = COORD_BLOCK + ADDITIONAL_COORDS + r"(?:\s*" + OFFSET_BLOCK + r")?"
    FULL_PATTERN = re.compile(r"^(?:" + PATTERN_COORDS_WITH_OPTIONAL_OFFSET + r"|" + OFFSET_ONLY_BLOCK + r")$")

    # Precompiled patterns to extract parts
    COORD_PATTERN = re.compile(r"([+-]?)\s*([0-9]\d*)?\s*([xyz])")
    OFFSET_PATTERN = re.compile(r"([+-])\s*([0-9]\d*)(?:\s*/\s*([0-9]\d*))?")
    OFFSET_ONLY_PATTERN = re.compile(r"([+-]?)\s*([0-9]\d*)(?:\s*/\s*([0-9]\d*))?")

    def __init__(self, s: str):
        """Parse a coordinate from a string representation."""
        self._x = 0.0
        self._y = 0.0
        self._z = 0.0
        self._bias = 0.0

        def parse_offset(text: str) -> float:
            """
            Parses an offset block (which must start with a sign) and returns its float value.
            """
            m = self.OFFSET_PATTERN.fullmatch(text.strip())
            if not m:
                raise GenerationError(self, "The offset block format is incorrect")
            sign, num_str, denom_str = m.group(1), m.group(2), m.group(3)
            value = int(num_str)
            if denom_str:
                value /= int(denom_str)
            return -value if sign == "-" else value

        def parse_offset_only(text: str) -> float:
            """
            Parses an offset-only expression (the '+' sign may be omitted) and returns its float value.
            """
            m = self.OFFSET_ONLY_PATTERN.fullmatch(text.strip())
            if not m:
                raise GenerationError(self, f"The offset-only block format is incorrect. error str: {text}")
            sign, num_str, denom_str = m.group(1), m.group(2), m.group(3)
            value = int(num_str)
            if denom_str:
                value /= int(denom_str)
            return -value if sign == "-" else value

        # Validate overall format
        if self.FULL_PATTERN.fullmatch(s) is None:
            raise GenerationError(self, f"the string must be something like `x-2z+1/2`. error str: {s}")

        cursor = 0
        # Extract coordinate blocks (if any)
        coord_matches = list(self.COORD_PATTERN.finditer(s))
        if coord_matches:
            cursor = 0
            for m in coord_matches:
                # Ensure only spaces exist between blocks
                if m.start() != cursor and s[cursor : m.start()].strip():
                    break
                sign, coef, var = m.group(1), m.group(2), m.group(3)
                value = int(coef) if coef else 1
                if sign == "-":
                    value = -value
                if var == "x":
                    self._x = value
                elif var == "y":
                    self._y = value
                elif var == "z":
                    self._z = value
                cursor = m.end()
            # Process any remaining part as an offset block
            remaining = s[cursor:].strip()
            if remaining:
                self._bias = parse_offset(remaining)
        else:
            # No coordinate blocks found: parse entire string as an offset-only expression.
            self._bias = parse_offset_only(s)

    @cached_property
    def generator(self):
        _x, _y, _z, _bias = self._x, self._y, self._z, self._bias

        @njit("float64(float64, float64, float64)", nogil=True, fastmath=True)
        def gen(x: float, y: float, z: float) -> float:
            """Generate the value based on the input x, y, z values."""
            return _x * x + _y * y + _z * z + _bias

        return gen

    @property
    def x(self) -> float:
        """Get the coefficient for the x-axis."""
        return self._x

    @property
    def y(self) -> float:
        """Get the coefficient for the y-axis."""
        return self._y

    @property
    def z(self) -> float:
        """Get the coefficient for the z-axis."""
        return self._z

    @property
    def bias(self) -> float:
        """Get the bias term."""
        return self._bias

    def gen(self, x: float, y: float, z: float) -> float:
        """Generate the value based on the input x, y, z values."""
        return self.generator(x, y, z)
