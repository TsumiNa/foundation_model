# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0


import numpy as np
from beartype.typing import Dict, List, Optional, Tuple
from joblib import Parallel, delayed
from numba import njit, prange
from tqdm.auto import tqdm

from shotgun_csp.core import GeneratorArgs
from shotgun_csp.core.exception import GenerationError
from shotgun_csp.core.utils import COVALENT_RADIUS, WY
from shotgun_csp.core.wyckoff.lattice import Lattice
from shotgun_csp.core.wyckoff.lattice.lattice import check_distance
from shotgun_csp.core.wyckoff.position import WyckoffPosition
from shotgun_csp.core.wyckoff.position.mesh import generate_valid_positions
from shotgun_csp.core.wyckoff.structure import CrystalStructure

__all__ = ["CrystalGenerator"]


@njit(fastmath=True, nogil=True)
def _pad_array(arr, fixed_length):
    """
    Accepts an int64 array (with maximum length <= fixed_length) and returns an
    int64 array of length fixed_length. If the input array is shorter, the remaining
    positions are filled with -1.

    Parameters:
      arr (np.ndarray): Input array of type int64.
      fixed_length (int): The desired length of the output array.

    Returns:
      np.ndarray: An int64 array of length fixed_length.
    """
    result = np.full(fixed_length, -1, dtype=np.int64)
    n = len(arr)
    for i in prange(n):
        if i >= fixed_length:
            break
        result[i] = arr[i]
    return result


@njit(fastmath=True, nogil=True)
def suggest_min_dist(volume, n_atoms, avg_dist=None):
    """Calculate a suggested minimum distance between atoms in a crystal structure.

    This function estimates a reasonable minimum distance between atoms based on the
    volume of the crystal and number of atoms, optionally considering a given average distance.

    Args:
        volume (float): Volume of the crystal structure in cubic angstroms
        n_atoms (int): Number of atoms in the structure
        avg_dist (float, optional): Average distance between atoms. Defaults to None.

    Returns:
        float: Suggested minimum distance between atoms. If avg_dist is provided,
              returns the minimum between the calculated spacing and avg_dist.

    Notes:
        The function calculates volume per atom and takes its cube root to get an
        initial spacing estimate. This is then reduced by 10% to be more conservative.
    """
    volume_per_atom = volume / n_atoms
    spacing = volume_per_atom ** (1 / 3)
    spacing = spacing * 0.8  # 稍保守一点

    if avg_dist is not None:
        return min(spacing, avg_dist)
    return spacing


@njit(fastmath=True, nogil=True)
def _mesh_based_gen_one(
    func_idx,
    pos_funcs,
    pos_freedom,
    n_atoms,
    lattice_func,
    avg_atomic_dist,
    atomic_dist_decay_rate: float = 0.002,
    perturbation: float = 0.0,
    max_attempts=1000,
):
    """Generate one crystal structure using mesh-based approach.

    Args:
        lattice: Lattice matrix
        abc: Lattice constants [a, b, c]
        min_dist: Minimum atomic distance
        func_idx: Array of position function indices (must be int64 array, not a Python list)
        pos_funcs: Position generator functions
        pos_freedom: Position freedom flags
        n_atoms: Number of atoms
        atomic_dist_decay_rate: Rate to reduce min_dist when retrying
        perturbation: Random perturbation to add to positions
        max_attempts: Maximum number of generation attempts

    Returns:
        Tuple of (positions, success_flag)
    """
    lattice, abc, _, volume = lattice_func()
    min_dist = suggest_min_dist(volume, n_atoms, avg_atomic_dist)

    ret_entry = np.empty((n_atoms + 3, 3), dtype=np.float64)
    ret_entry[:3] = lattice

    for _ in range(max_attempts):
        min_dist = min_dist * (1 - atomic_dist_decay_rate)
        # We can assure that the atomic distance is too small so the current wyckoff cfg is not fit the composition
        if min_dist < avg_atomic_dist * 0.6:
            break
        position_idx_pool, valid_positions = generate_valid_positions(
            lattice, abc, pos_funcs, pos_freedom, min_dist, perturbation
        )

        # First check there are enough positions for each wyckoff letter for use
        # if not, retry
        idx_pool_ = position_idx_pool.copy()
        checker = False
        for f_idx in func_idx:
            idx_pool_[f_idx, 1] -= 1
            if idx_pool_[f_idx, 1] < 0:
                checker = True
                break
        if checker:
            continue

        cursor = 3
        for f_idx in func_idx:
            position_idx = position_idx_pool[f_idx]
            start, mul = position_idx[0], position_idx[2]

            particles: np.ndarray = valid_positions[start : start + mul]
            ret_entry[cursor : cursor + mul] = particles
            cursor += mul

            position_idx_pool[f_idx][0] += mul  # move start one step
        return ret_entry, volume, True
    return ret_entry, volume, False


@njit(fastmath=True, nogil=True)
def _random_gen_one(
    func_idx,
    pos_funcs,
    n_atoms,
    lattice_func,
    avg_atomic_dist,
    atomic_dist_decay_rate: float = 0.002,
    check_atomic_dist: bool = False,
    max_attempts=1000,
):
    """Generate one crystal structure using random coordinates.

    Args:
        lattice: Lattice matrix
        min_dist: Minimum atomic distance
        func_idx: Array of position function indices (must be int64 array, not a Python list)
        pos_funcs: Position generator functions
        n_atoms: Number of atoms
        atomic_dist_decay_rate: Rate to reduce min_dist when retrying
        check_atomic_dist: Whether to check atomic distances
        max_attempts: Maximum number of generation attempts

    Returns:
        Tuple of (positions, success_flag)
    """
    lattice, _, _, volume = lattice_func()
    min_dist = suggest_min_dist(volume, n_atoms, avg_atomic_dist)

    ret_entry = np.empty((n_atoms + 3, 3), dtype=np.float64)
    ret_entry[:3] = lattice

    if check_atomic_dist:
        for _ in prange(max_attempts):
            cursor = 3
            min_dist = min_dist * (1 - atomic_dist_decay_rate)
            # We can assure that the atomic distance is too small so the current wyckoff cfg is not fit the composition
            if min_dist < avg_atomic_dist * 0.6:
                break
            for f_idx in func_idx:
                x, y, z = np.random.uniform(0.0, 1.0, 3)
                particles: np.ndarray = pos_funcs[f_idx](x, y, z)
                mul = len(particles)
                ret_entry[cursor : cursor + mul] = particles
                cursor += mul

            if check_distance(lattice, ret_entry, min_dist):
                return ret_entry, volume, True
        return ret_entry, volume, False

    else:
        cursor = 3
        for f_idx in func_idx:
            x, y, z = np.random.uniform(0.0, 1.0, 3)
            particles: np.ndarray = pos_funcs[f_idx](x, y, z)
            mul = len(particles)
            ret_entry[cursor : cursor + mul] = particles
            cursor += mul
        return ret_entry, volume, True


class CrystalGenerator:
    def __init__(
        self,
        generator_args: GeneratorArgs,
    ):
        """
        CrystalGenerator is a class for generating crystal structures based on Wyckoff positions and space group symmetry.

        This generator supports both serial and parallel generation of crystal structures, with options for mesh-based
        or random generation, atomic distance constraints, and customizable lattice parameters.

            generator_args (GeneratorArgs): Arguments specifying the space group, lattice, and generation parameters.

        Attributes:
            _args (GeneratorArgs): The arguments used for generation.
            _lattice (Lattice): The lattice generator instance.
            _positions (List[WyckoffPosition]): List of Wyckoff position generators, sorted by letter.
            _multiplicity (Dict[str, int]): Multiplicity for each Wyckoff letter.
            _reuse (Dict[str, bool]): Whether each Wyckoff letter can be reused.
            _n_atoms (Dict[str, int]): Number of atoms for each Wyckoff letter.

        Methods:
            _letter_to_index(letter): Convert a Wyckoff letter to its alphabet index (e.g., 'a' -> 0).
            _get_positions(wyckoff_cfg): Parse Wyckoff configuration and return atom and position information.
            _generate_one_job(...): Generate a single crystal structure (for parallel execution).
            _generate_crystals(...): Generate multiple crystal structures, optionally in parallel.
            __call__(...): Main interface for generating crystal structures from Wyckoff configurations.
            volume_of_cell: Property returning the cell volume.
            variance_of_volume: Property returning the variance of the cell volume.
            angle_range: Property returning the allowed angle range for the lattice.
            max_attempts: Property returning the maximum number of generation attempts.
            space_group_num: Property returning the space group number.
            __repr__(): String representation of the generator.

        Raises:
            GenerationError: If invalid Wyckoff letters or parameters are provided.

        Usage:
            Instantiate with GeneratorArgs, then call with Wyckoff configurations to generate structures.
        """
        self._args = generator_args
        self._lattice = Lattice(generator_args)

        # Build the Wyckoff positions for the space group number
        # Dict[letter, [multiplicity, reuse, pattern]]
        wy: Dict[str, Tuple[int, bool, str]] = WY[generator_args.space_group_num - 1]
        self._positions: List[WyckoffPosition] = []
        self._multiplicity: Dict[str, int] = {}
        self._reuse: Dict[str, bool] = {}
        self._n_atoms: Dict[str, int] = {}

        _positions = {}
        for letter, (multiplicity, reuse, pattern) in wy.items():
            p = WyckoffPosition(pattern, shifts=generator_args.identical_sites, decimals=generator_args.decimals)
            tmp = p.generator(0.0, 0.0, 0.0)  # warm up
            self._multiplicity[letter] = multiplicity
            self._reuse[letter] = reuse
            _positions[letter] = p
            self._n_atoms[letter] = len(tmp)

        self._positions = [_positions[k] for k in sorted(_positions.keys())]  # sort by key

    @staticmethod
    def _letter_to_index(letter):
        """
        Takes a letter and returns its position in the alphabet minus 1.
        For example: 'a' -> 0, 'b' -> 1, 'z' -> 25
        """
        if not isinstance(letter, str) or len(letter) != 1 or not letter.isalpha():
            raise ValueError("letter must be a single character")

        # Convert the letter to lowercase and calculate the offset from 'a'
        return ord(letter.lower()) - ord("a")

    def _get_positions(self, wyckoff_cfg: Dict[str, List[str]]):
        elements: List[str] = []
        letters: List[str] = []
        position_func_idx = []
        for elem, letters_ in wyckoff_cfg.items():
            for l in letters_:
                if l not in self._multiplicity:
                    raise GenerationError(
                        self, f"Invalid Wyckoff letter: '{l}' for space group {self._args.space_group_num}"
                    )
                multiplicity = self._multiplicity[l]
                elements.extend([elem] * multiplicity)
                letters.extend([l] * multiplicity)
                position_func_idx.append(self._letter_to_index(l))
        avg_atomic_dist = sum([COVALENT_RADIUS[elem] for elem in elements]) / len(elements) * 2.0
        position_func_idx = _pad_array(np.array(position_func_idx, dtype=np.int64), len(elements))
        n_atoms = len(elements)
        return (elements, letters, position_func_idx), (n_atoms, avg_atomic_dist)

    @staticmethod
    def _generate_one_job(
        i,
        j,
        pos_func_indices,
        pos_funcs,
        pos_freedom,
        n_atoms,
        avg_atomic_dist,
        gen_lattice_func,
        use_mesh=False,
        perturbation=0.0,
        atomic_dist_decay_rate=0.002,
        check_atomic_dist=False,
        max_attempts=1000,
    ):
        """Single job function for parallel crystal generation with joblib."""
        # Extract non-negative function indices and convert to numpy array
        # to avoid numba's "reflected list" deprecation warning
        func_idx_array = np.array([k for k in pos_func_indices[i] if k > -1], dtype=np.int64)

        # Only generate the positions for letter a to last required letter
        max_letter = func_idx_array.max() + 1
        if use_mesh:
            ret_entry, volume, success = _mesh_based_gen_one(
                func_idx_array,
                pos_funcs[:max_letter],
                pos_freedom[:max_letter],
                n_atoms,
                gen_lattice_func,
                avg_atomic_dist,
                atomic_dist_decay_rate,
                perturbation,
                max_attempts,
            )
        else:
            ret_entry, volume, success = _random_gen_one(
                func_idx_array,
                pos_funcs[:max_letter],
                n_atoms,
                gen_lattice_func,
                avg_atomic_dist,
                atomic_dist_decay_rate,
                check_atomic_dist,
                max_attempts,
            )

        return (i, j, ret_entry, volume, success)

    def _generate_crystals(
        self,
        expect_size,
        pos_func_indices,
        pos_funcs,
        pos_freedom,
        gen_lattice_func,
        n_atoms,
        avg_atomic_dist,
        use_mesh=False,
        perturbation=0.0,
        atomic_dist_decay_rate=0.002,
        check_atomic_dist=False,
        max_attempts=1000,
        n_jobs=1,
        progress_bar=False,
    ):
        """
        Generate crystal structures using joblib for parallelization.

        This function supports both serial execution (n_jobs=1) and
        parallel execution (n_jobs>1) through joblib.
        """
        # Calculate the number of configurations per Wyckoff position
        n_wyckoff_cfgs = len(pos_func_indices)
        n_per_wyckoff = round(expect_size / n_wyckoff_cfgs)
        if n_per_wyckoff < 1:
            n_per_wyckoff = 1

        # Initialize arrays for results
        ret = np.empty((n_wyckoff_cfgs, n_per_wyckoff, n_atoms + 3, 3), dtype=np.float64)
        checked = np.zeros((n_wyckoff_cfgs, n_per_wyckoff), dtype=np.bool_)
        volumes = np.empty((n_wyckoff_cfgs, n_per_wyckoff), dtype=np.float64)

        # Create task list
        tasks = [(i, j) for i in range(n_wyckoff_cfgs) for j in range(n_per_wyckoff)]

        # Configure progress bar if needed
        if progress_bar:
            tasks = tqdm(tasks, total=len(tasks), desc="Generating crystals")

        # Execute jobs with joblib
        results = Parallel(n_jobs=n_jobs, backend="loky", batch_size=max(n_jobs, 1))(
            delayed(self._generate_one_job)(
                i,
                j,
                pos_func_indices,
                pos_funcs,
                pos_freedom,
                n_atoms,
                avg_atomic_dist,
                gen_lattice_func,
                use_mesh,
                perturbation,
                atomic_dist_decay_rate,
                check_atomic_dist,
                max_attempts,
            )
            for i, j in tasks
        )

        # Process results
        for i, j, ret_entry, vol, success in results:
            ret[i, j] = ret_entry
            volumes[i, j] = vol
            checked[i, j] = success

        return ret, volumes, checked

    def __call__(
        self,
        *wyckoff_cfgs: List[Dict[str, List[str]]],
        expect_size: int = 1,
        use_mesh: Optional[bool] = None,
        perturbation: Optional[float] = None,
        atomic_dist_decay_rate: Optional[float] = None,
        check_atomic_dist: Optional[bool] = None,
        return_crystal_structures: bool = False,
        progress_bar: bool = False,
        n_jobs: int = 1,  # New parameter for controlling joblib parallelism
    ):
        """
        Generate crystal structures based on Wyckoff configurations.

        Parameters:
            wyckoff_cfgs: List of dictionaries mapping element names to Wyckoff positions
            expect_size: Expected number of structures to generate
            use_mesh: Whether to use mesh-based generation
            perturbation: Amount of perturbation to apply to positions
            atomic_dist_decay_rate: Rate at which to reduce atomic distance constraints
            check_atomic_dist: Whether to check atomic distances
            return_crystal_structures: Whether to return CrystalStructure objects
            progress_bar: Whether to show a progress bar
            n_jobs: Number of parallel jobs (1 for serial, >1 for parallel, -1 for all CPUs)

        Returns:
            Tuple or List: Generated structures
        """
        if len(wyckoff_cfgs) == 0:
            raise GenerationError(self, "Wyckoff configurations are empty")

        # Use generator_args values for None parameters
        use_mesh = self._args.use_mesh if use_mesh is None else use_mesh
        perturbation = self._args.perturbation if perturbation is None else perturbation
        atomic_dist_decay_rate = (
            self._args.atomic_dist_decay_rate if atomic_dist_decay_rate is None else atomic_dist_decay_rate
        )
        check_atomic_dist = self._args.check_atomic_dist if check_atomic_dist is None else check_atomic_dist

        # Check if the number of Wyckoff configurations is less than 10,000
        # to determine if parallelization should be used
        if not 0.0 <= atomic_dist_decay_rate <= 0.005:
            raise GenerationError(self, "atomic_dist_decay_rate must be between 0 and 0.005")

        max_attempts = self._args.max_attempts
        gen_lattice_func = self._lattice.generator
        _ = gen_lattice_func()

        atom_wy_pairs = []
        position_func_indices = []
        for wyckoff_cfg in wyckoff_cfgs:
            (atoms, letters, position_func_idx), (n_atoms, avg_atomic_dist) = self._get_positions(wyckoff_cfg)
            position_func_indices.append(position_func_idx)
            atom_wy_pairs.append(
                (
                    tuple(atoms),
                    tuple(letters),
                )
            )

        typed_pos_func_indices = np.vstack(position_func_indices)
        typed_pos_funcs = tuple([p.generator for p in self._positions])  # sorted by letters in ascending already
        np_typed_free_coord = np.array([p._coord_freedom for p in self._positions], dtype=np.bool_)

        # Optimization: For single structure generation, bypass joblib overhead
        if len(atom_wy_pairs) == 1 and expect_size == 1:
            i, j = 0, 0  # Single structure at position (0,0)
            _, _, ret_entry, volume, success = self._generate_one_job(
                i,
                j,
                typed_pos_func_indices,
                typed_pos_funcs,
                np_typed_free_coord,
                n_atoms,
                avg_atomic_dist,
                gen_lattice_func,
                use_mesh,
                perturbation,
                atomic_dist_decay_rate,
                check_atomic_dist,
                max_attempts,
            )

            # Direct return for single structure case
            if not return_crystal_structures:
                return ret_entry, volume, success, atom_wy_pairs[0]

            if not success:
                return None

            return CrystalStructure(
                space_group_num=int(self._args.space_group_num),
                volume=float(volume),
                lattice=ret_entry[:3],
                positions=ret_entry[3:],
                atoms=list(atoms),
                wyckoff_letters=list(letters),
            )

        # For multiple structures, use the parallel implementation
        s, v, c = self._generate_crystals(
            expect_size,
            typed_pos_func_indices,
            typed_pos_funcs,
            np_typed_free_coord,
            gen_lattice_func,
            n_atoms,
            avg_atomic_dist,
            use_mesh=use_mesh,
            perturbation=perturbation,
            atomic_dist_decay_rate=atomic_dist_decay_rate,
            check_atomic_dist=check_atomic_dist,
            max_attempts=max_attempts,
            n_jobs=n_jobs,
            progress_bar=progress_bar,
        )

        if not return_crystal_structures:
            return s, v, c, atom_wy_pairs

        ret = []
        for i, (atoms, letters) in enumerate(atom_wy_pairs):
            s_, c_, v_ = s[i], c[i], v[i]
            for l_and_p, volumes, checked in zip(s_, v_, c_):
                if checked:
                    ret.append(
                        CrystalStructure(
                            space_group_num=int(self._args.space_group_num),
                            volume=float(volumes),
                            lattice=l_and_p[:3],
                            positions=l_and_p[3:],
                            atoms=list(atoms),
                            wyckoff_letters=list(letters),
                        )
                    )
        return ret

    @property
    def volume_of_cell(self):
        """
        Returns the volume of the cell.

        This method retrieves the precomputed volume of the cell stored in the
        `_volume_of_cell` attribute.

        Returns:
            float: The volume of the cell.
        """
        return self._args.volume_of_cell

    @property
    def variance_of_volume(self):
        """
        Returns the variance of the volume for the crystal structure.

        This method retrieves the precomputed variance of the volume, which is a measure
        of the dispersion of volume values around the mean volume.

        Returns:
            float: The variance of the volume.
        """
        return self._args.variance_of_volume

    @property
    def angle_range(self):
        """
        Returns the range of angles for the crystal generator.

        This method retrieves the angle range that is used in the crystal
        generation process. The angle range is typically defined as a tuple
        or list of two values representing the minimum and maximum angles.

        Returns:
            tuple: A tuple containing the minimum and maximum angles.
        """
        return self._args.min_angle_degree, self._args.max_angle_degree

    @property
    def max_attempts(self):
        """
        Retrieve the maximum number of attempts allowed for generating a crystal structure.

        Returns:
            int: The maximum number of attempts.
        """
        return self._args.max_attempts

    @property
    def space_group_num(self):
        """
        Retrieve the space group number of the crystal.

        Returns:
            int: The space group number.
        """
        return self._args.space_group_num

    def __repr__(self):
        return f"CrystalGenerator(\
            \n    space_group_num={self.space_group_num},\
            \n    volume_of_cell={self.volume_of_cell},\
            \n    variance_of_volume={self.variance_of_volume},\
            \n    angle_range={self.angle_range},\
            \n    max_attempts_number={self.max_attempts},\
            \n)"
