# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0

import numpy as np
import pytest
from ase import Atoms
from pymatgen.core import Structure

from shotgun_csp.core import GeneratorArgs
from shotgun_csp.core.exception import GenerationError
from shotgun_csp.core.wyckoff.generator import CrystalGenerator
from shotgun_csp.core.wyckoff.structure import CrystalStructure
from shotgun_csp.core.wyckoff.wyckoff_cfg import WyckoffCfgGenerator

"""
Tests for the generator.py module which provides crystal generation functionality.
"""


def test_crystal_generator_initialization():
    # Test basic initialization
    args = GeneratorArgs(
        space_group_num=1,
        volume_of_cell=100.0,
        variance_of_volume=10.0,
        min_angle_degree=60.0,
        max_angle_degree=90.0,
        max_attempts=100,
    )
    generator = CrystalGenerator(args)

    # Check properties
    assert generator.space_group_num == 1
    assert generator.volume_of_cell == 100.0
    assert generator.variance_of_volume == 10.0
    assert generator.angle_range == (60.0, 90.0)
    assert generator.max_attempts == 100


def test_crystal_generator_repr():
    # Test the __repr__ method
    args = GeneratorArgs(
        space_group_num=1,
        volume_of_cell=100.0,
        variance_of_volume=10.0,
        min_angle_degree=60.0,
        max_angle_degree=90.0,
        max_attempts=100,
    )
    generator = CrystalGenerator(args)

    repr_str = repr(generator)
    assert "CrystalGenerator" in repr_str
    assert "space_group_num=1" in repr_str
    assert "volume_of_cell=100.0" in repr_str
    assert "variance_of_volume=10.0" in repr_str
    assert "angle_range=(60.0, 90.0)" in repr_str
    assert "max_attempts_number=100" in repr_str


def test_generator_invalid_atomic_dist_scaler():
    # Test with invalid atomic_dist_scaler values
    args = GeneratorArgs(
        space_group_num=1,
        volume_of_cell=100.0,
        variance_of_volume=10.0,
        max_attempts=100,
    )
    generator = CrystalGenerator(args)

    wyckoff_cfgs = {"Li": ["a"], "O": ["a"]}

    # Test with tolerance = 0
    with pytest.raises(GenerationError, match="atomic_dist_decay_rate must be between 0 and 0.005"):
        generator(wyckoff_cfgs, atomic_dist_decay_rate=-0.1)

    # Test with tolerance > 1
    with pytest.raises(GenerationError, match="atomic_dist_decay_rate must be between 0 and 0.005"):
        generator(wyckoff_cfgs, atomic_dist_decay_rate=1.1)


def test_get_positions_invalid_letter():
    # Test _get_positions with invalid Wyckoff letter
    args = GeneratorArgs(
        space_group_num=1,
        volume_of_cell=100.0,
        variance_of_volume=10.0,
        max_attempts=100,
    )
    generator = CrystalGenerator(args)

    # Try to use a non-existing Wyckoff letter 'z' for space group 1
    wyckoff_cfg = {"Li": ["z"]}

    with pytest.raises(GenerationError, match="Invalid Wyckoff letter"):
        generator._get_positions(wyckoff_cfg)


def test_get_generator_with_multiple_configs():
    # Test generator with multiple Wyckoff configurations
    args = GeneratorArgs(
        space_group_num=1,
        volume_of_cell=100.0,
        variance_of_volume=10.0,
        min_angle_degree=60.0,
        max_angle_degree=90.0,
        max_attempts=100,
    )
    generator = CrystalGenerator(args)

    # Test with multiple Wyckoff configurations
    wyckoff_cfgs = [
        {"Li": ["a"], "O": ["a"]},
        {"Na": ["a"], "Cl": ["a"]},
    ]
    expect_size = 10

    s, _, c, _ = generator(*wyckoff_cfgs, expect_size=expect_size)
    assert s.shape == (2, 5, 5, 3)
    assert c.shape == (2, 5)

    assert np.all(c)


def test_get_generator_narrow_distance():
    # Test generator with multiple Wyckoff configurations
    args = GeneratorArgs(
        space_group_num=1,
        volume_of_cell=10.0,
        variance_of_volume=2.0,
        min_angle_degree=60.0,
        max_angle_degree=90.0,
        max_attempts=100,
    )
    generator = CrystalGenerator(args)

    # Test with multiple Wyckoff configurations
    wyckoff_cfgs = {"Na": ["a", "a", "a", "a", "a", "a", "a", "a"], "Cl": ["a", "a", "a", "a", "a", "a", "a", "a"]}

    expect_size = 10

    s, _, c, _ = generator(wyckoff_cfgs, expect_size=expect_size, atomic_dist_decay_rate=0.0, check_atomic_dist=True)
    assert s.shape == (1, 10, 19, 3)
    assert c.shape == (1, 10)

    assert not np.all(c)


def test_get_generator_with_return_crystal_structure():
    # Test generator with parallel=True
    args = GeneratorArgs(
        space_group_num=1,
        volume_of_cell=100.0,
        variance_of_volume=10.0,
        min_angle_degree=60.0,
        max_angle_degree=90.0,
        max_attempts=100,
    )
    generator = CrystalGenerator(args)

    wyckoff_cfgs = {"Li": ["a"], "O": ["a"]}
    ret = generator(wyckoff_cfgs, return_crystal_structures=True)

    assert isinstance(ret, CrystalStructure)
    assert ret.space_group_num == 1
    assert ret.atoms == ["Li", "O"]
    assert ret.wyckoff_letters == ["a", "a"]

    # generate 5 crystal structure
    ret = generator(wyckoff_cfgs, expect_size=5, return_crystal_structures=True)
    assert len(ret) == 5
    for s in ret:
        assert isinstance(s, CrystalStructure)
        assert s.space_group_num == 1
        assert s.atoms == ["Li", "O"]
        assert s.wyckoff_letters == ["a", "a"]


def test_get_generator_with_progress_bar():
    # Test generator with parallel=True
    args = GeneratorArgs(
        space_group_num=1,
        volume_of_cell=100.0,
        variance_of_volume=10.0,
        min_angle_degree=60.0,
        max_angle_degree=90.0,
        max_attempts=100,
    )
    generator = CrystalGenerator(args)
    wyckoff_cfgs = {"Li": ["a"], "O": ["a"]}
    # generate progress bar
    ret = generator(wyckoff_cfgs, expect_size=20, return_crystal_structures=True, progress_bar=True)
    assert len(ret) == 20
    for s in ret:
        assert isinstance(s, CrystalStructure)
        assert s.space_group_num == 1
        assert s.atoms == ["Li", "O"]
        assert s.wyckoff_letters == ["a", "a"]


def test_crystal_generate():
    # space group 63
    # ======================================================
    # Multiplicity | Wyckoff letter |      Coordinates
    # ------------------------------------------------------
    #      4       |         b      | (0,1/2,0) (0,1/2,1/2)
    # ------------------------------------------------------
    #      4       |         a      | (0,0,0) (0,0,1/2)
    # ------------------------------------------------------
    # Test generator with parallel=True
    args = GeneratorArgs(
        space_group_num=63,
        volume_of_cell=1000.0,
        variance_of_volume=10.0,
        min_angle_degree=60.0,
        max_angle_degree=90.0,
        max_attempts=100,
        wy_priority={"a": 1.0, "b": 1.0},
    )
    generator = CrystalGenerator(args)
    wyckoff_cfgs = {"Li": ["a"], "P": ["b"]}
    # Large enough to potentially use parallel processing

    s, _, c, args = generator(wyckoff_cfgs)

    assert s.shape == (11, 3)
    assert c is True
    expected_elements = ("Li", "Li", "Li", "Li", "P", "P", "P", "P")
    assert args[0] == expected_elements
    assert args[1] == ("a", "a", "a", "a", "b", "b", "b", "b")

    expected_positions = np.array(
        [
            [0.0, 0.0, 0.0],  # Li
            [0.0, 0.0, 0.5],  # Li
            [0.5, 0.5, 0.0],  # Li
            [0.5, 0.5, 0.5],  # Li
            [0.0, 0.5, 0.0],  # P
            [0.0, 0.5, 0.5],  # P
            [0.5, 1.0, 0.0],  # P
            [0.5, 1.0, 0.5],  # P
        ]
    )
    assert np.allclose(s[3:], expected_positions, atol=1e-6)


def test_crystal_generate_with_mesh():
    args = GeneratorArgs(
        space_group_num=63,
        volume_of_cell=200.0,
        variance_of_volume=10.0,
        min_angle_degree=60.0,
        max_angle_degree=90.0,
        max_attempts=100,
        wy_priority={"a": 1.0, "b": 1.0},
    )
    generator = CrystalGenerator(args)
    wyckoff_cfgs = {"Li": ["a"], "P": ["b"]}
    # Large enough to potentially use parallel processing

    s: CrystalStructure = generator(wyckoff_cfgs, use_mesh=True, expect_size=1, return_crystal_structures=True)

    assert s.space_group_num == 63, f"{s = }"
    assert 350 < s.volume < 450

    ase_s = s.ase_atoms
    assert isinstance(ase_s, Atoms)

    pmg_s = s.pymatgen_structure
    assert isinstance(pmg_s, Structure)

    dis = pmg_s.distance_matrix
    np.fill_diagonal(dis, 1e5)  # Ignore self-distance
    assert dis.min() > 1.6


# Tests derived from benchmark_crystal_generator.py


@pytest.fixture
def setup_ag_ge_s_generator():
    """Setup fixture for crystal generator tests with Ag-Ge-S system."""
    # Create generator arguments for Ag32 Ge4 S24 in space group 33
    args = GeneratorArgs(
        space_group_num=33,
        volume_of_cell=1254.59930407,
        variance_of_volume=30.0,
        min_angle_degree=60.0,
        max_angle_degree=90.0,
        max_attempts=100,
    )

    # Define composition
    composition = {"Ag": 32, "Ge": 4, "S": 24}

    # Generate Wyckoff configurations
    wy_cfg = WyckoffCfgGenerator(args)
    wy_cfgs = wy_cfg(
        composition,
        expect_size=1,
        progress_bar=False,
        drop_duplicates=True,
    )

    return args, wy_cfgs


@pytest.mark.parametrize("n_jobs", [1, 2])
def test_crystal_generation_parallel_functionality(setup_ag_ge_s_generator, n_jobs):
    """Test crystal generation with different n_jobs values."""
    args, wy_cfgs = setup_ag_ge_s_generator

    # Generate a small number of structures to keep test runtime reasonable
    opt_structure = CrystalGenerator(args)
    structures = opt_structure(
        wy_cfgs,
        expect_size=2,  # Small number for faster testing
        use_mesh=True,
        perturbation=0.05,
        return_crystal_structures=True,
        check_atomic_dist=True,
        progress_bar=False,
        n_jobs=n_jobs,
    )

    # Verify generation was successful
    assert structures is not None
    if isinstance(structures, list):
        assert len(structures) > 0
        for structure in structures:
            assert isinstance(structure, CrystalStructure)
            assert structure.space_group_num == 33


def test_single_structure_generation_functionality(setup_ag_ge_s_generator):
    """Test single structure generation path."""
    args, wy_cfgs = setup_ag_ge_s_generator

    opt_structure = CrystalGenerator(args)
    structure = opt_structure(
        wy_cfgs,
        expect_size=1,
        use_mesh=True,
        perturbation=0.05,
        return_crystal_structures=True,
        check_atomic_dist=True,
    )

    # Verify generation was successful
    assert structure is not None
    assert isinstance(structure, CrystalStructure)
    assert structure.space_group_num == 33


@pytest.mark.parametrize("use_mesh", [True, False])
def test_mesh_vs_random_functionality(setup_ag_ge_s_generator, use_mesh):
    """Test mesh-based vs random generation strategies."""
    args, wy_cfgs = setup_ag_ge_s_generator

    # Update args for random generation to prevent test from running too long
    max_attempts = 500 if not use_mesh else 100
    args.max_attempts = max_attempts

    opt_structure = CrystalGenerator(args)
    structures = opt_structure(
        wy_cfgs,
        expect_size=1,  # Single structure for quick testing
        use_mesh=use_mesh,
        perturbation=0.05,
        return_crystal_structures=True,
        check_atomic_dist=True,
        progress_bar=False,
        n_jobs=1,
    )

    # Verify generation behavior
    if use_mesh:
        # For mesh-based generation, we expect success
        assert structures is not None
        if isinstance(structures, list):
            assert len(structures) > 0
    else:
        # For random generation, we can't guarantee structures will be generated
        # with the reduced max_attempts, so we just check that the function runs
        pass


@pytest.mark.parametrize("perturbation", [0.0, 0.1])
def test_perturbation_effect_functionality(setup_ag_ge_s_generator, perturbation):
    """Test the effect of different perturbation values."""
    args, wy_cfgs = setup_ag_ge_s_generator

    opt_structure = CrystalGenerator(args)
    structures = opt_structure(
        wy_cfgs,
        expect_size=1,  # Single structure for quick testing
        use_mesh=True,
        perturbation=perturbation,
        return_crystal_structures=True,
        check_atomic_dist=True,
        progress_bar=False,
        n_jobs=1,
    )

    # Verify generation was successful
    assert structures is not None
    if isinstance(structures, list):
        assert len(structures) > 0


@pytest.mark.parametrize("check_atomic_dist", [True, False])
def test_atomic_distance_checking_functionality(setup_ag_ge_s_generator, check_atomic_dist):
    """Test the effect of atomic distance checking."""
    args, wy_cfgs = setup_ag_ge_s_generator

    opt_structure = CrystalGenerator(args)
    structures = opt_structure(
        wy_cfgs,
        expect_size=1,  # Single structure for quick testing
        use_mesh=False,
        perturbation=0.05,
        return_crystal_structures=True,
        check_atomic_dist=check_atomic_dist,
        progress_bar=False,
        n_jobs=1,
    )

    # Verify generation was successful
    assert structures is not check_atomic_dist


def test_batch_size_functionality(setup_ag_ge_s_generator):
    """Test functionality with different batch sizes."""
    args, wy_cfgs = setup_ag_ge_s_generator

    opt_structure = CrystalGenerator(args)
    structures = opt_structure(
        wy_cfgs,
        expect_size=3,  # Small batch size for quick testing
        use_mesh=True,
        perturbation=0.05,
        return_crystal_structures=True,
        check_atomic_dist=True,
        progress_bar=False,
        n_jobs=1,  # Serial for faster testing
    )

    # Verify generation was successful
    assert structures is not None
    assert isinstance(structures, list)
    assert len(structures) == 3  # We expect exactly the requested number

    # Check that all structures are valid
    for structure in structures:
        assert isinstance(structure, CrystalStructure)
        assert structure.space_group_num == 33
