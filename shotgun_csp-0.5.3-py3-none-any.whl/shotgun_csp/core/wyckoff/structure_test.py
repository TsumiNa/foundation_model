# Copyright 2025 TsumiNa.
# SPDX-License-Identifier: Apache-2.0
import json

import numpy as np
from ase import Atoms
from pymatgen.core import Structure

from shotgun_csp.core.wyckoff.structure import CrystalStructure


def test_crystal_structure_equality():
    """Test CrystalStructure equality."""
    lattice1 = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
    particles1 = np.array([[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])
    crystal1 = CrystalStructure(
        space_group_num=225,
        volume=1.0,
        lattice=lattice1,
        positions=particles1,
        atoms=["Si", "Si"],
        wyckoff_letters=["a", "b"],
    )

    assert isinstance(crystal1.ase_atoms, Atoms)
    assert isinstance(crystal1.pymatgen_structure, Structure)
    assert crystal1.wyckoff_cfg == {"Si": ["a", "b"]}

    lattice2 = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
    particles2 = np.array([[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])
    crystal2 = CrystalStructure(
        space_group_num=225,
        volume=1.0,
        lattice=lattice2,
        positions=particles2,
        atoms=["Si", "Si"],
        wyckoff_letters=["a", "b"],
    )

    assert crystal1 == crystal2

    # Test inequality due to lattice
    lattice3 = np.array([[1.1, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
    crystal3 = CrystalStructure(
        space_group_num=225,
        volume=1.0,
        lattice=lattice3,
        positions=particles1,
        atoms=["Si", "Si"],
        wyckoff_letters=["a", "b"],
    )
    assert crystal1 != crystal3

    # Test inequality due to particles
    particles4 = np.array([[0.1, 0.0, 0.0], [0.5, 0.5, 0.5]])
    crystal4 = CrystalStructure(
        space_group_num=225,
        volume=1.0,
        lattice=lattice1,
        positions=particles4,
        atoms=["Si", "Si"],
        wyckoff_letters=["a", "b"],
    )
    assert crystal1 != crystal4

    # Test inequality due to elements
    crystal5 = CrystalStructure(
        space_group_num=225,
        volume=1.0,
        lattice=lattice1,
        positions=particles1,
        atoms=["C", "Si"],
        wyckoff_letters=["a", "b"],
    )
    assert crystal1 != crystal5


def test_crystal_structure_inequality_different_type():
    """Test CrystalStructure inequality with a different type."""
    lattice1 = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
    particles1 = np.array([[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])
    crystal1 = CrystalStructure(
        space_group_num=225,
        volume=1.0,
        lattice=lattice1,
        positions=particles1,
        atoms=["Si", "Si"],
        wyckoff_letters=["a", "b"],
    )

    assert crystal1 != 1


def test_crystal_structure_serialization():
    """Test CrystalStructure serialization/deserialization.

    Added on 4/27/2025: Test the Pydantic-specific functionality for
    serialization and deserialization of NumPy arrays.
    """
    lattice = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
    positions = np.array([[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])
    crystal = CrystalStructure(
        space_group_num=225,
        volume=1.0,
        lattice=lattice,
        positions=positions,
        atoms=["Si", "Si"],
        wyckoff_letters=["a", "b"],
    )

    # Test model_dump
    crystal_dict = crystal.model_dump()
    assert isinstance(crystal_dict["lattice"], list)
    assert isinstance(crystal_dict["positions"], list)
    assert crystal_dict["space_group_num"] == 225

    # Test model_dump_json
    crystal_json = crystal.model_dump_json()
    crystal_dict_from_json = json.loads(crystal_json)
    assert isinstance(crystal_dict_from_json["lattice"], list)
    assert crystal_dict_from_json["space_group_num"] == 225

    # Test deserialization from dict
    crystal2 = CrystalStructure.model_validate(crystal_dict)
    assert isinstance(crystal2.lattice, np.ndarray)
    assert isinstance(crystal2.positions, np.ndarray)
    assert crystal == crystal2

    # Test deserialization from JSON
    crystal3 = CrystalStructure.model_validate_json(crystal_json)
    assert isinstance(crystal3.lattice, np.ndarray)
    assert isinstance(crystal3.positions, np.ndarray)
    assert crystal == crystal3


def test_crystal_structure_to_dict():
    """Test CrystalStructure to_dict method.

    Added on 4/27/2025: Test the to_dict method to ensure it properly
    excludes cached properties.
    """
    lattice = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
    positions = np.array([[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])
    crystal = CrystalStructure(
        space_group_num=225,
        volume=1.0,
        lattice=lattice,
        positions=positions,
        atoms=["Si", "Si"],
        wyckoff_letters=["a", "b"],
    )

    # Test to_dict excludes cached properties
    crystal_dict = crystal.to_dict()

    # These should be present
    assert "space_group_num" in crystal_dict
    assert "volume" in crystal_dict
    assert "lattice" in crystal_dict
    assert "positions" in crystal_dict
    assert "atoms" in crystal_dict
    assert "wyckoff_letters" in crystal_dict

    # These should be excluded (cached properties)
    assert "pymatgen_structure" not in crystal_dict
    assert "ase_atoms" not in crystal_dict

    # Check that the values are correct
    assert crystal_dict["space_group_num"] == 225
    assert crystal_dict["volume"] == 1.0
    assert isinstance(crystal_dict["lattice"], list)
    assert isinstance(crystal_dict["positions"], list)
